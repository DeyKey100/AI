#!/usr/bin/env python3
"""
Регрессионный тест на падение голосового сервера из-за кодировки stdout.

ИНЦИДЕНТ (2026-09-21, машина владельца)
----------------------------------------
start_karen.bat запускает сервер СКРЫТО через run_hidden.vbs, stdout уходит
в logs\\tts.log. В этом режиме CPython берёт для stdout кодировку локали -
cp1251 на русской Windows - и первая же печать символа вне cp1251 (стрелка
U+2192 в баннере) убивала процесс:

    UnicodeEncodeError: 'charmap' codec can't encode character '\\u2192'
      File "...\\silero_openai_tts_server.py", line 973, in main

Снаружи это выглядело как «start_karen.bat висит на Starting voice server».

ЧТО ПРОВЕРЯЕТ ТЕСТ
------------------
1. guard из реального сервера вырезается по маркерам и вставляется в
   мини-скрипт, печатающий те же проблемные символы;
2. запуск с PYTHONIOENCODING=cp1251 и stdout в файл:
     БЕЗ guard  -> процесс падает (UnicodeEncodeError) - баг воспроизведён;
     С guard    -> код 0, лог в UTF-8, текст на месте;
3. запуск в pty (консоль): guard НЕ меняет кодовую страницу, только
   errors='replace' -> кириллица читается, экзотика становится '?';
4. сам сервер не содержит символов вне cp1251 в исполняемых строках
   (страховка на случай, если guard когда-нибудь вырежут).

ЗАПУСК:  python tts/test_stdio_guard.py     (нужен только python3, ~1 c)
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SERVER = os.path.join(HERE, "silero_openai_tts_server.py")
GUARD_START = "# --- KAREN stdio guard"
GUARD_END = "# --- end KAREN stdio guard"

# символы, которые cp1251 не кодирует (стрелка, минус, псевдографика, эмодзи)
NASTY = "Silero TTS \u2192 OpenAI  \u2212 5.4  \u2500\u2500  \U0001F600"

fails: list[str] = []


def extract_guard() -> str:
    src = open(SERVER, encoding="utf-8").read()
    i = src.find(GUARD_START)
    j = src.find(GUARD_END)
    if i < 0 or j < 0:
        fails.append(f"в {os.path.basename(SERVER)} нет stdio guard "
                     f"(встройте: python tools/inject_stdio_guard.py)")
        return ""
    return src[i:j + len(GUARD_END)]


def run(script: str, env_extra: dict, to_file: bool, pty: bool = False):
    """Возвращает (returncode, текст-вывода)."""
    env = dict(os.environ)
    env.update(env_extra)
    with tempfile.TemporaryDirectory() as td:
        sp = os.path.join(td, "t.py")
        open(sp, "w", encoding="utf-8", newline="\n").write(script)
        out = os.path.join(td, "out.txt")
        if pty:
            # `script` даёт настоящую pty -> sys.stdout.isatty() == True.
            # В pty guard НЕ меняет кодовую страницу, поэтому байты наружу
            # идут именно в cp1251 - декодируем их так же, как это сделал
            # бы консольный шрифт Windows.
            cmd = ["script", "-qec", f"{sys.executable} {sp}", "/dev/null"]
            r = subprocess.run(cmd, capture_output=True, env=env, timeout=60)
            txt = r.stdout.decode("cp1251", "replace")
            return r.returncode, "".join(c for c in txt if c == "\n" or ord(c) >= 32)
        if to_file:
            with open(out, "wb") as fh:
                r = subprocess.run([sys.executable, sp], stdout=fh,
                                   stderr=subprocess.STDOUT, env=env, timeout=60)
            data = open(out, "rb").read()
            return r.returncode, data.decode("utf-8", "replace")
        r = subprocess.run([sys.executable, sp], capture_output=True, env=env, timeout=60)
        return r.returncode, (r.stdout + r.stderr).decode("utf-8", "replace")


def main() -> int:
    guard = extract_guard()
    print("=" * 72)
    print(" ТЕСТ: защита stdout от UnicodeEncodeError (cp1251)")
    print("=" * 72)
    if not guard:
        print("\n".join("   - " + f for f in fails))
        return 1

    body = f'print({NASTY!r})\nprint("\u041f\u0440\u0438\u0432\u0435\u0442, \u044f \u041a\u0430\u0440\u0435\u043d.")\n'
    no_guard = "import sys\n" + body
    with_guard = guard + "\n\n" + body

    # --- 1. воспроизводим баг: cp1251 + redirect, БЕЗ guard --------------
    rc, out = run(no_guard, {"PYTHONIOENCODING": "cp1251"}, to_file=True)
    if rc == 0:
        fails.append("БАГ НЕ ВОСПРОИЗВОДИТСЯ: печать U+2192 в cp1251-файл прошла "
                     "(окружение не эмулирует русскую Windows) - тест не показателен")
        print("    [??] без guard: rc=0 (ожидали падение) - среда не cp1251?")
    else:
        ok = "UnicodeEncodeError" in out
        print(f"    [ok] без guard: rc={rc}, UnicodeEncodeError={'да' if ok else 'нет'} "
              f"- инцидент воспроизведён")
        if not ok:
            fails.append(f"без guard ошибка другая: {out.strip()[-160:]}")

    # --- 2. лечим: cp1251 + redirect, С guard ----------------------------
    rc, out = run(with_guard, {"PYTHONIOENCODING": "cp1251"}, to_file=True)
    if rc != 0:
        fails.append(f"С guard процесс всё равно упал (rc={rc}): {out.strip()[-200:]}")
        print(f"    [FAIL] с guard: rc={rc}")
    else:
        has_arrow = "\u2192" in out
        has_cyr = "\u041a\u0430\u0440\u0435\u043d" in out
        print(f"    [ok] с guard: rc=0, лог UTF-8, стрелка на месте={has_arrow}, "
              f"кириллица={has_cyr}")
        if not has_cyr:
            fails.append("с guard в лог не попала кириллица - кодировка не UTF-8?")

    # --- 3. консоль (pty): кодовая страница НЕ меняется ------------------
    if os.name == "posix" and subprocess.run(["which", "script"], capture_output=True).returncode == 0:
        rc, out = run(with_guard, {"PYTHONIOENCODING": "cp1251"}, to_file=False, pty=True)
        if rc != 0:
            fails.append(f"в pty guard уронил процесс (rc={rc}): {out.strip()[-160:]}")
            print(f"    [FAIL] pty: rc={rc}")
        else:
            # cp1251 не знает стрелки -> '?'; кириллица обязана остаться
            keep_cyr = "\u041a\u0430\u0440\u0435\u043d" in out
            print(f"    [ok] pty (консоль): rc=0, кириллица сохранена={keep_cyr}, "
                  f"стрелка заменена={'?' in out}")
            if not keep_cyr:
                fails.append("в pty потерялась кириллица - guard сломал консольный вывод")
    else:
        print("    [skip] pty-проверка (нет утилиты script)")

    # --- 4. сервер не печатает символы вне cp1251 -------------------------
    src = open(SERVER, encoding="utf-8").read()
    bad = set()
    for m in re.finditer(r'(?:print\(|help=|raise SystemExit\(|detail=)', src):
        tail = src[m.end():m.end() + 400]
        for ch in tail:
            if ord(ch) > 127:
                try:
                    ch.encode("cp1251")
                except Exception:
                    bad.add(ch)
    if bad:
        fails.append("в print/help сервера остались символы вне cp1251: "
                     + ", ".join(f"U+{ord(c):04X}" for c in sorted(bad)))
        print(f"    [FAIL] не-cp1251 символы в печати: {sorted(bad)}")
    else:
        print("    [ok] в print/help сервера нет символов вне cp1251")

    print("=" * 72)
    if fails:
        print(f" ПРОВАЛЕНО: {len(fails)}")
        for f in fails:
            print("   -", f)
        return 1
    print(" ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
