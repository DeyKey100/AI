#!/usr/bin/env python3
"""
Проверка Silero TTS-сервера ровно так, как его вызывает Open-LLM-VTuber.

Проект использует (src/open_llm_vtuber/tts/openai_tts.py):

    from openai import OpenAI
    client = OpenAI(api_key=..., base_url=...)
    with client.audio.speech.with_streaming_response.create(
            model=..., voice=..., input=text,
            response_format=file_extension, speed=speed) as response:
        response.stream_to_file(path)

Этот тест повторяет тот же вызов, поэтому «зелёный» результат означает,
 что и VTuber-бэкенд получит аудио.

Запуск:  python test_silero_server.py [--base-url http://127.0.0.1:8880/v1] [--out out]
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
import wave

TEXT_SHORT = "Привет! Я твой локальный компаньон."
TEXT_LONG = ("Сейчас проверим длинную фразу: если синтез быстрее реального времени, "
             "то задержка вообще не будет заметна в разговоре.")
# Регрессия бага 2026-09-21: Silero v5_5_ru бросает ГОЛЫЙ ValueError() на тексте
# без единой кириллической буквы, сервер отвечал HTTP 500 {'detail': 'ошибка синтеза: '}.
# Бэкенд присылал именно такие строки, когда Groq отвечал 403 и текст ошибки LLM
# попадал в озвучку. Теперь сервер транслитерирует латиницу и подменяет
# нечитаемый текст запасной фразой, поэтому все три случая обязаны давать 200.
TEXTS_NONCYRILLIC = (
    ("latin", "Error calling the chat endpoint: Error occurred while generating response."),
    ("mixed", "Привет! Error calling the chat endpoint."),
    ("digits", "403"),
)
UA = {"User-Agent": "Mozilla/5.0 (open-llm-vtuber-silero-test)"}


def http_get(url: str, timeout: int = 20):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, json.loads(r.read().decode())


def wav_info(path: str) -> tuple[float, int]:
    with wave.open(path) as w:
        return w.getnframes() / w.getframerate(), w.getframerate()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://127.0.0.1:8880/v1")
    ap.add_argument("--out", default="silero_test_output")
    ap.add_argument("--voice", default="baya")
    args = ap.parse_args()

    root = args.base_url.rstrip("/")
    host = root[:-3] if root.endswith("/v1") else root
    os.makedirs(args.out, exist_ok=True)
    failures = []

    print("=" * 68)
    print(f" Silero TTS server test -> {root}")
    print("=" * 68)

    # 1. health
    try:
        st, data = http_get(host + "/health")
        print(f"[ok] /health {st}: status={data.get('status')} model={data.get('model')} "
              f"threads={data.get('threads')} rtf_avg={data.get('rtf_avg')}")
        if data.get("status") != "ok":
            failures.append("health: модель не загружена")
    except Exception as e:  # noqa: BLE001
        print(f"[FAIL] /health недоступен: {e}")
        print("       Запустите сервер:  python silero_openai_tts_server.py --warmup")
        return 2

    # 2. список голосов
    try:
        st, data = http_get(host + "/v1/voices")
        names = [v["voice_id"] for v in data.get("voices", [])]
        print(f"[ok] /v1/voices: {len(names)} -> {', '.join(names)}")
        if args.voice not in names:
            print(f"[!!] запрошенный голос '{args.voice}' не найден, беру {names[0]}")
            args.voice = names[0]
    except Exception as e:  # noqa: BLE001
        print(f"[FAIL] /v1/voices: {e}")

    # 3. главный тест: OpenAI SDK (как в проекте)
    try:
        from openai import OpenAI
    except ImportError:
        print("[!!] пакет openai не установлен — проверяю только через urllib")
        OpenAI = None

    if OpenAI:
        client = OpenAI(api_key="not-needed", base_url=root, timeout=120)
        for label, text, speed in (("short", TEXT_SHORT, 1.0),
                                   ("long", TEXT_LONG, 1.0),
                                   ("fast", TEXT_SHORT, 1.15)):
            path = os.path.join(args.out, f"{args.voice}_{label}.wav")
            t0 = time.time()
            try:
                with client.audio.speech.with_streaming_response.create(
                    model="silero-v5_5_ru",
                    voice=args.voice,
                    input=text,
                    response_format="wav",
                    speed=speed,
                ) as response:
                    response.stream_to_file(path)
                dt = time.time() - t0
                dur, sr = wav_info(path)
                rtf = dt / dur if dur else float("inf")
                size = os.path.getsize(path)
                print(f"[ok] SDK/{label:5s}: {dt:5.2f} c -> {dur:5.2f} c аудио "
                      f"({sr} Гц, {size/1024:.0f} КБ) RTF={rtf:.3f}")
                if rtf > 1.0:
                    failures.append(f"RTF {rtf:.2f} > 1 — озвучка медленнее речи")
            except Exception as e:  # noqa: BLE001
                print(f"[FAIL] SDK/{label}: {type(e).__name__}: {str(e)[:200]}")
                failures.append(f"SDK {label}")

    # 4. то же через urllib (без SDK) + проверка заголовка RTF
    try:
        body = json.dumps({"model": "silero-v5_5_ru", "voice": args.voice,
                           "input": TEXT_SHORT, "response_format": "wav",
                           "speed": 1.0}).encode()
        req = urllib.request.Request(root + "/audio/speech", data=body,
                                     headers={**UA, "Content-Type": "application/json"})
        t0 = time.time()
        with urllib.request.urlopen(req, timeout=120) as r:
            blob = r.read()
            rtf_hdr = r.headers.get("X-Silero-RTF")
        path = os.path.join(args.out, f"{args.voice}_urllib.wav")
        with open(path, "wb") as f:
            f.write(blob)
        dur, sr = wav_info(path)
        print(f"[ok] urllib: {time.time()-t0:.2f} c -> {dur:.2f} c аудио, "
              f"заголовок X-Silero-RTF={rtf_hdr}")
    except urllib.error.HTTPError as e:
        print(f"[FAIL] urllib: HTTP {e.code} {e.read(200).decode(errors='replace')}")
        failures.append("urllib")
    except Exception as e:  # noqa: BLE001
        print(f"[FAIL] urllib: {type(e).__name__}: {e}")
        failures.append("urllib")

    # 4b. регрессия: текст без кириллицы обязан давать 200, а не 500
    for label, text in TEXTS_NONCYRILLIC:
        try:
            body = json.dumps({"model": "silero-v5_5_ru", "voice": args.voice,
                               "input": text, "response_format": "wav",
                               "speed": 1.0}).encode()
            req = urllib.request.Request(root + "/audio/speech", data=body,
                                         headers={**UA, "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=120) as r:
                blob = r.read()
            path = os.path.join(args.out, f"{args.voice}_noncyr_{label}.wav")
            with open(path, "wb") as f:
                f.write(blob)
            dur, _ = wav_info(path)
            if dur < 0.2:
                print(f"[FAIL] noncyr/{label}: аудио {dur:.2f} c - почти тишина")
                failures.append(f"noncyr {label}")
            else:
                print(f"[ok] noncyr/{label:6s}: {dur:.2f} c аудио (текст без кириллицы не роняет сервер)")
        except urllib.error.HTTPError as e:
            detail = e.read(300).decode(errors="replace")
            print(f"[FAIL] noncyr/{label}: HTTP {e.code} {detail[:200]}")
            failures.append(f"noncyr {label}")
        except Exception as e:  # noqa: BLE001
            print(f"[FAIL] noncyr/{label}: {type(e).__name__}: {e}")
            failures.append(f"noncyr {label}")

    # 5. все голоса — чтобы выбрать на слух
    print("\n[i] Генерирую сэмплы всех голосов для прослушивания ...")
    try:
        st, data = http_get(host + "/v1/voices")
        all_voices = [v["voice_id"] for v in data.get("voices", [])]
    except Exception:  # noqa: BLE001
        all_voices = [args.voice]
    for v in all_voices:
        path = os.path.join(args.out, f"voice_{v}.wav")
        if os.path.exists(path):
            continue
        try:
            body = json.dumps({"model": "silero-v5_5_ru", "voice": v, "input": TEXT_SHORT,
                               "response_format": "wav", "speed": 1.0}).encode()
            req = urllib.request.Request(root + "/audio/speech", data=body,
                                         headers={**UA, "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=120) as r:
                blob = r.read()
            with open(path, "wb") as f:
                f.write(blob)
            dur, _ = wav_info(path)
            print(f"     {v:16s} -> {path}  ({dur:.2f} c)")
        except Exception as e:  # noqa: BLE001
            print(f"     {v:16s} FAIL {str(e)[:80]}")

    # 6. итоговая статистика сервера
    try:
        st, data = http_get(host + "/health")
        print(f"\n[i] статистика сервера: requests={data.get('requests')} "
              f"audio={data.get('audio_seconds')} c synth={data.get('synth_seconds')} c "
              f"rtf_avg={data.get('rtf_avg')}")
    except Exception:  # noqa: BLE001
        pass

    print("\n" + "=" * 68)
    if failures:
        print(" ЕСТЬ ПРОБЛЕМЫ: " + "; ".join(failures))
        print("=" * 68)
        return 1
    print(" ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ — сервер совместим с openai_tts из Open-LLM-VTuber")
    print("=" * 68)
    print(" Подключение в conf.yaml:")
    print("   tts_config:")
    print("     tts_model: 'openai_tts'")
    print("     openai_tts:")
    print("       model: 'silero-v5_5_ru'")
    print(f"       voice: '{args.voice}'")
    print("       api_key: 'not-needed'")
    print(f"       base_url: '{root}'")
    print("       file_extension: 'wav'")
    return 0


if __name__ == "__main__":
    sys.exit(main())
