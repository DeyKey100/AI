#!/usr/bin/env python3
"""
Генератор демонстрационных сэмплов KAREN Voice.

Создаёт в audio/ два набора:
  voices/     — сравнение тембров и уровней тона (baya как есть / +high / +x-high / robot)
  emotional/  — 11 эмоций + прямое сравнение «эмо-движок выключен / включён»

Зачем отдельный скрипт: сэмплы в репозитории — это артефакты конкретной модели
и конкретного железа. Если захотите поменять пресет (pitch_st/rate/набор эмоций)
или обновить Silero — просто перезапустите скрипт и получите свежие файлы.

Запуск (в окружении TTS-сервера):
    python make_samples.py
    python make_samples.py --out ../../audio --voice baya_anime --sample-rate 48000

Требуется: torch, silero (и numpy). Сервер поднимать не нужно — скрипт работает
с моделью напрямую, используя те же функции, что и сервер.
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import os
import sys
import time
import warnings
import wave

warnings.filterwarnings("ignore")
os.environ.setdefault("SILERO_LICENSE", "accepted")

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import numpy as np  # noqa: E402

import silero_openai_tts_server as K  # noqa: E402

COMPARE_TEXT = "Ну ты даёшь! Я такого вообще не ожидала. Хм... расскажешь, что случилось?"

EMO_LINES = [
    ("neutral",   "Сегодня вторник. Мы планировали разобраться с настройками, и вот мы здесь."),
    ("joy",       "[joy] Ура, получилось! Я так рада, что всё заработало."),
    ("excited",   "[excited] Да ладно! Серьёзно? Ну ты даёшь, я в восторге!"),
    ("surprise",  "[surprise] Что? Правда? Я вообще не это ожидала услышать."),
    ("tease",     "[tease] Хм... а вот это уже интересно. Ну-ну, расскажи ещё."),
    ("sarcastic", "[sarcastic] Конечно, как скажешь. Гениальная идея, просто браво."),
    ("sad",       "[sad] Жаль, но сегодня не выйдет. Обидно, честно говоря."),
    ("angry",     "[angry] Хватит уже это делать! Достало, серьёзно."),
    ("shy",       "[shy] Ой... ну я не знаю даже. Ты меня смущаешь."),
    ("sleepy",    "[sleepy] Я уже засыпаю... давай завтра продолжим, а?"),
    ("robot",     "[robot] Системы в норме. Реактор стабилен. Привет, человек."),
]


def write_wav(path: str, x: np.ndarray, sr: int) -> float:
    x = K.normalize(x)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((np.clip(x, -1.0, 1.0) * 32767).astype("<i2").tobytes())
    return len(x) / sr


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None, help="куда складывать сэмплы (по умолчанию ../../audio)")
    ap.add_argument("--voice", default="baya")
    ap.add_argument("--sample-rate", type=int, default=48000, choices=[8000, 24000, 48000])
    ap.add_argument("--threads", type=int, default=0)
    args = ap.parse_args()

    out = args.out or os.path.normpath(os.path.join(HERE, "..", "audio"))
    sr = args.sample_rate

    import torch
    if args.threads > 0:
        torch.set_num_threads(args.threads)

    print("=" * 72)
    print(" KAREN Voice — генератор демо-сэмплов")
    print("=" * 72)
    print(f" голос-основа : {args.voice}")
    print(f" sample rate  : {sr}")
    print(f" потоков torch: {torch.get_num_threads()}")
    print(f" папка        : {os.path.abspath(out)}")

    t0 = time.time()
    K.load_model("v5_5_ru", args.threads or 4)
    print(f"[ok] модель загружена за {time.time() - t0:.1f} c")

    try:
        vname, profile = K.resolve_voice(args.voice)
    except KeyError:
        print(f"[xx] нет голоса '{args.voice}'. Доступны: {', '.join(sorted(K.VOICES))}")
        return 1

    rows = []

    # ---- 1) сравнение тембров/уровней тона -------------------------------
    print("\n[1/3] Сравнение вариантов тембра")
    variants = [
        ("baya_raw",      "baya", "medium", "спикер baya без обработки"),
        ("baya_high",     "baya", "high",   "baya + native high (+2.4 полутона)"),
        ("baya_xhigh",    "baya", "x-high", "baya + native x-high (+3.1 полутона)"),
        ("baya_low",      "baya", "low",    "baya + native low (-3.2 полутона)"),
        ("baya_robot",    "baya", "robot",  "эффект робота (pitch=robot)"),
    ]
    for fname, spk, pitch, desc in variants:
        ssml = (f'<speak><prosody pitch="{pitch}" rate="medium">'
                f'{K.xml_escape("Привет! Как тебе мой тембр?")}</prosody></speak>')
        t = time.time()
        x = K.synth(ssml_text=ssml, speaker=spk, sample_rate=sr)
        dt = time.time() - t
        dur = write_wav(os.path.join(out, "voices", fname + ".wav"), x, sr)
        rows.append((f"voices/{fname}.wav", dt, dur, desc))
        print(f"  {fname:14s} {dt*1000:5.0f} мс -> {dur:5.2f} c   {desc}")

    # ---- 2) эмоции -------------------------------------------------------
    print(f"\n[2/3] Эмоции на голосе {vname}")
    for emo, text in EMO_LINES:
        t = time.time()
        ssml, trace = K.build_ssml(text, profile, jitter=False)
        x = K.synth(ssml_text=ssml, speaker=profile["speaker"], sample_rate=sr)
        if profile.get("chipmunk_st"):
            x = K.chipmunk(x, profile["chipmunk_st"])
        dt = time.time() - t
        dur = write_wav(os.path.join(out, "emotional", f"emo_{emo}.wav"), x, sr)
        got = trace[0]["emotion"] if trace else "?"
        pit = trace[0]["pitch"] if trace else "-"
        rat = trace[0]["rate"] if trace else "-"
        rows.append((f"emotional/emo_{emo}.wav", dt, dur,
                     f"{got}: pitch={pit}, rate={rat}"))
        print(f"  {emo:10s} {dt*1000:5.0f} мс -> {dur:5.2f} c   "
              f"определено={got:10s} pitch={pit:7s} rate={rat}")

    # ---- 3) прямое сравнение: эмо-движок выключен / включён --------------
    print("\n[3/3] Сравнение «без эмоций» против «с эмоциями» (один и тот же текст)")
    for label, use_emo in (("emo-off", False), ("emo-on", True)):
        t = time.time()
        if use_emo:
            ssml, trace = K.build_ssml(COMPARE_TEXT, profile, jitter=True)
            x = K.synth(ssml_text=ssml, speaker=profile["speaker"], sample_rate=sr)
            info = ",".join(t_["emotion"] for t_ in trace)
        else:
            x = K.synth(text=COMPARE_TEXT, speaker=profile["speaker"], sample_rate=sr)
            info = "текст как есть"
        dt = time.time() - t
        dur = write_wav(os.path.join(out, "emotional", f"compare_{label}.wav"), x, sr)
        rows.append((f"emotional/compare_{label}.wav", dt, dur, info))
        print(f"  {label:8s} {dt*1000:5.0f} мс -> {dur:5.2f} c   {info}")

    total_dt = sum(r[1] for r in rows)
    total_dur = sum(r[2] for r in rows)
    print("\n" + "=" * 72)
    print(f" готово: {len(rows)} файлов, {total_dt:.2f} c синтеза на {total_dur:.1f} c аудио")
    print(f" средний RTF {total_dt / total_dur:.4f}  (на этом железе)")
    print(f" папка: {os.path.abspath(out)}")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
