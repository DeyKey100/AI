#!/usr/bin/env python3
"""
Silero TTS v5 -> OpenAI-совместимый TTS-сервер с ЭМОЦИОНАЛЬНОЙ prosody.
=====================================================================

Для Open-LLM-VTuber: проект подключается штатным провайдером `openai_tts`
(файл src/open_llm_vtuber/tts/openai_tts.py есть и в main, и в теге v1.2.1),
патчить исходники проекта не нужно.

    POST /v1/audio/speech
    {"model": "...", "voice": "...", "input": "...", "response_format": "wav", "speed": 1.0}
    -> audio/wav

-----------------------------------------------------------------------------
ЧТО УМЕЕТ (и почему это дёшево)
-----------------------------------------------------------------------------
1. НАТИВНЫЙ SSML Silero v5_5: <speak>, <prosody pitch/rate>, <break time>, <p>, <s>.
   Измерено (baya, 48 кГц): pitch x-low/low/medium/high/x-high = 177.8 / 201.7 /
   242.4 / 277.5 / 289.2 Гц, то есть диапазон примерно -5.4...+3.1 полутона
   БЕЗ артефактов постобработки; есть отдельное значение pitch="robot".
   rate меняет длительность в 2.8 раза (x-slow 6.10 c … x-fast 2.20 c) почти
   не трогая тон. Задержка SSML такая же, как у обычного текста (0.11 vs 0.12 c).

2. ЭМО-ДВИЖОК: каждая фраза получает свою подачу.
   Источник эмоции (по приоритету):
     a) явный тег от LLM:  [joy] Это же потрясающе! [tease] Или нет?
     b) эвристика по тексту: пунктуация (! ? ... ,), КАПС, ключевые слова
     c) neutral
   Плюс микро-вариативность: к каждой фразе добавляется небольшой случайный
   сдвиг rate (и опционально pitch) — именно её не хватает, чтобы речь
   перестала звучать «как автоответчик». Отключается --no-jitter.

3. ПРОФИЛИ ГОЛОСА: базовый спикер + базовый уровень pitch + базовый rate.
   Эмоции применяются ОТНОСИТЕЛЬНО профиля, поэтому персона сохраняет тембр.

-----------------------------------------------------------------------------
ВАЖНО: почему тон делается через SSML, а не постобработкой
-----------------------------------------------------------------------------
Прежняя версия этого сервера двигала тон передискретизацией в два прохода
(«поднять тон, затем вернуть длительность»). Второй проход возвращал и тон —
в итоге f0 не менялся вовсе, а речь просто ускорялась. Одиночная
передискретизация («chipmunk») тон действительно меняет, но ускоряет речь
и даёт характерный мультяшный призвук. Нативный SSML prosody лучше по всем
пунктам, поэтому он теперь основной механизм, а chipmunk оставлен как
опция для экстремальных значений (chipmunk_st), которых нет в SSML.

-----------------------------------------------------------------------------
ЗАПУСК
-----------------------------------------------------------------------------
Отдельное виртуальное окружение (не смешивать с окружением Open-LLM-VTuber:
Silero работает с numpy>=2, а проект пинит numpy<2):

    py -3.11 -m venv .venv-silero            # Windows
    .venv-silero\Scripts\activate
    pip install torch --index-url https://download.pytorch.org/whl/cpu
    pip install silero fastapi "uvicorn[standard]"

    python silero_openai_tts_server.py --warmup

Проверка:  python test_silero_server.py
Голоса:    curl http://127.0.0.1:8880/v1/voices
Здоровье:  curl http://127.0.0.1:8880/health

Windows: просто запустите ..\\start_tts_server.bat

Железо (замерено на 2 vCPU Xeon / 1 ГБ RAM, 2026-09-21):
    RTF 0.027–0.036, фраза 3.2 c озвучивается за 0.08–0.15 c,
    RAM ~0.6 ГБ, VRAM 0. На i7-13620H будет быстрее.

Лицензия: Silero Models — CC BY-NC 4.0 (некоммерческое использование).
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import gc
import io
import math
import os
import random
import re
import threading
import time
import wave
from typing import Any, Optional
from xml.sax.saxutils import escape as xml_escape

os.environ.setdefault("SILERO_LICENSE", "accepted")

import numpy as np  # noqa: E402

try:
    import torch  # noqa: E402
except ImportError as e:  # pragma: no cover
    raise SystemExit("Нужен torch: pip install torch --index-url https://download.pytorch.org/whl/cpu") from e

try:
    from fastapi import FastAPI, HTTPException  # noqa: E402
    from fastapi.responses import JSONResponse, Response  # noqa: E402
    from pydantic import BaseModel, Field  # noqa: E402
    import uvicorn  # noqa: E402
except ImportError as e:  # pragma: no cover
    raise SystemExit('Нужны fastapi/uvicorn: pip install fastapi "uvicorn[standard]"') from e


MODEL_ID = "silero-v5_5_ru"
SSML_PITCHES = ["x-low", "low", "medium", "high", "x-high"]   # + служебное "robot"
SSML_RATES = ["x-slow", "slow", "medium", "fast", "x-fast"]


# --------------------------------------------------------------------------- #
#  Профили голоса
# --------------------------------------------------------------------------- #
#  speaker  — голос Silero (aidar, baya, kseniya, eugene, xenia)
#  pitch    — базовый уровень SSML pitch (влияет на тембр персонажа)
#  rate     — базовая скорость SSML
#  chipmunk_st — ДОПОЛНИТЕЛЬНЫЙ сдвиг тона постобработкой (0 = выключено).
#                Нужен, когда пяти уровней SSML не хватает. Ускоряет речь
#                в 2**(st/12) раз — сервер компенсирует это уровнем rate.
def _p(speaker: str, pitch: str = "medium", rate: str = "medium",
       chipmunk_st: float = 0.0, gender: str = "female", desc: str = "") -> dict:
    return {"speaker": speaker, "pitch": pitch, "rate": rate,
            "chipmunk_st": chipmunk_st, "gender": gender, "desc": desc}


VOICES: dict[str, dict[str, Any]] = {
    # --- рекомендуемые: тембр baya ---
    # Базовый pitch="medium" намеренно: эмо-движок сдвигает его от x-low до x-high,
    # и только из средней точки есть запас ВВЕРХ для радости/восторга.
    # Если поставить базу "high", то joy/excited упрутся в потолок и будут звучать
    # одинаково с neutral (проверено: сатурация).
    "baya_anime":       _p("baya", "medium", "medium", 0, "female",
                           "baya, средний тон: максимальный диапазон эмоций (рекомендую)"),
    "baya_bright":      _p("baya", "high", "medium", 0, "female",
                           "baya + native high: ярче/юнее, но меньше запас вверх для эмоций"),
    "baya_bright_x":    _p("baya", "x-high", "medium", 0, "female",
                           "baya + x-high: самый яркий, эмоции почти не читаются вверх"),
    "baya_bright_extra": _p("baya", "x-high", "slow", 3.0, "female",
                           "baya + x-high + 3 полутона постобработкой (темп скомпенсирован)"),
    # --- остальные спикеры ---
    "kseniya_anime":    _p("kseniya", "high", "medium", 0, "female", "kseniya + high"),
    "kseniya_soft":     _p("kseniya", "medium", "medium", 0, "female", "kseniya как есть"),
    "xenia_anime":      _p("xenia", "high", "medium", 0, "female", "xenia + high"),
    "xenia_soft":       _p("xenia", "medium", "medium", 0, "female", "xenia как есть"),
    "aidar":            _p("aidar", "medium", "medium", 0, "male", "aidar (мужской)"),
    "eugene":           _p("eugene", "medium", "medium", 0, "male", "eugene (мужской)"),
    "baya":             _p("baya", "medium", "medium", 0, "female", "baya как есть"),
    "kseniya":          _p("kseniya", "medium", "medium", 0, "female", "kseniya как есть"),
    "xenia":            _p("xenia", "medium", "medium", 0, "female", "xenia как есть"),
    # --- служебные / для приколов ---
    "baya_robot":       _p("baya", "robot", "medium", 0, "female", "эффект робота (pitch=robot)"),
    "baya_chipmunk":    _p("baya", "x-high", "slow", 5.0, "female",
                           "экстремальный подъём: SSML x-high + 5 полутонов постобработкой"),
}

# Совместимость со старыми именами из первой версии сервера.
LEGACY_ALIASES = {
    "anime_baya": "baya_bright",      # прежний anime_baya звучал ярко -> сохраняем характер
    "anime_kseniya": "kseniya_anime",
    "anime_xenia": "xenia_anime",
    "anime_soft": "kseniya_soft",
    "anime_high": "baya_bright_x",
}


# --------------------------------------------------------------------------- #
#  Эмоции
# --------------------------------------------------------------------------- #
#  pitch_shift — сдвиг уровня SSML pitch в шагах списка SSML_PITCHES (0 = как в профиле)
#  rate        — уровень SSML rate
#  lead_break  — пауза ПЕРЕД фразой, мс (задержка, многозначительность)
#  tail_break  — пауза ПОСЛЕ фразы, мс
EMOTIONS: dict[str, dict[str, Any]] = {
    "neutral":   {"pitch_shift": 0,  "rate": "medium", "lead_break": 0,   "tail_break": 140,
                  "keywords": ()},
    "joy":       {"pitch_shift": +1, "rate": "fast",   "lead_break": 0,   "tail_break": 90,
                  "keywords": ("ура", "здорово", "отлично", "класс", "супер", "обожаю",
                               "люблю", "рада", "рад", "круто", "прекрасно", "вау", "классно",
                               "превосходно", "замечательно", "ураа")},
    "excited":   {"pitch_shift": +2, "rate": "x-fast", "lead_break": 0,   "tail_break": 60,
                  "keywords": ("да ладно", "серьёзно", "серьезно", "не может быть", "ого",
                               "ничего себе", "вау", "обалдеть", "фантастика", "невероятно")},
    "surprise":  {"pitch_shift": +2, "rate": "medium", "lead_break": 130, "tail_break": 210,
                  "keywords": ("что", "как", "почему", "зачем", "неужели", "правда")},
    "tease":     {"pitch_shift": +1, "rate": "slow",   "lead_break": 90,  "tail_break": 240,
                  "keywords": ("ну", "вообще-то", "вообще то", "допустим", "посмотрим",
                               "может быть", "а вот и нет", "хм")},
    "sarcastic": {"pitch_shift": -1, "rate": "slow",   "lead_break": 170, "tail_break": 260,
                  "keywords": ("конечно", "разумеется", "как скажешь", "ага", "ну да",
                               "гениально", "браво", "молодец")},
    "sad":       {"pitch_shift": -2, "rate": "x-slow", "lead_break": 230, "tail_break": 330,
                  "keywords": ("жаль", "грустно", "печально", "обидно", "увы", "к сожалению",
                               "скучаю", "плохо", "расстро")},
    "angry":     {"pitch_shift": -1, "rate": "x-fast", "lead_break": 0,   "tail_break": 110,
                  "keywords": ("хватит", "достало", "надоел", "злюсь", "бесишь", "раздражает",
                               "немедленно", "прекрати")},
    "shy":       {"pitch_shift": +1, "rate": "slow",   "lead_break": 190, "tail_break": 190,
                  "keywords": ("ой", "нуу", "смуща", "стесня", "не знаю")},
    "sleepy":    {"pitch_shift": -2, "rate": "x-slow", "lead_break": 300, "tail_break": 400,
                  "keywords": ("спать", "устала", "устал", "сонная", "засыпаю")},
    "robot":     {"pitch_shift": 0,  "rate": "medium", "lead_break": 0,   "tail_break": 120,
                  "keywords": (), "force_pitch": "robot"},
}

# теги, которые LLM может ставить в тексте: [joy] фраза [tease] фраза
TAG_RE = re.compile(r"\[\s*([a-zA-Zа-яА-Я_]{2,16})\s*\]")
# деление на фразы (сохраняем разделители)
SENT_SPLIT_RE = re.compile(r"(?<=[.!?…])\s+|(?<=\.\s)(?=[А-ЯA-ZЁ])")


# --------------------------------------------------------------------------- #
#  Состояние
# --------------------------------------------------------------------------- #
_SCIPY_WARNED = False

# Карта произношения: что реально уходит в синтез вместо написанного.
# Применяется ТОЛЬКО к тексту для TTS, поэтому субтитры и память диалога
# остаются с нормальным написанием («Карен»).
#
# Значение по умолчанию подобрано замерами (2026-09-21, спикер baya, 48 кГц).
# Метод: длительность гласных по огибающей энергии — в русском ударный гласный
# заметно длиннее. Калибровка метода на контрольных словах:
#     м+ама  -> 0.190 / 0.155 c   (маркер на 1-м слоге, 1-й длиннее)
#     к+ошка -> 0.090 / 0.045 c   (маркер на 1-м слоге, 1-й длиннее)
# Результаты для имени:
#     Карен  -> 0.065 / 0.155 c   ударение на 2-м слоге (x2.38)  <-- НЕ устраивает
#     Карэн  -> 0.080 / 0.150 c   ВСЁ ЕЩЁ на 2-м слоге (x1.88)   <-- одно «э» не лечит
#     К+арэн -> 0.120 / 0.100 c   ударение на 1-м слоге          <-- ПОДХОДИТ
#     Кар+эн -> 0.080 / 0.150 c   идентично «Карэн»: маркер ПОСЛЕ ударного
#                                 гласного моделью игнорируется (md5 совпадает)
# Вывод: нужны ОБА изменения — «э» вместо «е» и маркер «+» ПЕРЕД первым слогом.
#
# ПОДТВЕРЖДЕНО НА СЛУХ владельцем проекта 2026-09-21: из всех собранных вариантов
# единственно правильное ударение дал сэмпл 02_FIXED_marker_a («Привет! Меня зовут
# К+арэн.»). Остальные — 01_WRONG_karen_default (автоударение), 05_variant_e_plain
# (только «э», без маркера) — звучат неверно. Значение ниже менять не нужно.
DEFAULT_STRESS_MAP: dict[str, str] = {"Карен": "К+арэн"}
STRESS_MAP: dict[str, str] = dict(DEFAULT_STRESS_MAP)


def apply_stress(text: str) -> str:
    """Подставить маркеры ударения '+' по карте STRESS_MAP.

    Silero v5_5 поддерживает автоматическую расстановку ударений (put_stress_homo),
    но в алфавите модели есть символ '+', которым ударение задаётся вручную:
    'К+арэн'. Полезно для имён, где автоударение модели ошибается.
    Маркер работает, только если стоит ПЕРЕД гласным ударного слога:
    замерено, что 'Кар+эн' модель игнорирует полностью (md5 совпадает с 'Карэн'),
    а 'К+арэн' переносит ударение на первый слог (0.120/0.100 c против 0.080/0.150 c).
    Замена регистронезависима по первой букве не делается намеренно — имена
    пишутся с фиксированным регистром.
    """
    if not STRESS_MAP or not text:
        return text
    for plain, marked in STRESS_MAP.items():
        if plain and plain in text:
            text = text.replace(plain, marked)
    return text


# --------------------------------------------------------------------------- #
#  Транслитерация латиницы + защита от нечитаемого текста
#
#  Баг 2026-09-21 (логи пользователя + воспроизведение в песочнице):
#  Silero v5_5_ru — РУССКОЯЗЫЧНЫЙ пак. В упакованном внутри v5_5_ru.pt коде
#  (multi_acc_v3_package.py, process_simple_text) текст без ЕДИНОЙ кириллической
#  буквы отбраковывается проверкой  has_text = bool(re.sub(r'[^а-я\- ]', '', s))
#  и вызывает ГОЛЫЙ  raise ValueError  — без сообщения. На стороне сервера это
#  выглядело как HTTP 500 {'detail': 'ошибка синтеза: '} с пустой причиной.
#  Так падала озвучка английской строки «Error calling the chat endpoint: ...»,
#  которую бэкенд пытался произнести после ошибки Groq.
#  Замеры в песочнице на реальном v5_5_ru:
#    «Проверка связи.»                              -> OK
#    «Error calling the chat endpoint: ...»         -> ValueError()
#    «403»                                          -> ValueError()
#    «Привет! Error calling the chat endpoint.»     -> OK, НО латиница Молча
#                                                       выбрасывается фильтром
#                                                       символов модели
#  Лечение: (1) латинские слова фонетически транслитерируются в кириллицу —
#  смешанный текст теперь ПРОИЗНОСИТСЯ ЦЕЛИКОМ, а не теряет английские слова;
#  (2) текст, где не осталось ни кириллицы, ни латиницы (чистые цифры, эмодзи,
#  символы), заменяется короткой запасной фразой — молчание и 500 хуже.
#  Отключается флагом --no-translit (защита от падения остаётся и тогда).
# --------------------------------------------------------------------------- #
TRANSLIT_DIGRAPHS = {
    "sh": "ш", "ch": "ч", "th": "т", "ph": "ф",
    "ck": "к", "qu": "кв", "ee": "и", "oo": "у",
}
TRANSLIT_MAP = {
    "a": "а", "b": "б", "c": "к", "d": "д", "e": "е", "f": "ф", "g": "г",
    "h": "х", "i": "и", "j": "дж", "k": "к", "l": "л", "m": "м", "n": "н",
    "o": "о", "p": "п", "q": "к", "r": "р", "s": "с", "t": "т", "u": "у",
    "v": "в", "w": "в", "x": "кс", "y": "и", "z": "з",
}
UNREADABLE_FALLBACK = "Хм, тут что-то нечитаемое."
LATIN_WORD_RE = re.compile(r"[A-Za-z]+")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁё]")
# Теги эмоций [joy] и т.п. транслитерация обязана сохранить как есть —
# их разбирает build_ssml(), когда эмо-движок включён.
_EMOTION_TAG_RE = re.compile(r"\[(" + "|".join(sorted(EMOTIONS)) + r")\]", re.IGNORECASE)


def translit_word(word: str) -> str:
    """Одно латинское слово -> кириллица фонетически (Error -> Еррор)."""
    low = word.lower()
    out: list[str] = []
    i = 0
    while i < len(low):
        digraph = TRANSLIT_DIGRAPHS.get(low[i:i + 2])
        if digraph:
            out.append(digraph)
            i += 2
        else:
            out.append(TRANSLIT_MAP.get(low[i], ""))
            i += 1
    res = "".join(out)
    if not res:
        return word
    if word.isupper():
        return res.upper()
    if word[0].isupper():
        return res[0].upper() + res[1:]
    return res


def ensure_pronounceable(text: str, translit: bool = True) -> tuple[str, str]:
    """Подготовить текст для Silero v5_5_ru: латиница -> кириллица, мусор -> запасная фраза.

    Возвращает (текст, режим), режим: "" — без изменений, "translit" — латиница
    транслитерирована, "fallback" — текст целиком заменён запасной фразой.
    """
    if not text:
        return text, ""
    # Теги эмоций на время прячем в плейсхолдеры \x00N\x01 (N — цифра: её
    # транслитерация не трогает), потом возвращаем обратно.
    tags: list[str] = []

    def _protect(m: "re.Match[str]") -> str:
        tags.append(m.group(0))
        return f"\x00{len(tags) - 1}\x01"

    protected = _EMOTION_TAG_RE.sub(_protect, text)

    def _restore(t: str) -> str:
        return re.sub(r"\x00(\d+)\x01", lambda m: tags[int(m.group(1))], t)

    def _fix(t: str) -> str:
        if translit:
            t = LATIN_WORD_RE.sub(lambda m: translit_word(m.group(0)), t)
        return t

    if CYRILLIC_RE.search(protected):
        fixed = _fix(protected)
        mode = "translit" if (translit and fixed != protected) else ""
    else:
        # ни одной кириллической буквы — модель гарантированно бросит ValueError()
        fixed = _fix(protected)
        if CYRILLIC_RE.search(fixed):
            mode = "translit"
        else:
            fixed, mode = UNREADABLE_FALLBACK, "fallback"
    return _restore(fixed), mode


STATE: dict[str, Any] = {
    "model": None, "lock": threading.Lock(), "loaded_at": None,
    "requests": 0, "audio_seconds": 0.0, "synth_seconds": 0.0,
    "emotion_hits": {}, "args": None,
}


def load_model(speaker_id: str, threads: int) -> None:
    torch.set_num_threads(max(1, threads))
    t0 = time.time()
    last_err: Optional[Exception] = None
    try:
        from silero import silero_tts
        model, _example = silero_tts(language="ru", speaker=speaker_id)
        STATE["model"] = model
        print(f"[ok] Silero {speaker_id} загружена через pip-пакет за {time.time() - t0:.1f} c")
        print(f"[i]  голоса модели: {list(getattr(model, 'speakers', []))}")
        return
    except Exception as e:  # noqa: BLE001
        last_err = e
        print(f"[!] pip-пакет silero не сработал ({type(e).__name__}: {str(e)[:120]}) — пробую torch.hub")
    try:
        model, _example = torch.hub.load(repo_or_dir="snakers4/silero-models",
                                         model="silero_tts", language="ru", speaker=speaker_id)
        STATE["model"] = model
        print(f"[ok] Silero {speaker_id} загружена через torch.hub за {time.time() - t0:.1f} c")
        return
    except Exception as e:  # noqa: BLE001
        last_err = e
    raise SystemExit(f"[xx] Не удалось загрузить Silero: {last_err}")


def synth(text: str = None, ssml_text: str = None, speaker: str = "baya",
          sample_rate: int = 48000) -> np.ndarray:
    """Синтез с поддержкой нового (text=/ssml_text=) и старого (texts=[]) API."""
    model = STATE["model"]
    if model is None:
        raise RuntimeError("модель не загружена")
    with STATE["lock"]:
        try:
            if ssml_text:
                audio = model.apply_tts(ssml_text=ssml_text, speaker=speaker,
                                        sample_rate=sample_rate)
            else:
                audio = model.apply_tts(text=text, speaker=speaker, sample_rate=sample_rate)
        except TypeError:
            audio = model.apply_tts(texts=[text or ssml_text], sample_rate=sample_rate,
                                    speaker=speaker)
    if isinstance(audio, (list, tuple)):
        audio = audio[0]
    if hasattr(audio, "detach"):
        audio = audio.detach().cpu().numpy()
    return np.asarray(audio, dtype=np.float32).flatten()


# --------------------------------------------------------------------------- #
#  Постобработка (только chipmunk — сдвиг тона одиночной передискретизацией)
# --------------------------------------------------------------------------- #
def _rational(r: float, max_den: int = 1000) -> tuple[int, int]:
    from fractions import Fraction
    f = Fraction(float(r)).limit_denominator(max_den)
    return f.numerator, f.denominator


def _resample(x: np.ndarray, up: int, down: int) -> np.ndarray:
    if up == down:
        return x
    try:
        from scipy.signal import resample_poly
        return resample_poly(x, up, down).astype(np.float32)
    except ImportError:
        global _SCIPY_WARNED
        if not _SCIPY_WARNED:
            _SCIPY_WARNED = True
            print("[!] scipy не установлен — chipmunk-сдвиг тона идёт линейной интерполяцией "
                  "(слышны артефакты). Лечение: pip install scipy. Основного голоса baya "
                  "это не касается: он использует нативный SSML.")
        n_out = int(round(len(x) * up / down))
        idx = np.linspace(0, len(x) - 1, n_out)
        return np.interp(idx, np.arange(len(x)), x).astype(np.float32)


def chipmunk(x: np.ndarray, semitones: float) -> np.ndarray:
    """Одиночная передискретизация: тон выше в r раз, речь быстрее в r раз.

    Именно так (в ОДИН проход) тон действительно меняется. Двухпроходная схема
    «поднять тон, потом вернуть длительность» возвращает и исходный тон тоже —
    это была ошибка прежней версии сервера.
    """
    if abs(semitones) < 1e-3 or len(x) < 64:
        return x
    r = 2.0 ** (semitones / 12.0)
    up, down = _rational(1.0 / r)
    return _resample(x, up, down).astype(np.float32)


def normalize(x: np.ndarray, peak: float = 0.95) -> np.ndarray:
    m = float(np.max(np.abs(x))) if len(x) else 0.0
    return x if m < 1e-6 else (x / m * peak).astype(np.float32)


def to_wav_bytes(x: np.ndarray, sr: int) -> bytes:
    pcm = (np.clip(x, -1.0, 1.0) * 32767).astype("<i2")
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


def wav_to_mp3(wav_bytes: bytes, ffmpeg: str) -> Optional[bytes]:
    import shutil
    import subprocess
    import tempfile
    exe = ffmpeg or shutil.which("ffmpeg")
    if not exe:
        return None
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "in.wav")
        dst = os.path.join(td, "out.mp3")
        with open(src, "wb") as f:
            f.write(wav_bytes)
        try:
            subprocess.run([exe, "-y", "-loglevel", "error", "-i", src,
                            "-codec:a", "libmp3lame", "-b:a", "128k", dst],
                           check=True, timeout=120)
        except Exception:  # noqa: BLE001
            return None
        with open(dst, "rb") as f:
            return f.read()


# --------------------------------------------------------------------------- #
#  Эмо-движок
# --------------------------------------------------------------------------- #
def shift_pitch_level(level: str, steps: int) -> str:
    """Сдвинуть уровень SSML pitch на N шагов по списку, не выходя за границы."""
    if level not in SSML_PITCHES:
        return level            # например "robot" — не трогаем
    i = SSML_PITCHES.index(level) + steps
    return SSML_PITCHES[max(0, min(len(SSML_PITCHES) - 1, i))]


def shift_rate_level(level: str, steps: int) -> str:
    if level not in SSML_RATES:
        return level
    i = SSML_RATES.index(level) + steps
    return SSML_RATES[max(0, min(len(SSML_RATES) - 1, i))]


def split_sentences(text: str) -> list[str]:
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    parts = re.split(r"(?<=[.!?…])\s+", text)
    out = []
    for p in parts:
        p = p.strip()
        if len(p) > 240:                       # очень длинный кусок режем по запятым
            sub = re.split(r"(?<=,\s)", p)
            buf = ""
            for s in sub:
                if len(buf) + len(s) > 200 and buf:
                    out.append(buf.strip()); buf = s
                else:
                    buf += s
            if buf.strip():
                out.append(buf.strip())
        elif p:
            out.append(p)
    return out


def detect_emotion(sentence: str) -> str:
    """Определить эмоцию по фразе: сначала ключевые слова, потом пунктуация.

    ВАЖНО: сравнение идёт по ЦЕЛЫМ СЛОВАМ (и биграммам), а не по подстрокам.
    Прежняя версия искала подстроку в тексте и из-за этого ставила «shy»
    любому предложению со словом «даже» (входит в ключ «не знаю даже»).
    Одиночные слова-маркеры вроде «ой» при этом не дают ложных срабатываний,
    потому что «стой»/«мой» — это другие токены.
    """
    s = sentence.strip()
    if not s:
        return "neutral"
    low = s.lower().replace("ё", "е")
    toks = re.findall(r"[a-zа-я]+", low)
    wset = set(toks)
    bigrams = {f"{toks[i]} {toks[i + 1]}" for i in range(len(toks) - 1)}

    best, best_score = "neutral", 0
    for emo, cfg in EMOTIONS.items():
        score = 0
        for kw in cfg["keywords"]:
            parts = kw.lower().replace("ё", "е").split()
            if len(parts) == 1:
                if parts[0] in wset:
                    score += 2
            elif f"{parts[0]} {parts[-1]}" in bigrams:
                score += 3                       # фраза целиком, подряд
            elif all(w in wset for w in parts):
                score += 2                       # все слова фразы есть во фразе
        if score > best_score:
            best, best_score = emo, score
    if best_score:
        return best

    # пунктуация и регистр — только если ключевых слов не нашлось
    upper_words = re.findall(r"[А-ЯA-ZЁ]{3,}", s)
    excl, ques = s.count("!"), s.count("?")
    dots = s.count("...") + s.count("…")
    if upper_words or excl >= 2:
        return "excited"
    if excl == 1:
        return "joy"
    if dots:
        return "tease"
    if ques and len(s) < 60:
        return "surprise"
    return "neutral"


MAX_SAFE_SILERO_CHARS = 900   # сама Silero предупреждает и деградирует после 1000 символов
# Пиковая память Silero растёт с длительностью синтезируемого аудио, а не с числом
# символов как таковых: 350 символов (~40 c звука) на машине с 1 ГБ RAM убивали
# процесс OOM-killer'ом без единой строчки traceback. Поэтому кусок по умолчанию
# короткий (~13 c аудио) — это безопасно даже на очень тесном стенде.


def chunk_text(text: str, max_chars: int) -> list[str]:
    """Разрезать текст на куски не длиннее max_chars по границам предложений.

    Зачем: Silero v5 на тексте длиннее ~1000 символов печатает
    "UserWarning: Text string is longer than 1000 symbols" и расходует столько
    памяти, что процесс убивает OOM-killer (проверено: сервер падал на 4000 символов).
    Поэтому всё, что длиннее порога, синтезируется по кускам и склеивается.
    """
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]

    sentences = split_sentences(text)
    chunks: list[str] = []
    buf = ""
    for sent in sentences:
        while len(sent) > max_chars:          # одно огромное «предложение»
            cut = sent.rfind(",", 0, max_chars)
            if cut < max_chars // 2:
                cut = sent.rfind(" ", 0, max_chars)
            if cut <= 0:
                cut = max_chars
            piece, sent = sent[:cut].strip(), sent[cut:].strip()
            if buf and len(buf) + len(piece) + 1 > max_chars:
                chunks.append(buf)
                buf = piece
            else:
                buf = f"{buf} {piece}".strip()
        if not sent:
            continue
        if buf and len(buf) + len(sent) + 1 > max_chars:
            chunks.append(buf)
            buf = sent
        else:
            buf = f"{buf} {sent}".strip()
    if buf:
        chunks.append(buf)
    return chunks


XMLISH_RE = re.compile(r"<\s*/?\s*[a-zA-Z][^>]{0,80}>")


def sanitize_for_ssml(text: str) -> str:
    """Вычистить из текста конструкции, похожие на XML-теги, ДО экранирования.

    Silero парсит ssml_text как XML. Если в тексте встретится `<script>...</script>`
    или `</prosody>`, то даже после xml_escape парсер может вернуть None и синтез
    упадёт с "Failed to parse SSML". Проверял: экранирование в &lt;/&gt; от этого
    не спасает, поэтому подозрительные «теги» заменяются на их текстовое содержимое.
    Обычные скобки, кавычки, амперсанд и многоточия не затрагиваются.
    """
    if not text:
        return text
    cleaned = XMLISH_RE.sub(" ", text)
    cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
    return cleaned or text


def build_ssml(text: str, profile: dict, use_emotion: bool = True,
               jitter: bool = True, rng: random.Random | None = None,
               speed: float = 1.0) -> tuple[str, list[dict]]:
    """Собрать SSML из текста: теги эмоций -> prosody/break по каждой фразе."""
    rng = rng or random
    trace: list[dict] = []

    # --- разбираем явные теги [emotion] ---
    tagged: list[tuple[Optional[str], str]] = []
    pos = 0
    current_tag: Optional[str] = None
    for m in TAG_RE.finditer(text):
        name = m.group(1).lower()
        if name in EMOTIONS:
            chunk = text[pos:m.start()]
            if chunk.strip():
                tagged.append((current_tag, chunk.strip()))
            current_tag = name
            pos = m.end()
    tail = text[pos:]
    if tail.strip():
        tagged.append((current_tag, tail.strip()))
    if not tagged:
        tagged = [(None, text)]

    pieces: list[str] = []
    for forced, chunk in tagged:
        for sentence in split_sentences(chunk):
            emo = forced if forced else (detect_emotion(sentence) if use_emotion else "neutral")
            if emo not in EMOTIONS:
                emo = "neutral"
            cfg = EMOTIONS[emo]

            pitch = cfg.get("force_pitch") or shift_pitch_level(profile["pitch"], cfg["pitch_shift"])
            rate = shift_rate_level(profile["rate"], SSML_RATES.index(cfg["rate"]) - 2)

            # микро-вариативность: ±1 шаг rate в пределах ±1, изредка ±1 pitch
            if jitter:
                # намеренно НЕ трогаем крайние уровни: x-slow и x-fast отличаются
                # от medium в 1.9 и 1.45 раза, прыжок туда делает речь нестабильной
                if rng.random() < 0.5 and rate in ("slow", "medium", "fast"):
                    rate = shift_rate_level(rate, rng.choice([-1, 1]))
                if rng.random() < 0.12 and pitch in ("low", "medium", "high"):
                    pitch = shift_pitch_level(pitch, rng.choice([-1, 1]))

            inner = xml_escape(sanitize_for_ssml(sentence))
            lead = cfg["lead_break"]
            tailb = cfg["tail_break"]
            if jitter:
                lead = max(0, int(lead * rng.uniform(0.7, 1.3)))
                tailb = max(40, int(tailb * rng.uniform(0.75, 1.25)))

            seg = ""
            if lead:
                seg += f'<break time="{lead}ms"/>'
            seg += f'<prosody pitch="{pitch}" rate="{rate}">{inner}</prosody>'
            if tailb:
                seg += f'<break time="{tailb}ms"/>'
            pieces.append(seg)
            trace.append({"sentence": sentence[:70], "emotion": emo,
                          "pitch": pitch, "rate": rate,
                          "lead_ms": lead, "tail_ms": tailb})

    # компенсация параметра speed из запроса: сдвигаем общий уровень rate
    if abs(speed - 1.0) > 0.02:
        # speed>1 => речь БЫСТРЕЕ => уровень rate выше. Прежняя версия двигала
        # уровень в обратную сторону (speed=1.2 замедлял речь) — исправлено.
        steps = int(round(math.log(max(speed, 0.25)) / math.log(1.35)))
        pieces = [re.sub(r'rate="([a-z\-]+)"',
                         lambda m: 'rate="%s"' % shift_rate_level(m.group(1), steps),
                         p) for p in pieces]

    body = "".join(pieces)
    # <break time="240ms"/><break time="130ms"/>  ->  <break time="370ms"/>
    def _merge(m):
        a, b = int(m.group(1)), int(m.group(2))
        return f'<break time="{min(a + b, 1200)}ms"/>'
    for _ in range(3):
        new_body = re.sub(r'<break time="(\d+)ms"/>\s*<break time="(\d+)ms"/>', _merge, body)
        if new_body == body:
            break
        body = new_body
    ssml = "<speak>" + body + "</speak>"
    return ssml, trace


# --------------------------------------------------------------------------- #
#  HTTP API
# --------------------------------------------------------------------------- #
class SpeechRequest(BaseModel):
    model: str = MODEL_ID
    voice: str = "baya"
    input: str = Field(..., description="текст для озвучки")
    response_format: str = "wav"
    speed: float = 1.0
    emotion: Optional[str] = Field(None, description="принудительная эмоция для всего текста")
    ssml: Optional[bool] = Field(None, description="false = отключить эмо-движок")


def resolve_voice(name: str) -> tuple[str, dict]:
    if name in VOICES:
        return name, VOICES[name]
    if name in LEGACY_ALIASES:
        real = LEGACY_ALIASES[name]
        return real, VOICES[real]
    if name in ("aidar", "baya", "kseniya", "eugene", "xenia"):
        return name, _p(name, "medium", "medium", 0,
                        "male" if name in ("aidar", "eugene") else "female", "чистый голос Silero")
    raise KeyError(name)


def build_app(args: argparse.Namespace) -> FastAPI:
    app = FastAPI(title="Silero OpenAI-compatible TTS (emotional)", version="2.0.0")

    @app.get("/health")
    def health() -> JSONResponse:
        return JSONResponse({
            "status": "ok" if STATE["model"] is not None else "no-model",
            "model": MODEL_ID,
            "voices": sorted(VOICES),
            "emotions": sorted(EMOTIONS),
            "ssml_pitch_levels": SSML_PITCHES,
            "ssml_rate_levels": SSML_RATES,
            "emotion_engine": bool(args.emotion and not args.no_emotion),
            "jitter": bool(args.jitter and not args.no_jitter),
            "translit": not args.no_translit,
            "unreadable_fallback": UNREADABLE_FALLBACK,
            "stress_map": STRESS_MAP,
            "requests": STATE["requests"],
            "audio_seconds": round(STATE["audio_seconds"], 1),
            "synth_seconds": round(STATE["synth_seconds"], 2),
            "rtf_avg": round(STATE["synth_seconds"] / STATE["audio_seconds"], 4)
            if STATE["audio_seconds"] else None,
            "emotion_hits": STATE["emotion_hits"],
            "threads": torch.get_num_threads(),
        })

    @app.get("/v1/models")
    def models() -> JSONResponse:
        return JSONResponse({"object": "list",
                             "data": [{"id": MODEL_ID, "object": "model", "owned_by": "silero"}]})

    @app.get("/v1/voices")
    def voices() -> JSONResponse:
        return JSONResponse({"voices": [{"voice_id": k, **v} for k, v in VOICES.items()],
                             "emotions": [{"id": k, **{kk: vv for kk, vv in v.items()
                                                       if kk != "keywords"}}
                                          for k, v in EMOTIONS.items()],
                             "legacy_aliases": LEGACY_ALIASES})

    @app.post("/v1/audio/speech")
    def speech(req: SpeechRequest) -> Response:
        if STATE["model"] is None:
            raise HTTPException(status_code=503, detail="модель ещё не загружена")
        text = (req.input or "").strip()
        if not text:
            raise HTTPException(status_code=400, detail="пустой input")
        if len(text) > args.max_input_chars:
            raise HTTPException(
                status_code=413,
                detail=f"текст {len(text)} символов длиннее лимита {args.max_input_chars}. "
                       f"Open-LLM-VTuber и так шлёт текст по предложениям; лимит можно "
                       f"поднять параметром --max-input-chars")

        try:
            voice_name, profile = resolve_voice(req.voice)
        except KeyError:
            raise HTTPException(
                status_code=400,
                detail=f"неизвестный voice '{req.voice}'. Доступны: {', '.join(sorted(VOICES))}")

        sr = args.sample_rate
        # принудительные ударения — только для синтеза (субтитры проект рисует сам)
        text = apply_stress(text)
        # Silero v5_5_ru не читает текст без кириллицы (голый ValueError -> 500)
        # и молча проглатывает латиницу в смешанном тексте — см. ensure_pronounceable
        text, prep_mode = ensure_pronounceable(text, translit=not args.no_translit)
        if prep_mode == "translit":
            print(f"[i] латиница транслитерирована в кириллицу (ru-пак Silero не читает "
                  f"латиницу): {text[:80]!r}")
        elif prep_mode == "fallback":
            print(f"[i] в тексте нет ни кириллицы, ни латиницы (цифры/символы/эмодзи) — "
                  f"озвучена запасная фраза {UNREADABLE_FALLBACK!r}")
        use_emotion = bool(args.emotion and not args.no_emotion) and (req.ssml is not False)
        rng = random.Random() if args.jitter_seed <= 0 else random.Random(args.jitter_seed)

        if use_emotion:
            if req.emotion and req.emotion in EMOTIONS:
                # принудительная эмоция: ставим тег в начало текста
                text = f"[{req.emotion}] {text}"
            ssml_text, trace = build_ssml(text, profile, use_emotion=True,
                                          jitter=bool(args.jitter and not args.no_jitter),
                                          rng=rng,
                                          speed=req.speed or 1.0)
            for t in trace:
                STATE["emotion_hits"][t["emotion"]] = STATE["emotion_hits"].get(t["emotion"], 0) + 1
            if args.debug:
                print(f"[ssml] voice={voice_name} фраз={len(trace)}")
                for t in trace:
                    print(f"       {t['emotion']:9s} pitch={t['pitch']:7s} rate={t['rate']:8s} "
                          f"break {t['lead_ms']}/{t['tail_ms']} мс | {t['sentence']!r}")
        else:
            ssml_text, trace = None, []

        n_chunks = len(chunk_text(text, args.max_chunk_chars))
        if n_chunks > 1:
            print(f"[i] текст {len(text)} симв. -> синтез из {n_chunks} куск(ов/а) "
                  f"по <= {args.max_chunk_chars} симв. (ограничение пиковой памяти)")

        # если после разбора не осталось ни одной фразы (текст целиком состоял из
        # «тегов»), озвучиваем исходный текст как есть — молчание хуже
        if use_emotion and not [p for p in (ssml_text or "").split("<prosody") if p.strip()][1:]:
            ssml_text, trace = None, []

        t0 = time.time()
        t_synth = 0.0
        cur_chunk = text[:80]
        try:
            pieces_audio = []
            for chunk in chunk_text(text, args.max_chunk_chars):
                cur_chunk = chunk
                if ssml_text is not None:
                    part_ssml, part_trace = build_ssml(
                        chunk, profile, use_emotion=use_emotion,
                        jitter=not args.no_jitter, rng=rng, speed=req.speed or 1.0)
                    if args.debug:
                        for t in part_trace:
                            print(f"       {t['emotion']:9s} pitch={t['pitch']:7s} "
                                  f"rate={t['rate']:8s} | {t['sentence']!r}")
                else:
                    part_ssml, part_trace = None, []
                tc = time.time()
                if part_ssml:
                    pieces_audio.append(synth(ssml_text=part_ssml,
                                              speaker=profile["speaker"], sample_rate=sr))
                else:
                    pieces_audio.append(synth(text=chunk, speaker=profile["speaker"],
                                              sample_rate=sr))
                t_synth += time.time() - tc
                del part_ssml, part_trace
                # длинный текст = много проходов модели; без явной очистки пиковое
                # потребление памяти растёт и процесс может убить OOM-killer
                gc.collect()
            if not pieces_audio:
                raise ValueError("из текста не получилось ни одного фрагмента")
            x = (np.concatenate(pieces_audio) if len(pieces_audio) > 1
                 else pieces_audio[0])
        except Exception as e:  # noqa: BLE001
            # Синтез может упасть на тексте, который парсер Silero не переварил
            # (например, SSML-разметка). Молчание хуже, поэтому пробуем ещё раз
            # обычным текстом без разметки. ВАЖНО: у некоторых ошибок Silero
            # пустое сообщение (голый ValueError на тексте без кириллицы) —
            # поэтому в лог и в detail всегда пишем тип исключения и сам текст.
            err1 = str(e) or "<без сообщения>"
            print(f"[!] синтез не удался ({type(e).__name__}: {err1[:120]}; "
                  f"текст: {cur_chunk[:60]!r}) — пробую обычным текстом без разметки")
            try:
                pieces_audio = []
                for chunk in chunk_text(re.sub(r"<[^>]{1,80}>", " ", text),
                                        args.max_chunk_chars):
                    cur_chunk = chunk
                    tc = time.time()
                    pieces_audio.append(synth(text=chunk, speaker=profile["speaker"],
                                              sample_rate=sr))
                    t_synth += time.time() - tc
                x = (np.concatenate(pieces_audio) if len(pieces_audio) > 1
                     else pieces_audio[0])
            except Exception as e2:  # noqa: BLE001
                err2 = str(e2) or "<без сообщения>"
                raise HTTPException(
                    status_code=500,
                    detail=f"ошибка синтеза ({type(e2).__name__}): {err2}; "
                           f"текст: {cur_chunk[:80]!r}") from e2
        dur = len(x) / float(sr)

        cs = float(profile.get("chipmunk_st", 0.0))
        if cs:
            x = chipmunk(x, cs)
        x = normalize(x)
        dur_final = len(x) / float(sr)

        STATE["requests"] += 1
        STATE["audio_seconds"] += dur_final
        STATE["synth_seconds"] += t_synth
        rtf_hdr = f"{t_synth / max(dur, 1e-6):.4f}"

        fmt = (req.response_format or "wav").lower()
        wav_bytes = to_wav_bytes(x, sr)
        if fmt == "mp3":
            mp3 = wav_to_mp3(wav_bytes, args.ffmpeg)
            if mp3 is not None:
                return Response(content=mp3, media_type="audio/mpeg",
                                headers={"X-Silero-RTF": rtf_hdr})
            print("[!] запросили mp3, но ffmpeg недоступен — отдаю wav")
        return Response(content=wav_bytes, media_type="audio/wav",
                        headers={"X-Silero-RTF": rtf_hdr,
                                 "X-Silero-Voice": voice_name,
                                 "X-Silero-Emotions": ",".join(t["emotion"] for t in trace)})

    return app



# --------------------------------------------------------------------------- #
#  Демо-режим: нагенерировать сэмплы и выйти (без запуска HTTP-сервера)
# --------------------------------------------------------------------------- #
DEMO_TEXTS = [
    ("neutral",  "Сегодня вторник. Мы планировали разобраться с настройками, и вот мы здесь."),
    ("joy",      "[joy] Ура, получилось! Я так рада, что всё заработало."),
    ("excited",  "[excited] Да ладно! Серьёзно? Ну ты даёшь, я в восторге!"),
    ("surprise", "[surprise] Что? Правда? Я вообще не это ожидала услышать."),
    ("tease",    "[tease] Хм... а вот это уже интересно. Ну-ну, расскажи ещё."),
    ("sarcastic", "[sarcastic] Конечно, как скажешь. Гениальная идея, просто браво."),
    ("sad",      "[sad] Жаль, но сегодня не выйдет. Обидно, честно говоря."),
    ("angry",    "[angry] Хватит уже это делать! Достало, серьёзно."),
    ("shy",      "[shy] Ой... ну я не знаю даже. Ты меня смущаешь."),
    ("sleepy",   "[sleepy] Я уже засыпаю... давай завтра продолжим, а?"),
    ("robot",    "[robot] Системы в норме. Реактор стабилен. Привет, человек."),
]


def run_demo(args: argparse.Namespace) -> int:
    out = args.demo_dir
    os.makedirs(out, exist_ok=True)
    sr = args.sample_rate
    voice = args.demo_voice
    try:
        vname, profile = resolve_voice(voice)
    except KeyError:
        print(f"[xx] нет голоса '{voice}'. Доступны: {', '.join(sorted(VOICES))}")
        return 1

    print("=" * 72)
    print(f" ДЕМО: голос {vname} (speaker={profile['speaker']}, base pitch={profile['pitch']})")
    print(f" sample_rate={sr}  emotion={'ВКЛ' if not args.no_emotion else 'ВЫКЛ'}"
          f"  jitter={'ВКЛ' if not args.no_jitter else 'ВЫКЛ'}")
    print(f" папка: {os.path.abspath(out)}")
    print("=" * 72)

    rows = []
    # 1) одна и та же фраза с эмо-движком и без — прямое сравнение
    cmp_text = "Ну ты даёшь! Я такого вообще не ожидала. Хм... расскажешь, что случилось?"
    for label, emo_on in (("emo-off", False), ("emo-on", True)):
        t0 = time.time()
        if emo_on and not args.no_emotion:
            ssml_text, trace = build_ssml(cmp_text, profile, jitter=not args.no_jitter,
                                          rng=random.Random(42))
            x = synth(ssml_text=ssml_text, speaker=profile["speaker"], sample_rate=sr)
        else:
            trace = []
            x = synth(text=cmp_text, speaker=profile["speaker"], sample_rate=sr)
        if profile.get("chipmunk_st"):
            x = chipmunk(x, profile["chipmunk_st"])
        x = normalize(x)
        name = f"compare_{label}.wav"
        with wave.open(os.path.join(out, name), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
            w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
        dt = time.time() - t0
        dur = len(x) / sr
        rows.append((name, dt, dur))
        emos = ",".join(t["emotion"] for t in trace) or "-"
        print(f"  [{label:8s}] {dt:5.2f} c -> {dur:5.2f} c аудио  RTF {dt/dur:.3f}  эмоции: {emos}")

    # 2) все эмоции
    print()
    for emo, text in DEMO_TEXTS:
        t0 = time.time()
        ssml_text, trace = build_ssml(text, profile, use_emotion=not args.no_emotion,
                                      jitter=not args.no_jitter, rng=random.Random(7))
        x = synth(ssml_text=ssml_text, speaker=profile["speaker"], sample_rate=sr)
        if profile.get("chipmunk_st"):
            x = chipmunk(x, profile["chipmunk_st"])
        x = normalize(x)
        name = f"emo_{emo}.wav"
        with wave.open(os.path.join(out, name), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
            w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
        dt = time.time() - t0
        dur = len(x) / sr
        rows.append((name, dt, dur))
        got = trace[0]["emotion"] if trace else "?"
        pit = trace[0]["pitch"] if trace else "-"
        rat = trace[0]["rate"] if trace else "-"
        print(f"  [{emo:10s}] {dt:5.2f} c -> {dur:5.2f} c  RTF {dt/dur:.3f}  "
              f"определено={got:10s} pitch={pit:7s} rate={rat}")

    total_synth = sum(r[1] for r in rows)
    total_audio = sum(r[2] for r in rows)
    print()
    print(f"  ИТОГО: {len(rows)} файлов, {total_synth:.2f} c синтеза на {total_audio:.2f} c аудио"
          f"  -> средний RTF {total_synth/total_audio:.4f}")
    print(f"  Папка: {os.path.abspath(out)}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Silero v5 as an OpenAI-compatible emotional TTS server")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8880)
    ap.add_argument("--speaker-id", default="v5_5_ru",
                    help="ID модели Silero: v5_5_ru (рекомендуется), v5_ru, v5_4_ru")
    ap.add_argument("--sample-rate", type=int, default=48000, choices=[8000, 24000, 48000])
    ap.add_argument("--threads", type=int, default=0, help="потоков torch (0 = авто)")
    ap.add_argument("--ffmpeg", default="", help="путь к ffmpeg, если нужен mp3")
    ap.add_argument("--warmup", action="store_true")
    # Эмо-движок ВЫКЛЮЧЕН по умолчанию: владельцу проекта чистая подача baya
    # понравилась больше. Включается флагом --emotion (и --jitter к нему).
    ap.add_argument("--emotion", action="store_true",
                    help="включить эмо-движок (подбор pitch/rate/пауз по тексту). "
                         "По умолчанию ВЫКЛЮЧЕН")
    ap.add_argument("--jitter", action="store_true",
                    help="включить микро-вариативность подачи (работает только с --emotion)")
    ap.add_argument("--no-emotion", action="store_true",
                    help="(устаревший флаг, теперь это поведение по умолчанию)")
    ap.add_argument("--no-jitter", action="store_true",
                    help="(устаревший флаг, теперь это поведение по умолчанию)")
    ap.add_argument("--jitter-seed", type=int, default=0,
                    help="фиксировать seed микро-вариативности (0 = случайный)")
    ap.add_argument("--debug", action="store_true", help="печатать разбор эмоций и SSML")
    ap.add_argument("--stress", action="append", default=[], metavar="СЛОВО=СЛ+ОВО",
                    help="дополнить карту произношения, можно несколько раз. "
                         'Пример: --stress "Legion=Л+егион". По умолчанию уже задано '
                         '"Карен=К+арэн" (подобрано замерами длительности гласных)')
    ap.add_argument("--no-stress", action="store_true",
                    help="очистить карту произношения и озвучивать текст как написан")
    ap.add_argument("--no-translit", action="store_true",
                    help="не транслитерировать латиницу в кириллицу. Silero v5_5_ru "
                         "не читает чистую латиницу (голый ValueError) и молча "
                         "проглатывает её в смешанном тексте; защита от падения "
                         "(запасная фраза) остаётся и с этим флагом")
    ap.add_argument("--max-input-chars", type=int, default=600,
                    help="жёсткий лимит длины входного текста (413 при превышении)")
    ap.add_argument("--max-chunk-chars", type=int, default=130,
                    help="длина куска при синтезе. ВАЖНО: Silero синтезирует кусок ЦЕЛИКОМ "
                         "и держит его в памяти, поэтому пиковое потребление растёт с "
                         "ДЛИТЕЛЬНОСТЬЮ аудио (~130 символов = ~13 c = безопасно даже "
                         "на машине с 1 ГБ RAM). Open-LLM-VTuber и так шлёт текст по "
                         "предложениям, так что в обычном режиме это не используется")
    ap.add_argument("--demo", action="store_true",
                    help="нагенерировать демо-сэмплы и выйти (сервер не запускается)")
    ap.add_argument("--demo-voice", default="baya")
    ap.add_argument("--demo-dir", default="demo_audio")
    args = ap.parse_args()

    if args.threads > 0:
        torch.set_num_threads(args.threads)

    print("=" * 72)
    print(" Silero TTS -> OpenAI-compatible endpoint  (emotional prosody, v2)")
    print("=" * 72)
    print(f" model id      : {MODEL_ID}")
    print(f" speaker pack  : {args.speaker_id}")
    print(f" sample rate   : {args.sample_rate}")
    print(f" torch threads : {torch.get_num_threads()}")
    _emo = bool(args.emotion and not args.no_emotion)
    _jit = bool(args.jitter and not args.no_jitter)
    print(f" emotion engine: {'ВКЛ' if _emo else 'ВЫКЛ (по умолчанию)'}"
          f"   флаг --emotion включает {len(EMOTIONS)} эмоций")
    print(f" jitter        : {'ВКЛ' if _jit else 'ВЫКЛ (по умолчанию)'}   флаг --jitter")
    if not _emo:
        print(" подача        : ровная, текст озвучивается как есть (без SSML-просодии)")
    print(f" voices        : {', '.join(sorted(VOICES))}")
    print(f" произношение  : {STRESS_MAP if STRESS_MAP else 'как написано (авто)'}")
    print(f" транслит      : {'ВКЛ (латиница -> кириллица; ru-пак не читает латиницу)' if not args.no_translit else 'ВЫКЛ (--no-translit; защита запасной фразой остаётся)'}")
    print(f" endpoint      : http://{args.host}:{args.port}/v1/audio/speech")
    print("=" * 72)

    if args.no_stress:
        STRESS_MAP.clear()
    for item in args.stress:
        if "=" not in item:
            print(f"[!] --stress '{item}' без '=' — пропущено (нужно вида Слово=Сл+ово)")
            continue
        plain, marked = item.split("=", 1)
        plain, marked = plain.strip(), marked.strip()
        if plain and marked:
            STRESS_MAP[plain] = marked
    if STRESS_MAP:
        print("[i] карта произношения (только для синтеза, субтитры не затрагивает):")
        for k, v in STRESS_MAP.items():
            tag = " (по умолчанию)" if DEFAULT_STRESS_MAP.get(k) == v else ""
            print(f"      {k!r} -> {v!r}{tag}")
    else:
        print("[i] карта произношения пуста (--no-stress)")

    load_model(args.speaker_id, args.threads or 4)
    STATE["loaded_at"] = time.time()
    STATE["args"] = args

    if args.demo:
        return run_demo(args)

    if args.warmup:
        print("[i] прогрев (обычный текст + латиница + SSML + эмоции) ...")
        t0 = time.time()
        prof = VOICES["baya"]
        synth(text="Проверка связи.", speaker=prof["speaker"], sample_rate=args.sample_rate)
        # регресс-проверка бага 2026-09-21: чистая латиница роняла Silero v5_5_ru
        # голым ValueError. Прогоняем её через ensure_pronounceable, как в HTTP-хендлере.
        _lat, _mode = ensure_pronounceable("Connection check.", translit=not args.no_translit)
        synth(text=_lat, speaker=prof["speaker"], sample_rate=args.sample_rate)
        print(f"[i] прогрев латиницы: 'Connection check.' -> {_lat!r} (режим: {_mode or 'как есть'})")
        if args.emotion:
            s, _ = build_ssml("Проверка связи. [joy] Всё работает!", prof, jitter=False)
            synth(ssml_text=s, speaker=prof["speaker"], sample_rate=args.sample_rate)
        print(f"[ok] прогрето за {time.time() - t0:.2f} c")

    uvicorn.run(build_app(args), host=args.host, port=args.port, log_level="info")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
