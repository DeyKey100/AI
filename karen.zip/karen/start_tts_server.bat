@echo off
REM =====================================================================
REM  KAREN Voice - Silero TTS server (OpenAI-compatible) for the KAREN
REM  project on top of Open-LLM-VTuber.
REM  Starts the local Russian voice on http://127.0.0.1:8880
REM
REM  Two ways to run it:
REM   a) DOUBLE-CLICK this file -> visible window, errors are readable.
REM      Use this to debug. Keep the window open while talking.
REM   b) start_karen.bat / start_vtuber.bat run it HIDDEN (no taskbar
REM      button) with all output in karen\logs\tts.log. They also set
REM      KAREN_HIDDEN=1, which this file uses to (a) skip `pause` - an
REM      invisible window waiting for a keypress would leave a zombie
REM      cmd.exe forever - and (b) force UTF-8 for Python output.
REM
REM  ENCODING NOTE (the 2026-09-21 crash): when stdout is redirected to a
REM  file, Python uses the locale codepage cp1251 and a single character
REM  outside it (the arrow in the old banner) raised UnicodeEncodeError,
REM  killing the server silently. Fixed twice over: PYTHONIOENCODING=utf-8
REM  below + the stdio guard inside silero_openai_tts_server.py.
REM
REM  This .bat itself is ASCII-only: cmd.exe decodes batch files in the
REM  OEM codepage (CP866 on Russian Windows), so UTF-8 Cyrillic comments
REM  here would turn into mojibake or break parsing.
REM =====================================================================
setlocal
title KAREN Voice :8880

set "HERE=%~dp0"
set "LAB=%HERE%"
if exist "%HERE%..\karen\" set "LAB=%HERE%..\karen\"
if exist "%HERE%..\..\karen\" set "LAB=%HERE%..\..\karen\"
set "VENV=%LAB%tts\.venv-silero"
set "SERVER=%LAB%tts\silero_openai_tts_server.py"

REM Only when hidden: stdout is a file, so UTF-8 is the right encoding.
REM In a visible window we deliberately do NOT touch it - the console
REM codepage (866) renders Cyrillic correctly, and the stdio guard inside
REM the server picks the encoding itself (isatty -> console, else UTF-8).
REM PYTHONUTF8 is NOT set on purpose: it would also change open() defaults.
if "%KAREN_HIDDEN%"=="1" set "PYTHONIOENCODING=utf-8"

echo [%date% %time%] start_tts_server.bat launched  ^(hidden=%KAREN_HIDDEN%^)

if not exist "%SERVER%" (
    echo [xx] Not found: %SERVER%
    echo      Keep this .bat inside the karen folder and run it from there.
    goto :end_fail
)

REM ---- create the TTS environment on first run ------------------------
if not exist "%VENV%\Scripts\python.exe" (
    echo [..] Creating a separate venv for the voice: %VENV%
    py -3.11 -m venv "%VENV%" 2>nul
    if not exist "%VENV%\Scripts\python.exe" python -m venv "%VENV%" 2>nul
    if not exist "%VENV%\Scripts\python.exe" (
        where uv >nul 2>nul
        if errorlevel 1 (
            echo [xx] Cannot create the venv. Install Python 3.10-3.12 and retry.
            goto :end_fail
        )
        echo [..] python not found - trying uv venv
        uv venv "%VENV%" --python 3.11
        REM uv venv has no pip inside; pip is used below, so bootstrap it
        if exist "%VENV%\Scripts\python.exe" uv pip install --python "%VENV%\Scripts\python.exe" pip
    )
    if not exist "%VENV%\Scripts\python.exe" (
        echo [xx] Cannot create the venv.
        goto :end_fail
    )
    echo [..] Installing CPU torch + silero + fastapi (one-time, about 2 GB)
    "%VENV%\Scripts\python.exe" -m pip install --upgrade pip
    "%VENV%\Scripts\python.exe" -m pip install torch --index-url https://download.pytorch.org/whl/cpu
    "%VENV%\Scripts\python.exe" -m pip install silero fastapi "uvicorn[standard]" scipy
    if errorlevel 1 (
        echo [xx] Dependency installation failed.
        goto :end_fail
    )
)

echo.
echo ====================================================================
echo  KAREN Voice - Silero TTS server on http://127.0.0.1:8880
echo  speaker profile : baya    (flat delivery, emotion engine OFF)
echo  name stress     : Karen -^> K+aren  (built in, stress on 1st syllable,
echo                    confirmed by ear: audio\names\02_FIXED_marker_a.wav)
if "%KAREN_HIDDEN%"=="1" (
    echo  running HIDDEN. Stop it with: stop_karen.bat
) else (
    echo  stop with Ctrl+C. KEEP THIS WINDOW OPEN.
)
echo ====================================================================
echo.

REM  ---------------------------------------------------------------------
REM  Optional flags - append them to the python line below:
REM    --emotion --jitter            emotional delivery (11 emotions)
REM    --no-stress                   disable the Karen -^> K+aren mapping
REM    --stress "Legion=L+egion"     add your own pronunciation (repeatable)
REM    --threads 6                   torch threads (4-6 is sane on i7-13620H)
REM
REM  Voice profile is NOT changed here - edit conf.yaml instead:
REM    character_config.tts_config.openai_tts.voice
REM  Profile list : curl http://127.0.0.1:8880/v1/voices
REM  Current map  : curl http://127.0.0.1:8880/health   (stress_map field)
REM  ---------------------------------------------------------------------

"%VENV%\Scripts\python.exe" "%SERVER%" --host 127.0.0.1 --port 8880 --sample-rate 48000 --threads 4 --warmup
set "EC=%errorlevel%"
echo.
echo [%date% %time%] python exited with code %EC%
if not "%EC%"=="0" (
    echo [xx] Voice server EXITED unexpectedly ^(code %EC%^).
    echo      Read the lines above - that is the reason.
    echo      If it mentions a module: delete %VENV% and run this file again.
)
if "%KAREN_HIDDEN%"=="1" exit /b %EC%

:end_fail
if "%KAREN_HIDDEN%"=="1" exit /b 1
pause
exit /b 0
