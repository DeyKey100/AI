#!/usr/bin/env python3
"""
Диагностика Groq API для проекта «Локальный AI VTuber-компаньон».
Замена test_official.py из технического паспорта: больше проверок, человекочитаемый отчёт,
учёт реальных лимитов аккаунта и явная обработка Cloudflare 1010.

Запуск:
    uv run python scripts/test_groq_api.py            (из корня Open-LLM-VTuber)
    python test_groq_api.py                           (везде, где стоит groq SDK)

Ключ берётся только из переменной окружения GROQ_API_KEY (в файле не хранится).

Что проверяется:
  1. Cloudflare / связность (и отдельно — почему голый urllib получает 1010)
  2. Валидность ключа + список доступных моделей
  3. Наличие целевой модели qwen/qwen3.8-27b
  4. Диалог на русском (латентность, токены, скорость)
  5. Стриминг (время до первого токена — ключевая метрика для голосового компаньона)
  6. Реальные rate-limit заголовки и суточный бюджет
  7. Проверка ограничения OTPM (почему max_tokens=1024 ломается на free-тарифе)
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

MODEL = os.getenv("VTUBER_LLM_MODEL", "qwen/qwen3.8-27b")
BASE = "https://api.groq.com/openai/v1"

SYSTEM_PROMPT = (
    "Ты — игривый AI VTuber-компаньон. Отвечай коротко, живо и по-русски. "
    "Без эмодзи и без markdown — твой ответ озвучивается синтезатором речи."
)

GREEN, RED, YELL, DIM, RESET = "\033[92m", "\033[91m", "\033[93m", "\033[2m", "\033[0m"
if not sys.stdout.isatty():
    # лог-файлы не должны содержать ANSI-последовательности (скрытый запуск)
    GREEN = RED = YELL = DIM = RESET = ""

BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")


def ok(msg: str) -> None:
    print(f"  {GREEN}[ok]{RESET} {msg}")


def bad(msg: str) -> None:
    print(f"  {RED}[FAIL]{RESET} {msg}")


def warn(msg: str) -> None:
    print(f"  {YELL}[!!]{RESET} {msg}")


def note(msg: str) -> None:
    print(f"  {DIM}{msg}{RESET}")


def header(n: str, title: str) -> None:
    print(f"\n{n}  {title}\n" + "-" * 68)


# ---------------------------------------------------------------------------
#  Быстрая диагностика (--quick): только stdlib, ~10 секунд.
#  Появилась 2026-09-21 после бага «403 Forbidden» на машине владельца:
#  бэкенд на каждый запрос отвечал «Error calling the chat endpoint», а
#  причина (IP/ключ/модель) была видна только в глубине логов.
# ---------------------------------------------------------------------------
def http_json(url: str, api_key: str = "", data: bytes | None = None,
              timeout: int = 15) -> tuple[int, str]:
    """(status, тело). status=0 означает сетевую ошибку (нет связи/VPN)."""
    headers = {"User-Agent": BROWSER_UA, "Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urllib.request.Request(url, headers=headers, data=data)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode(errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read(400).decode(errors="replace")
    except Exception as e:  # noqa: BLE001
        return 0, f"{type(e).__name__}: {e}"


def fetch_exit_info() -> tuple[str, str]:
    """(IP, код страны), под которыми нас видит интернет. ('?','?') при неудаче."""
    try:
        status, body = http_json("http://ip-api.com/line/?fields=query,countryCode",
                                 timeout=8)
        if status == 200:
            lines = [l.strip() for l in body.splitlines() if l.strip()]
            # порядок полей в ответе /line/ не гарантирован — распознаём сами:
            # IP содержит точки/двоеточия, страна — ровно две заглавные буквы
            ip = next((l for l in lines if re.fullmatch(r"[\d.]+|[\da-fA-F:]+", l)), "?")
            country = next((l for l in lines if re.fullmatch(r"[A-Z]{2}", l)), "?")
            if ip != "?":
                return ip, country
    except Exception:  # noqa: BLE001
        pass
    try:
        status, body = http_json("https://api.ipify.org?format=json", timeout=8)
        if status == 200:
            return json.loads(body).get("ip", "?"), "?"
    except Exception:  # noqa: BLE001
        pass
    return "?", "?"


def diagnose_status(status: int, body: str, country: str) -> None:
    """Человекочитаемый вердикт по коду ответа Groq + план действий."""
    if status == 0:
        bad(f"СЕТЬ НЕДОСТУПНА: {body[:150]}")
        note("Включите VPN (Karing) и повторите. Если VPN включён — проверьте,")
        note("что туннель вообще поднят (значок Karing в трее, режим TUN).")
        return
    if status == 401:
        bad("401 — ключ НЕДЕЙСТВИТЕЛЕН (отозван, удалён или опечатка в setx).")
        note("1) Создайте новый ключ: https://console.groq.com/keys")
        note('2) setx GROQ_API_KEY "gsk_..."  -> откройте НОВЫЙ терминал')
        note("3) Перезапустите Карен (stop_karen.bat -> start_karen.bat).")
        return
    if status == 403:
        bad("403 Forbidden — запрос ЗАПРЕЩЁН. Это НЕ ошибка ключа (та была бы 401):")
        bad("Groq блокирует запрос по IP-адресу/стране или по аккаунту.")
        if country == "RU":
            note(f"Ваш выходной IP сейчас в стране {country} — трафик до api.groq.com")
            note("идёт МИМО VPN. В Karing включите глобальный режим/TUN или добавьте")
            note("api.groq.com в правила проксирования, затем повторите проверку.")
        else:
            note(f"Выходной IP: страна {country}. Значит, сам exit-узел VPN в")
            note("блоклисте Groq (часто — дешёвые/датацентровые IP). Действия:")
            note("1) В Karing выберите ДРУГОЙ узел/страну (DE, NL, FI, PL, US...)")
            note("   и повторите: python scripts\\test_groq_api.py --quick")
            note("2) Если 403 на всех узлах — блокировка на уровне аккаунта/ключа:")
            note("   пересоздайте ключ на https://console.groq.com/keys при")
            note("   ВКЛЮЧЁННОМ VPN и обновите setx GROQ_API_KEY.")
        note("Ответ сервера: " + body[:160].replace("\n", " "))
        return
    if status == 404:
        bad("404 — модель не найдена: её сняли с Groq или опечатка в имени.")
        note(f"Текущая модель: {MODEL}. Список доступных: GET {BASE}/models")
        note("Обновите model в Open-LLM-VTuber/conf.yaml (секция llm).")
        return
    if status == 429:
        bad("429 — упёрлись в лимиты free-тарифа (RPD/TPM/OTPM).")
        note("Подождите сброса (минутный/суточный) или реже прерывайте Карен.")
        return
    bad(f"HTTP {status} — {body[:200]}")


def run_quick() -> int:
    """--quick: ключ -> выходной IP -> /models -> chat. Только stdlib."""
    print("=" * 68)
    print(" Groq quick-check  (ключ -> выходной IP -> модели -> чат)")
    print("=" * 68)
    api_key = os.getenv("GROQ_API_KEY", "").strip()
    if not api_key:
        bad('GROQ_API_KEY не задан. Лечение: setx GROQ_API_KEY "gsk_..." + новый терминал.')
        return 1
    ok(f"ключ из окружения: {api_key[:12]}...{api_key[-4:]}")

    ip, country = fetch_exit_info()
    if country == "?":
        warn(f"выходной IP: {ip} (страну определить не удалось)")
    elif country == "RU":
        bad(f"выходной IP: {ip}, страна RU — VPN НЕ маршрутизирует трафик; Groq даст 403")
    else:
        ok(f"выходной IP: {ip} (страна: {country})")

    status, body = http_json(f"{BASE}/models", api_key)
    if status != 200:
        diagnose_status(status, body, country)
        return 1
    try:
        models = sorted(m["id"] for m in json.loads(body).get("data", []))
    except Exception:  # noqa: BLE001
        models = []
    ok(f"ключ действителен, моделей доступно: {len(models)}")
    if MODEL in models:
        ok(f"целевая модель на месте: {MODEL}")
    else:
        warn(f"{MODEL} НЕТ в списке — чат может отвечать 404; похожие: "
             f"{', '.join(m for m in models if 'qwen' in m.lower()) or 'нет'}")

    status, body = http_json(
        f"{BASE}/chat/completions", api_key,
        data=json.dumps({"model": MODEL, "max_tokens": 16,
                         "messages": [{"role": "user", "content": "Скажи: связь есть."}]
                         }).encode())
    if status != 200:
        diagnose_status(status, body, country)
        if status in (403, 404):
            # второй шанс: самая доступная бесплатная модель — отделяет
            # блокировку аккаунта/IP от проблем конкретной модели
            status2, body2 = http_json(
                f"{BASE}/chat/completions", api_key,
                data=json.dumps({"model": "llama-3.1-8b-instant", "max_tokens": 16,
                                 "messages": [{"role": "user", "content": "ping"}]
                                 }).encode())
            if status2 == 200:
                warn("Зато llama-3.1-8b-instant ОТВЕЧАЕТ — проблема только в модели")
                warn(f"{MODEL}: поменяйте model в conf.yaml на работающую.")
                return 1
            note(f"Контрольный запрос к llama-3.1-8b-instant: HTTP {status2} — "
                 "проблема на уровне ключа/IP/аккаунта, а не модели.")
        return 1
    try:
        answer = json.loads(body)["choices"][0]["message"]["content"].strip()
    except Exception:  # noqa: BLE001
        answer = body[:120]
    ok(f"чат работает: «{answer[:80]}»")
    note("Если Карен всё равно отвечает ошибкой — перезапустите её (stop/start),")
    note("чтобы бэкенд подхватил восстановившийся доступ.")
    return 0


def diagnose_from_exception(e: Exception, country: str) -> None:
    """Вытащить HTTP-код из исключения groq SDK и напечатать вердикт."""
    s = str(e)
    for code in (401, 403, 404, 429):
        if f"Error code: {code}" in s or f"status_code={code}" in s:
            diagnose_status(code, s[:200], country)
            return


def main() -> int:
    if "--quick" in sys.argv:
        return run_quick()

    api_key = os.getenv("GROQ_API_KEY", "").strip()
    failures: list[str] = []

    print("=" * 68)
    print(" Groq API diagnostics — Open-LLM-VTuber / AI-компаньон")
    print("=" * 68)

    if not api_key:
        bad("GROQ_API_KEY не задан.")
        print('    Windows:  setx GROQ_API_KEY "gsk_..."  -> откройте НОВЫЙ терминал')
        print("    Linux/mac: export GROQ_API_KEY='gsk_...'")
        note("Подсказка: conf.yaml проекта подставляет ${GROQ_API_KEY} из окружения ОС,")
        note("         .env-файл он НЕ читает.")
        return 2
    ok(f"ключ найден в окружении: {api_key[:12]}...{api_key[-4:]}")
    warn("Если этот ключ где-то публиковался (например, в техническом паспорте) —")
    warn("отзовите его в https://console.groq.com/keys и выпустите новый.")

    # ---------------------------------------------------------------- 1
    header("1/7", "Cloudflare / связность")
    _ip, _country = fetch_exit_info()
    if _country == "RU":
        bad(f"выходной IP: {_ip}, страна RU — VPN НЕ маршрутизирует трафик до Groq; ждите 403")
    elif _country == "?":
        warn(f"выходной IP: {_ip} (страну не определить — нет связи до ip-api)")
    else:
        ok(f"выходной IP: {_ip} (страна: {_country})")
    note("Если страна RU при включённом Karing — трафик идёт мимо VPN: включите")
    note("глобальный режим/TUN или добавьте api.groq.com в правила проксирования.")
    browser_ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")
    for label, headers in (("urllib без User-Agent", {}),
                           ("urllib + браузерный UA", {"User-Agent": browser_ua})):
        try:
            req = urllib.request.Request(f"{BASE}/models", headers=headers)
            urllib.request.urlopen(req, timeout=15)
            ok(f"{label}: 200")
        except urllib.error.HTTPError as e:
            body = e.read(200).decode(errors="replace").strip().replace("\n", " ")
            if e.code == 403 and "1010" in body:
                warn(f"{label}: HTTP 403, Cloudflare error 1010 (заблокирован User-Agent)")
            elif e.code == 401:
                ok(f"{label}: прошёл WAF, получен ожидаемый 401 (нет ключа в заголовке)")
            else:
                warn(f"{label}: HTTP {e.code} — {body[:120]}")
        except Exception as e:  # noqa: BLE001
            bad(f"{label}: {type(e).__name__}: {e}")
            failures.append("сеть недоступна")
    note("Вывод: 1010 — это фильтр по User-Agent, а не геоблок. Официальный SDK и")
    note("      любой клиент с нормальным UA работают; Open-LLM-VTuber использует SDK.")

    # ---------------------------------------------------------------- SDK
    try:
        from groq import Groq
    except ImportError:
        bad("пакет groq не установлен:  uv add groq   (или pip install groq)")
        return 2

    client = Groq(api_key=api_key, timeout=60, max_retries=2)

    # ---------------------------------------------------------------- 2
    header("2/7", "Валидность ключа и список моделей")
    models: list[str] = []
    try:
        resp = client.models.list()
        models = sorted(m.id for m in resp.data)
        ok(f"ключ действителен, доступно моделей: {len(models)}")
        for m in models:
            print(f"        - {m}")
    except Exception as e:  # noqa: BLE001
        bad(f"не удалось получить список моделей: {type(e).__name__}: {str(e)[:200]}")
        diagnose_from_exception(e, _country)
        failures.append("ключ невалиден или сеть заблокирована")
        print("\nИтог: БЕЗ ДОСТУПА К API — дальше проверки бессмысленны.")
        return 1

    # ---------------------------------------------------------------- 3
    header("3/7", f"Целевая модель: {MODEL}")
    if MODEL in models:
        ok("модель доступна на аккаунте")
    else:
        bad(f"{MODEL} нет в списке доступных")
        failures.append(f"модель {MODEL} недоступна")
        cand = [m for m in models if "qwen" in m.lower()]
        if cand:
            warn(f"похожие: {', '.join(cand)}")
    note("Статус модели на Groq — Preview: её могут снять в любой момент.")
    note("Держите резерв: Ollama qwen3:8b локально или Alibaba DashScope.")

    # ---------------------------------------------------------------- 4
    header("4/7", "Диалог на русском (латентность и токены)")
    question = "Привет! Как тебе мой новый ноутбук Lenovo Legion с RTX 4060?"
    try:
        t0 = time.time()
        r = client.chat.completions.create(
            model=MODEL,
            temperature=0.8,
            max_tokens=200,          # <= 1000: на free-тарифе OTPM = 1000
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": question},
            ],
        )
        wall = time.time() - t0
        u = r.usage
        text = (r.choices[0].message.content or "").strip()
        tps = u.completion_tokens / max(u.completion_time or 1e-6, 1e-6)
        ok(f"ответ получен за {wall:.2f} c (генерация {u.completion_time:.3f} c, {tps:.0f} t/s)")
        print(f"        prompt={u.prompt_tokens} completion={u.completion_tokens} total={u.total_tokens}")
        print(f"        {DIM}«{text[:300]}»{RESET}")
        if any(ch in text for ch in "😀😎✨💻🍵🎮😊"):
            warn("в ответе есть эмодзи — убедитесь, что в conf.yaml включён")
            warn("tts_preprocessor_config.remove_special_char: True, иначе TTS будет их проговаривать.")
        rc = getattr(r.choices[0].message, "reasoning_content", None)
        note(f"reasoning_content: {'нет (thinking не мешает латентности)' if not rc else f'{len(rc)} симв.'}")
    except Exception as e:  # noqa: BLE001
        bad(f"ошибка запроса: {type(e).__name__}: {str(e)[:250]}")
        diagnose_from_exception(e, _country)
        failures.append("chat completion не работает")

    # ---------------------------------------------------------------- 5
    header("5/7", "Стриминг — время до первого токена")
    try:
        t0 = time.time()
        first = None
        chunks = 0
        chars = 0
        stream = client.chat.completions.create(
            model=MODEL, temperature=0.8, max_tokens=150, stream=True,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": "Скажи пару слов о том, как проходит твой день."},
            ],
        )
        for ch in stream:
            if ch.choices and ch.choices[0].delta and ch.choices[0].delta.content:
                if first is None:
                    first = time.time() - t0
                chunks += 1
                chars += len(ch.choices[0].delta.content)
        total = time.time() - t0
        if first:
            ok(f"первый токен через {first:.2f} c, весь ответ {total:.2f} c "
               f"({chunks} чанков, {chars} символов)")
            if first > 1.5:
                warn("latency высокая — проверьте прокси/маршрут до api.groq.com")
        else:
            warn("стриминг не вернул контента")
    except Exception as e:  # noqa: BLE001
        bad(f"стриминг не работает: {type(e).__name__}: {str(e)[:200]}")
        failures.append("streaming")

    # ---------------------------------------------------------------- 6
    header("6/7", "Реальные лимиты аккаунта (заголовки ответа)")
    try:
        req = urllib.request.Request(
            f"{BASE}/chat/completions",
            data=json.dumps({
                "model": MODEL,
                "messages": [{"role": "user", "content": "ok"}],
                "max_tokens": 8,
            }).encode(),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": browser_ua,
            },
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            hdrs = resp.headers
    except urllib.error.HTTPError as e:
        hdrs = e.headers  # заголовки лимитов приходят и при 429
    except Exception as e:  # noqa: BLE001
        hdrs = None
        warn(f"не удалось прочитать заголовки: {e}")

    if hdrs:
        mapping = [
            ("x-ratelimit-limit-requests", "запросов в сутки (RPD)"),
            ("x-ratelimit-remaining-requests", "осталось запросов сегодня"),
            ("x-ratelimit-limit-tokens", "токенов в минуту (TPM)"),
            ("x-ratelimit-remaining-tokens", "осталось токенов в этой минуте"),
            ("x-ratelimit-reset-requests", "сброс дневного лимита через"),
            ("x-ratelimit-reset-tokens", "сброс минутного лимита через"),
        ]
        for h, label in mapping:
            v = hdrs.get(h)
            if v:
                ok(f"{label}: {v}")
        note("Справочно (доки Groq, qwen/qwen3.8-27b): 30 RPM | 1000 RPD | 8K TPM | 200K TPD.")
        note("1000 запросов в сутки — главный лимит «компаньона на весь день»:")
        note("  ~10 реплик/мин = ~600 запросов/час. Экономьте: короткий системный промпт,")
        note("  use_mcpp: False, меньше прерываний; резерв — Ollama qwen3:8b локально.")

    # ---------------------------------------------------------------- 7
    header("7/7", "Проверка ограничения max_tokens (OTPM)")
    note("На free-тарифе действует OTPM = 1000 output-токенов В МИНУТУ.")
    note("Запрошенный max_tokens вычитается из бюджета текущей минуты, поэтому")
    note("max_tokens=1024 то проходит, то отбивается 429 — в зависимости от того,")
    note("сколько токенов уже потрачено в этой минуте. Это плавающая, труднодиагностируемая ошибка.")
    for mt in (1024, 512):
        try:
            client.chat.completions.create(
                model=MODEL, max_tokens=mt,
                messages=[{"role": "user", "content": "Скажи: тест пройден."}],
            )
            ok(f"max_tokens={mt}: запрос принят (в этой минуте бюджета хватило)")
        except Exception as e:  # noqa: BLE001
            msg = str(e)
            if "429" in msg and "OTPM" in msg:
                warn(f"max_tokens={mt}: 429 — не хватило output-бюджета этой минуты (OTPM=1000)")
                note("  Именно так и выглядит «иногда работает, иногда нет» при max_tokens: 1024 из паспорта.")
                note("  В conf.yaml Open-LLM-VTuber поля max_tokens нет вовсе — проблема не возникает.")
            else:
                bad(f"max_tokens={mt}: {type(e).__name__}: {msg[:180]}")

    # ---------------------------------------------------------------- итог
    print("\n" + "=" * 68)
    if failures:
        print(f" {RED}ЕСТЬ ПРОБЛЕМЫ:{RESET} " + "; ".join(dict.fromkeys(failures)))
        print("=" * 68)
        return 1
    print(f" {GREEN}ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ — LLM-бэкенд готов к подключению.{RESET}")
    print("=" * 68)
    print(" Следующий шаг: uv run run_server.py  ->  http://localhost:12393 (Chrome)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
