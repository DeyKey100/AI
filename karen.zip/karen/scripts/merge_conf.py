#!/usr/bin/env python3
"""
Сборка conf.yaml для Open-LLM-VTuber v1.2.1 из двух частей:

    config_templates/conf.default.yaml   (полный шаблон проекта — все дефолты)
  + config/conf.patch.yaml               (наши «русские» правки: Groq + faster-whisper + Piper)
  = conf.yaml                            (готовый рабочий конфиг)

Зачем так: шаблон содержит обязательные поля, о которых легко забыть
(system_config.tool_prompts, translator_config.translate_provider, все блоки
провайдеров), а патч — только то, что относится к нашему стеку.
Глубокое слияние сохраняет и то, и другое.

Запуск:
    из корня проекта Open-LLM-VTuber:
        python <путь>/merge_conf.py --patch <путь>/conf.patch.yaml
    или просто положите merge_conf.py и conf.patch.yaml в корень проекта:
        python merge_conf.py

Опции:
    --out conf.yaml      куда писать результат
    --dry-run            только показать, что изменится
    --check              после сборки провалидировать результат схемой проекта
                         (работает, если запускать из корня проекта с установленными зависимостями)
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import copy
import shutil
import sys
import time
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("Нужен PyYAML:  pip install pyyaml   (или uv add pyyaml)")


def deep_merge(base: dict, patch: dict) -> dict:
    """Рекурсивно накладывает patch на base. Списки и скаляры заменяются целиком."""
    out = copy.deepcopy(base)
    for k, v in patch.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def flatten(d, prefix=""):
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            yield from flatten(v, key + ".")
        else:
            yield key, v


def lint_yaml_files(root: Path) -> int:
    """Быстрая проверка синтаксиса YAML у конфигов (без валидации схемой).

    Ловит опечатки вроде «* вместо #» в characters/*.yaml и conf.yaml,
    из-за которых сервер падает с неочевидным ScannerError.
    """
    targets = []
    for pat in ("conf.yaml", "characters/*.yaml", "config_alts/*.yaml", "conf.patch.yaml"):
        targets.extend(sorted(root.glob(pat)))
    if not targets:
        print("[i] нечего проверять (--lint)")
        return 0
    bad = 0
    for p in targets:
        try:
            with open(p, encoding="utf-8") as f:
                yaml.safe_load(f)
            print(f"    [ok]   {p}")
        except Exception as e:  # noqa: BLE001
            bad += 1
            print(f"    [FAIL] {p}\n           {type(e).__name__}: {str(e)[:300]}")
    return 1 if bad else 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", default=None, help="по умолчанию config_templates/conf.default.yaml")
    ap.add_argument("--patch", default=None, help="по умолчанию ищет conf.patch.yaml рядом с собой")
    ap.add_argument("--out", default="conf.yaml")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--lint", action="store_true",
                    help="только проверить синтаксис YAML у conf.yaml и characters/*.yaml")
    ap.add_argument("--tts", default="openai_tts",
                    choices=["openai_tts", "piper_tts", "edge_tts", "sherpa_onnx_tts"],
                    help="openai_tts = локальный Silero-сервер (по умолчанию)")
    ap.add_argument("--silero-url", default="http://127.0.0.1:8880/v1")
    ap.add_argument("--silero-voice", default="baya")
    ap.add_argument("--silero-model", default="silero-v5_5_ru")
    args = ap.parse_args()

    root = Path.cwd()

    if args.lint:
        print("[i] Проверка синтаксиса YAML ...")
        return lint_yaml_files(root)

    tpl_path = Path(args.template) if args.template else root / "config_templates" / "conf.default.yaml"
    if not tpl_path.exists():
        tpl_path = root / "conf.default.yaml"
    if not tpl_path.exists():
        sys.exit(f"[xx] шаблон не найден: {tpl_path}\n"
                 f"    Запускайте из корня проекта Open-LLM-VTuber или укажите --template.")

    patch_path = Path(args.patch) if args.patch else Path(__file__).parent / "conf.patch.yaml"
    if not patch_path.exists():
        patch_path = root / "conf.patch.yaml"
    if not patch_path.exists():
        sys.exit(f"[xx] файл правок не найден: {patch_path}  (укажите --patch)")

    with open(tpl_path, encoding="utf-8") as f:
        base = yaml.safe_load(f) or {}
    with open(patch_path, encoding="utf-8") as f:
        patch = yaml.safe_load(f) or {}

    print(f"[i] шаблон : {tpl_path}")
    print(f"[i] правки  : {patch_path}")

    merged = deep_merge(base, patch)

    # --- TTS: по умолчанию локальный Silero через штатный openai_tts-клиент проекта ---
    tts_root = merged.setdefault("character_config", {}).setdefault("tts_config", {})
    tts_root["tts_model"] = args.tts
    if args.tts == "openai_tts":
        oa = tts_root.setdefault("openai_tts", {})
        oa["model"] = args.silero_model
        oa["voice"] = args.silero_voice
        oa["api_key"] = "not-needed"
        oa["base_url"] = args.silero_url
        oa["file_extension"] = "wav"      # wav не требует ffmpeg на стороне сервера
    elif args.tts == "piper_tts":
        tts_root.setdefault("piper_tts", {})["model_path"] = \
            "models/piper/ru_RU-irina-medium.onnx"
    elif args.tts == "edge_tts":
        tts_root.setdefault("edge_tts", {})["voice"] = "ru-RU-SvetlanaNeural"

    # --- что именно изменилось ---
    flat_base = dict(flatten(base))
    flat_new = dict(flatten(merged))
    changed, added = [], []
    for k, v in flat_new.items():
        if k not in flat_base:
            added.append((k, v))
        elif flat_base[k] != v:
            changed.append((k, flat_base[k], v))

    print(f"\n[i] изменено ключей: {len(changed)}, добавлено: {len(added)}")
    for k, old, new in changed:
        o = str(old).replace("\n", " ")[:60]
        n = str(new).replace("\n", " ")[:60]
        print(f"    ~ {k}\n        было: {o}\n        стало: {n}")
    for k, v in added:
        print(f"    + {k} = {str(v).replace(chr(10), ' ')[:70]}")

    if args.dry_run:
        print("\n[i] --dry-run: файл не записан.")
        return 0

    out = Path(args.out)
    if out.exists():
        bak = out.with_suffix(f".yaml.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(out, bak)
        print(f"\n[i] резервная копия прежнего конфига: {bak.name}")

    header = (
        "# conf.yaml — собран автоматически merge_conf.py\n"
        f"# шаблон: {tpl_path.name}  +  правки: {patch_path.name}\n"
        f"# дата: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        "# Ключ берётся из переменной окружения GROQ_API_KEY (setx GROQ_API_KEY \"gsk_...\").\n"
        "# Не храните ключ в этом файле и не коммитьте его в git.\n\n"
    )
    with open(out, "w", encoding="utf-8") as f:
        f.write(header)
        yaml.safe_dump(merged, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=110)
    print(f"[+] записан {out.resolve()}")

    if args.check:
        print("\n[i] валидация схемой проекта ...")
        try:
            sys.path.insert(0, str(root / "src"))
            from open_llm_vtuber.config_manager import read_yaml, validate_config  # type: ignore
            cfg = validate_config(read_yaml(str(out)))
            cc = cfg.character_config
            b = cc.agent_config.agent_settings.basic_memory_agent
            print(f"[OK] конфиг валиден: llm={b.llm_provider} asr={cc.asr_config.asr_model} "
                  f"tts={cc.tts_config.tts_model} vad={cc.vad_config.vad_model}")
        except ImportError:
            print("[!!] не удалось импортировать config_manager (нет зависимостей проекта) — проверка пропущена")
        except Exception as e:  # noqa: BLE001
            print(f"[xx] конфиг НЕ прошёл валидацию: {type(e).__name__}: {str(e)[:800]}")
            return 1

    if args.tts == "openai_tts":
        print("\n[i] TTS = Silero через openai_tts. Сервер должен быть запущен ОТДЕЛЬНО:")
        print(f"      python tts/silero_openai_tts_server.py --warmup   ({args.silero_url})")
        print(f"      голос: {args.silero_voice}  (список: curl {args.silero_url.replace('/v1','')}/v1/voices)")
    print("\nДальше:  uv run run_server.py   ->   http://localhost:12393  (Chrome)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
