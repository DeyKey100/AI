#!/usr/bin/env python3
"""
Смоук-тест полного стека AI-компаньона. Запускается НА ВАШЕЙ машине,
когда бэкенд Open-LLM-VTuber уже поднят (uv run run_server.py).

Проверяет по цепочке:
  0. ресурсы машины (RAM/VRAM/диск) — влезет ли стек
  1. Silero TTS-сервер (:8880) — здоровье, голос, реальная задержка
  2. бэкенд (:12393) — отдаёт ли веб-интерфейс
  3. Live2D-модели — видны ли фронту (и известный баг эндпоинта v1.2.1)
  4. TTS через штатный WebSocket проекта /tts-ws
  5. ASR через POST /asr (нужен wav-файл: --asr-file путь)
  6. ПОЛНЫЙ ЦИКЛ: text-input -> Groq LLM -> TTS через /client-ws
  7. расход лимитов Groq после теста

Запуск из корня проекта Open-LLM-VTuber:
    uv run python smoke_test.py
    uv run python smoke_test.py --asr-file test_ru.wav --keep-listening

Зависимости: websockets (ставится вместе с проектом), опционально openai.
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import asyncio
import io
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
import wave

UA = {"User-Agent": "Mozilla/5.0 (vtuber-smoke-test)"}
GREEN, RED, YELL, DIM, BOLD, RESET = "\033[92m", "\033[91m", "\033[93m", "\033[2m", "\033[1m", "\033[0m"

results: list[tuple[str, str, str]] = []   # (статус, этап, деталь)


def ok(step: str, msg: str) -> None:
    results.append(("OK", step, msg))
    print(f"  {GREEN}[ok]{RESET}   {msg}")


def warn(step: str, msg: str) -> None:
    results.append(("WARN", step, msg))
    print(f"  {YELL}[warn]{RESET} {msg}")


def fail(step: str, msg: str) -> None:
    results.append(("FAIL", step, msg))
    print(f"  {RED}[FAIL]{RESET} {msg}")


def note(msg: str) -> None:
    print(f"  {DIM}{msg}{RESET}")


def header(title: str) -> None:
    print(f"\n{BOLD}{'-' * 72}\n{title}\n{'-' * 72}{RESET}")


def http_json(url: str, timeout: int = 20):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, json.loads(r.read().decode())


# --------------------------------------------------------------------------- #
# 0. ресурсы
# --------------------------------------------------------------------------- #
def check_resources() -> None:
    header("0/7  Ресурсы машины")
    total_ram = avail_ram = None
    try:
        if sys.platform == "win32":
            out = subprocess.check_output(
                ["wmic", "OS", "get", "TotalVisibleMemorySize,FreePhysicalMemory", "/value"],
                text=True, stderr=subprocess.DEVNULL)
            vals = dict(l.split("=") for l in out.splitlines() if "=" in l)
            total_ram = int(vals.get("TotalVisibleMemorySize", 0)) / 1048576
            avail_ram = int(vals.get("FreePhysicalMemory", 0)) / 1048576
        else:
            with open("/proc/meminfo") as f:
                d = dict((k.strip(), v.strip()) for k, v in
                         (l.split(":", 1) for l in f if ":" in l))
            total_ram = int(d["MemTotal"].split()[0]) / 1048576
            avail_ram = int(d["MemAvailable"].split()[0]) / 1048576
    except Exception as e:  # noqa: BLE001
        warn("0", f"не удалось прочитать RAM: {e}")

    if total_ram:
        msg = f"RAM: {avail_ram:.1f} ГБ свободно из {total_ram:.1f} ГБ"
        if total_ram < 15:
            fail("0", msg + " — стек не поместится")
        elif avail_ram < 4:
            warn("0", msg + " — маловато: закройте браузер/игры перед запуском")
        else:
            ok("0", msg)

    # VRAM через nvidia-smi
    smi = shutil.which("nvidia-smi")
    if smi:
        try:
            out = subprocess.check_output(
                [smi, "--query-gpu=name,memory.total,memory.used", "--format=csv,noheader"],
                text=True, stderr=subprocess.DEVNULL).strip()
            ok("0", f"GPU: {out}")
        except Exception:  # noqa: BLE001
            warn("0", "nvidia-smi есть, но не отдал данные")
    else:
        note("nvidia-smi не найден (Live2D рендерится через WebGL браузера — это не критично)")

    if shutil.which("ffmpeg"):
        try:
            v = subprocess.check_output(["ffmpeg", "-version"], text=True,
                                        stderr=subprocess.DEVNULL).splitlines()[0]
            ok("0", f"ffmpeg: {v[:70]}")
        except Exception:  # noqa: BLE001
            warn("0", "ffmpeg найден, но не запускается")
    else:
        fail("0", "ffmpeg НЕ найден в PATH — конвертация аудио не будет работать. "
                  "winget install ffmpeg")

    note(f"Python: {sys.version.split()[0]}  (проект требует >=3.10,<3.13)")


# --------------------------------------------------------------------------- #
# 1. Silero TTS сервер
# --------------------------------------------------------------------------- #
def check_tts_server(base: str, voice: str) -> bool:
    header("1/7  Локальный TTS-сервер (Silero)")
    root = base.rstrip("/")
    host = root[:-3] if root.endswith("/v1") else root
    try:
        st, d = http_json(host + "/health", timeout=6)
        ok("1", f"{host}/health -> {d.get('status')} | модель {d.get('model')} | "
                f"потоков {d.get('threads')} | rtf_avg {d.get('rtf_avg')}")
    except Exception as e:  # noqa: BLE001
        fail("1", f"Silero TTS-сервер не отвечает на {host}/health: {type(e).__name__}")
        note("Запустите его отдельным окном:  start_tts_server.bat")
        note("или:  python tts/silero_openai_tts_server.py --warmup")
        return False

    # реальная замеренная задержка
    text = "Привет! Проверка связи."
    body = json.dumps({"model": "silero-v5_5_ru", "voice": voice, "input": text,
                       "response_format": "wav", "speed": 1.0}).encode()
    req = urllib.request.Request(root + "/audio/speech", data=body,
                                 headers={**UA, "Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            blob = r.read()
            rtf = r.headers.get("X-Silero-RTF")
        dt = time.time() - t0
        buf = io.BytesIO(blob)
        with wave.open(buf) as w:
            dur = w.getnframes() / w.getframerate()
            sr = w.getframerate()
        ok("1", f"голос '{voice}': {dt*1000:.0f} мс на {dur:.2f} с аудио "
                f"({sr} Гц, {len(blob)/1024:.0f} КБ), серверный RTF={rtf}")
        if dt > 1.0:
            warn("1", "задержка больше секунды — проверьте --threads и нагрузку на CPU")
    except urllib.error.HTTPError as e:
        fail("1", f"TTS вернул HTTP {e.code}: {e.read(200).decode(errors='replace')[:150]}")
        return False
    except Exception as e:  # noqa: BLE001
        fail("1", f"TTS-запрос не прошёл: {type(e).__name__}: {str(e)[:150]}")
        return False
    return True


# --------------------------------------------------------------------------- #
# 2. бэкенд
# --------------------------------------------------------------------------- #
def check_backend(base: str) -> bool:
    header("2/7  Бэкенд Open-LLM-VTuber")
    try:
        req = urllib.request.Request(base + "/", headers=UA)
        with urllib.request.urlopen(req, timeout=10) as r:
            body = r.read()
        if r.status == 200 and b"<html" in body.lower():
            ok("2", f"{base}/ -> 200, веб-интерфейс отдаётся")
            # index.html у проекта крошечный (SPA-шелл ~300 байт) — это норма.
            # Реальная проверка: существуют ли и отдаются ли его ассеты.
            import re
            refs = re.findall(rb'(?:src|href)="([^"]+\.(?:js|css))"', body)
            note(f"index.html: {len(body)} байт (SPA-шелл), ассетов: {len(refs)}")
            if not refs:
                warn("2", "в index.html нет ссылок на js/css — фронтенд-субмодуль не собран "
                          "(нужен git clone --recursive)")
            else:
                bad_assets = []
                for ref in refs[:4]:
                    u = ref.decode().lstrip("./")
                    full = base.rstrip("/") + "/" + u
                    try:
                        req2 = urllib.request.Request(full, headers=UA)
                        with urllib.request.urlopen(req2, timeout=20) as r2:
                            size = len(r2.read())
                        note(f"    {u} -> 200, {size/1024:.0f} КБ")
                    except Exception as e:  # noqa: BLE001
                        bad_assets.append(f"{u}: {type(e).__name__}")
                if bad_assets:
                    fail("2", "ассеты фронта не отдаются: " + ", ".join(bad_assets))
                    note("      лечение: git submodule update --init --recursive")
                else:
                    ok("2", "фронтенд собран и отдаётся целиком")
        else:
            warn("2", f"{base}/ -> {r.status}, но это не HTML")
        return True
    except Exception as e:  # noqa: BLE001
        fail("2", f"бэкенд не отвечает на {base}/: {type(e).__name__}")
        note("Запустите:  uv run run_server.py   (и посмотрите лог на ошибки)")
        return False


# --------------------------------------------------------------------------- #
# 3. Live2D
# --------------------------------------------------------------------------- #
def check_live2d(base: str, project_dir: str) -> None:
    header("3/7  Live2D-модели")
    try:
        st, d = http_json(base + "/live2d-models/info")
        n = d.get("count", 0)
        if n:
            ok("3", f"эндпоинт видит моделей: {n} -> "
                    f"{', '.join(c.get('name', '?') for c in d.get('characters', []))}")
        else:
            warn("3", "эндпоинт вернул count=0 — это известный баг v1.2.1: он ищет "
                      "live2d-models/<имя>/<имя>.model3.json, а файлы лежат в подпапке runtime/")
    except Exception as e:  # noqa: BLE001
        warn("3", f"/live2d-models/info недоступен: {type(e).__name__}")

    # фактическая проверка по model_dict.json — именно его читает фронтенд
    try:
        with open(os.path.join(project_dir, "model_dict.json"), encoding="utf-8") as f:
            md = json.load(f)
        names = [m.get("name") for m in md]
        ok("3", f"model_dict.json (его читает фронт): {len(names)} моделей -> {', '.join(names[:8])}")
        # модели на диске, которых нет в словаре — фронт их не покажет
        try:
            on_disk = {e.name for e in os.scandir(os.path.join(project_dir, "live2d-models"))
                       if e.is_dir()}
            hidden = sorted(on_disk - set(names))
            if hidden:
                warn("3", f"лежат на диске, но НЕ видны во фронте (нет записи в model_dict.json): "
                          f"{', '.join(hidden)}")
                note("      чтобы добавить: скопируйте блок из model_dict.json и поправьте name/url")
        except Exception:  # noqa: BLE001
            pass
        missing = []
        for m in md:
            url = (m.get("url") or "").lstrip("/")
            if url and not os.path.isfile(os.path.join(project_dir, url)):
                missing.append(f"{m.get('name')}: нет {url}")
        if missing:
            warn("3", "не найдены файлы моделей:\n        " + "\n        ".join(missing[:5]))
        else:
            ok("3", "все model3.json из model_dict.json присутствуют на диске")
        emo = md[0].get("emotionMap") if md else None
        if emo:
            note(f"карта эмоций первой модели: {', '.join(list(emo)[:8])} "
                 f"(ключевые слова на английском — их LLM вставляет в ответ)")
    except FileNotFoundError:
        warn("3", "model_dict.json не найден — запускайте тест из корня проекта")
    except Exception as e:  # noqa: BLE001
        warn("3", f"не удалось разобрать model_dict.json: {e}")


# --------------------------------------------------------------------------- #
# 4. TTS через WebSocket проекта
# --------------------------------------------------------------------------- #
async def check_project_tts(ws_base: str) -> None:
    header("4/7  TTS через штатный WebSocket /tts-ws")
    try:
        import websockets
    except ImportError:
        warn("4", "пакет websockets не установлен — пропускаю")
        return
    uri = ws_base.rstrip("/") + "/tts-ws"
    text = "Проверка озвучки через бэкенд. Вторая фраза для проверки разбиения."
    t0 = time.time()
    try:
        async with websockets.connect(uri, max_size=None) as ws:
            await ws.send(json.dumps({"text": text}))
            parts, errors = [], []
            while True:
                msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=180))
                if msg.get("status") == "error":
                    errors.append(msg.get("message"))
                    break
                if msg.get("audioPath"):
                    parts.append((msg.get("text", ""), msg["audioPath"], time.time() - t0))
                if msg.get("status") == "complete":
                    break
        dt = time.time() - t0
        if errors:
            fail("4", f"TTS вернул ошибку: {errors[0][:200]}")
            return
        ok("4", f"{len(parts)} аудиофрагментов за {dt:.2f} c")
        for txt, path, at in parts[:6]:
            size = os.path.getsize(path) if os.path.exists(path) else -1
            note(f"    [{at:5.2f} c] {txt[:44]!r} -> {path} ({size/1024:.0f} КБ)")
        if parts:
            per = dt / len(parts)
            if per > 2.5:
                warn("4", f"{per:.1f} c на фрагмент — похоже на облачный TTS (edge_tts). "
                          f"С локальным Silero должно быть < 0.5 c")
            else:
                ok("4", f"{per:.2f} c на фрагмент — похоже на локальный движок")
    except Exception as e:  # noqa: BLE001
        fail("4", f"/tts-ws не сработал: {type(e).__name__}: {str(e)[:200]}")


# --------------------------------------------------------------------------- #
# 5. ASR
# --------------------------------------------------------------------------- #
def check_asr(base: str, wav_file: str | None) -> None:
    header("5/7  ASR (распознавание русской речи)")
    if not wav_file:
        note("пропущено: укажите --asr-file <путь к wav 16 кГц 16 бит моно>")
        note("подсказка: любой wav можно сделать так —")
        note("  ffmpeg -i вход.mp3 -ac 1 -ar 16000 -f wav test_ru.wav")
        note("или запишите себя: «привет, как дела» — тест сравнит текст")
        return
    if not os.path.isfile(wav_file):
        fail("5", f"файл не найден: {wav_file}")
        return
    try:
        with wave.open(wav_file) as w:
            dur = w.getnframes() / w.getframerate()
            sr, sw, ch = w.getframerate(), w.getsampwidth(), w.getnchannels()
        note(f"файл: {dur:.2f} c, {sr} Гц, {sw*8} бит, каналов {ch}")
        if sw != 2:
            fail("5", "эндпоинт /asr ожидает 16-битный PCM wav")
            return
        with open(wav_file, "rb") as f:
            blob = f.read()
    except Exception as e:  # noqa: BLE001
        fail("5", f"не удалось прочитать wav: {e}")
        return

    boundary = uuid.uuid4().hex
    body = io.BytesIO()
    body.write(f"--{boundary}\r\n".encode())
    body.write(b'Content-Disposition: form-data; name="file"; filename="a.wav"\r\n')
    body.write(b"Content-Type: audio/wav\r\n\r\n")
    body.write(blob)
    body.write(f"\r\n--{boundary}--\r\n".encode())

    t0 = time.time()
    try:
        req = urllib.request.Request(base.rstrip("/") + "/asr", data=body.getvalue(),
                                     headers={"Content-Type": f"multipart/form-data; boundary={boundary}",
                                              **UA})
        with urllib.request.urlopen(req, timeout=300) as r:
            res = json.loads(r.read().decode())
        dt = time.time() - t0
        if res.get("error"):
            fail("5", f"сервер вернул ошибку: {res['error'][:200]}")
            return
        text = (res.get("text") or "").strip()
        ok("5", f"распознано за {dt:.2f} c (RTF {dt/max(dur,1e-6):.3f}): {text!r}")
        if not text:
            warn("5", "пустой текст — проверьте язык в конфиге (asr_config.faster_whisper.language: 'ru')")
        if dt > dur:
            warn("5", "распознавание медленнее самой речи — уменьшите модель или включите device: 'cuda'")
        note("ВАЖНО: первая просьба распознавания грузит модель в память (несколько секунд).")
        note("      Дальше будет быстрее — это нормальное ленивое поведение проекта.")
    except urllib.error.HTTPError as e:
        fail("5", f"HTTP {e.code}: {e.read(200).decode(errors='replace')[:150]}")
    except Exception as e:  # noqa: BLE001
        fail("5", f"{type(e).__name__}: {str(e)[:200]}")
        note("если соединение оборвалось — смотрите лог бэкенда: возможно, не хватило RAM "
             "на загрузку ASR-модели (в песочнице разработчика именно так и было)")


# --------------------------------------------------------------------------- #
# 6. полный цикл
# --------------------------------------------------------------------------- #
async def check_conversation(ws_base: str, question: str) -> None:
    header("6/7  Полный цикл: текст -> Groq LLM -> TTS")
    try:
        import websockets
    except ImportError:
        warn("6", "пакет websockets не установлен — пропускаю")
        return
    uri = ws_base.rstrip("/") + "/client-ws"
    t0 = time.time()
    try:
        async with websockets.connect(uri, max_size=None) as ws:
            await ws.send(json.dumps({"type": "add-client-to-group", "invitee_uid": None}))
            await asyncio.sleep(1.0)
            note(f"вопрос: {question!r}")
            await ws.send(json.dumps({"type": "text-input", "text": question}))
            t_send = time.time()

            types: dict[str, int] = {}
            sentences: list[str] = []
            audio: list[str] = []
            first_text_at = first_audio_at = None
            while time.time() - t0 < 120:
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=30)
                except asyncio.TimeoutError:
                    note("30 c тишины — завершаю")
                    break
                try:
                    msg = json.loads(raw)
                except Exception:  # noqa: BLE001
                    continue
                t = msg.get("type", "?")
                types[t] = types.get(t, 0) + 1
                if msg.get("audioPath"):
                    audio.append(msg["audioPath"])
                    if first_audio_at is None:
                        first_audio_at = time.time() - t_send
                if t in ("sentence-start", "sentence-end") and msg.get("text"):
                    sentences.append(msg["text"])
                    if first_text_at is None:
                        first_text_at = time.time() - t_send
                if t == "error":
                    fail("6", f"сервер вернул ошибку: {str(msg)[:200]}")
                    return
                if t == "conversation-chain-complete" or types.get("sentence-end", 0) >= 8:
                    break
            total = time.time() - t0

        ok("6", f"цикл отработал за {total:.2f} c")
        note(f"    типы сообщений: {json.dumps(types, ensure_ascii=False)}")
        if first_text_at:
            ok("6", f"первая фраза получена через {first_text_at:.2f} c")
        else:
            warn("6", "текст ответа не пришёл (возможно, другие имена событий в этой версии)")
        if first_audio_at:
            ok("6", f"первое аудио через {first_audio_at:.2f} c — это и есть «задержка до ответа голосом»")
        else:
            warn("6", "аудио не получено")
        if sentences:
            print(f"\n  {BOLD}Ответ компаньона:{RESET}")
            print("   " + " ".join(sentences)[:800])
        if audio:
            note(f"    аудиофрагментов: {len(audio)} (лежат в папке cache/)")
        if total > 20:
            warn("6", "цикл дольше 20 c — проверьте VPN до api.groq.com и TTS-сервер")
    except Exception as e:  # noqa: BLE001
        fail("6", f"/client-ws: {type(e).__name__}: {str(e)[:220]}")
        note("если соединение закрылось без close-frame — бэкенд упал (OOM?). Смотрите его лог.")


# --------------------------------------------------------------------------- #
# 7. лимиты Groq
# --------------------------------------------------------------------------- #
def check_groq_quota() -> None:
    header("7/7  Остаток лимитов Groq")
    key = os.getenv("GROQ_API_KEY", "").strip()
    if not key:
        warn("7", "GROQ_API_KEY не задан в окружении — не могу спросить остаток квоты")
        return
    body = json.dumps({"model": "qwen/qwen3.8-27b", "max_tokens": 8,
                       "messages": [{"role": "user", "content": "ok"}]}).encode()
    req = urllib.request.Request("https://api.groq.com/openai/v1/chat/completions",
                                 data=body,
                                 headers={"Authorization": f"Bearer {key}",
                                          "Content-Type": "application/json", **UA})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            h = r.headers
    except urllib.error.HTTPError as e:
        h = e.headers
    except Exception as e:  # noqa: BLE001
        warn("7", f"не удалось прочитать заголовки: {type(e).__name__}")
        return
    left_req = h.get("x-ratelimit-remaining-requests")
    left_tok = h.get("x-ratelimit-remaining-tokens")
    lim_req = h.get("x-ratelimit-limit-requests")
    lim_tok = h.get("x-ratelimit-limit-tokens")
    if left_req:
        pct = 100 * int(left_req) / max(int(lim_req or 1000), 1)
        msg = f"запросов осталось сегодня: {left_req} из {lim_req} ({pct:.0f}%)"
        (ok if pct > 30 else warn)("7", msg)
        if int(left_req) < 100:
            note("почти исчерпано: переключайтесь на локальный резерв "
                 "(llm_provider: 'ollama_llm', модель qwen3:8b)")
    if left_tok:
        ok("7", f"токенов в текущей минуте: {left_tok} из {lim_tok}")
    note("лимиты: 30 RPM | 1000 запросов/сутки | 8K TPM | OTPM 1000")


# --------------------------------------------------------------------------- #
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://127.0.0.1:12393")
    ap.add_argument("--tts-url", default="http://127.0.0.1:8880/v1")
    ap.add_argument("--voice", default="baya")
    ap.add_argument("--asr-file", default=None, help="wav 16 кГц 16 бит моно для теста ASR")
    ap.add_argument("--question", default="Привет! Расскажи коротко, кто ты и где живёшь.")
    ap.add_argument("--skip", default="", help="список этапов через запятую, например: 0,5")
    ap.add_argument("--project-dir", default=".",
                    help="корень проекта Open-LLM-VTuber (для model_dict.json и cache/)")
    args = ap.parse_args()

    skip = {s.strip() for s in args.skip.split(",") if s.strip()}
    ws_base = args.base_url.replace("http://", "ws://").replace("https://", "wss://")

    print("=" * 72)
    print(" СМОУК-ТЕСТ СТЕКА: Groq LLM + Silero TTS + faster-whisper ASR + Live2D")
    print("=" * 72)

    if "0" not in skip:
        check_resources()
    tts_alive = True
    if "1" not in skip:
        tts_alive = check_tts_server(args.tts_url, args.voice)
    backend_alive = True
    if "2" not in skip:
        backend_alive = check_backend(args.base_url)
    if "3" not in skip:
        check_live2d(args.base_url, args.project_dir)
    if backend_alive and "4" not in skip:
        asyncio.run(check_project_tts(ws_base))
    if backend_alive and "5" not in skip:
        check_asr(args.base_url, args.asr_file)
    if backend_alive and "6" not in skip:
        asyncio.run(check_conversation(ws_base, args.question))
    if "7" not in skip:
        check_groq_quota()

    # ---- итог ----
    header("ИТОГ")
    n_ok = sum(1 for s, _, _ in results if s == "OK")
    n_warn = sum(1 for s, _, _ in results if s == "WARN")
    n_fail = sum(1 for s, _, _ in results if s == "FAIL")
    for status, step, msg in results:
        if status == "FAIL":
            print(f"  {RED}FAIL{RESET} [{step}] {msg[:150]}")
    print()
    for status, step, msg in results:
        if status == "WARN":
            print(f"  {YELL}WARN{RESET} [{step}] {msg[:150]}")
    print(f"\n  {GREEN}OK: {n_ok}{RESET}   {YELL}WARN: {n_warn}{RESET}   {RED}FAIL: {n_fail}{RESET}")
    if not tts_alive:
        print(f"\n  {RED}Без TTS-сервера компаньон будет молчать.{RESET}")
    if n_fail:
        print(f"\n  {RED}ЕСТЬ БЛОКЕРЫ — смотрите разделы выше и лог бэкенда (logs/debug_*.log){RESET}")
        return 1
    print(f"\n  {GREEN}Стек рабочий. Открывайте {args.base_url} в Chrome.{RESET}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
