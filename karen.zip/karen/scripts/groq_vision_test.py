#!/usr/bin/env python3
"""
Проверка зрения (Vision) у qwen/qwen3.8-27b на Groq — для сценария
«компаньон смотрит на мой экран / на камеру».

Зачем отдельный скрипт:
  В Open-LLM-VTuber v1.2.1 НЕТ секции vision в conf.yaml — зрение заявлено в README,
  но конфигурируется со стороны фронтенда и в стабильной ветке развито слабо.
  Поэтому отдельно проверять мультимодальность LLM нужно напрямую.

Факты по модели (доки Groq):
  - вход: Text + images, до 3 изображений за запрос, каждое = 2048 input-токенов
  - лимит free-тарифа: 8K TPM -> скриншоты очень быстро съедают минутный бюджет
  - отдельный Alibaba Qwen-VL для этого НЕ нужен: основная модель уже мультимодальная

Запуск:
  python groq_vision_test.py                 # встроенный тестовый кадр
  python groq_vision_test.py screen.png      # свой файл
  python groq_vision_test.py --screenshot    # реальный скриншот экрана (нужен mss: pip install mss)
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import base64
import io
import os
import struct
import sys
import time
import zlib

MODEL = os.getenv("VTUBER_LLM_MODEL", "qwen/qwen3.8-27b")


def make_test_png() -> bytes:
    """Рисуем PNG 320x160: синий фон, красный квадрат, зелёная полоса — без внешних библиотек."""
    w, h = 320, 160
    rows = []
    for y in range(h):
        row = bytearray([0])  # filter type 0
        for x in range(w):
            if 60 <= x < 160 and 40 <= y < 120:
                row += bytes((220, 40, 40))
            elif y > 130:
                row += bytes((40, 200, 90))
            else:
                row += bytes((30, 60, 160))
        rows.append(bytes(row))
    raw = b"".join(rows)

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def take_screenshot() -> bytes:
    try:
        import mss
    except ImportError:
        sys.exit("Для --screenshot нужен пакет mss:  pip install mss")
    with mss.mss() as sct:
        mon = sct.monitors[1]
        shot = sct.grab(mon)
        png = mss.tools.to_png(shot.rgb, shot.size)
    return png


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("image", nargs="?", help="путь к изображению (png/jpg/webp, до 20 МБ)")
    ap.add_argument("--screenshot", action="store_true", help="снять реальный скриншот экрана")
    ap.add_argument("--question", default="Опиши, что изображено, одним предложением по-русски.")
    args = ap.parse_args()

    api_key = os.getenv("GROQ_API_KEY", "").strip()
    if not api_key:
        sys.exit("GROQ_API_KEY не задан. Windows: setx GROQ_API_KEY \"gsk_...\" + новый терминал.")

    if args.screenshot:
        data = take_screenshot()
        src = "скриншот экрана"
    elif args.image:
        with open(args.image, "rb") as f:
            data = f.read()
        src = os.path.basename(args.image)
    else:
        data = make_test_png()
        src = "синтетический тестовый кадр 320x160"

    ext = "png"
    if src.lower().endswith((".jpg", ".jpeg")):
        ext = "jpeg"
    elif src.lower().endswith(".webp"):
        ext = "webp"
    b64 = base64.b64encode(data).decode()
    print(f"[i] источник: {src}, {len(data)/1024:.0f} КБ, mime=image/{ext}")
    if len(data) > 20 * 1024 * 1024:
        sys.exit("[xx] файл больше 20 МБ — лимит Groq на размер файла.")

    try:
        from groq import Groq
    except ImportError:
        sys.exit("пакет groq не установлен:  pip install groq")

    client = Groq(api_key=api_key, timeout=90)
    print(f"[i] модель: {MODEL} (мультимодальная: до 3 изображений, 2048 токенов за картинку)")
    t0 = time.time()
    try:
        r = client.chat.completions.create(
            model=MODEL,
            temperature=0.4,
            max_tokens=300,
            messages=[
                {"role": "system",
                 "content": "Ты — AI VTuber-компаньон. Отвечай по-русски, кратко, без эмодзи."},
                {"role": "user", "content": [
                    {"type": "text", "text": args.question},
                    {"type": "image_url",
                     "image_url": {"url": f"data:image/{ext};base64,{b64}"}},
                ]},
            ],
        )
    except Exception as e:  # noqa: BLE001
        print(f"[FAIL] vision-запрос не прошёл: {type(e).__name__}: {str(e)[:400]}")
        print("\nЧто это значит:")
        print("  - если 400 'image not supported' -> мультимодальность на вашем тарифе/модели недоступна;")
        print("    тогда для зрения нужен отдельный провайдер (Alibaba DashScope qwen-vl-plus).")
        print("  - если 429 -> уперлись в TPM 8K: одно изображение = 2048 входных токенов.")
        return 1

    u = r.usage
    print(f"[ok] ответ за {time.time()-t0:.2f} c | prompt={u.prompt_tokens} "
          f"completion={u.completion_tokens}")
    print("\n--- ответ модели ---")
    print((r.choices[0].message.content or "").strip())
    print("--------------------")
    print("\nЗамечания по бюджету:")
    print(f"  * входных токенов на этот запрос: {u.prompt_tokens} (из них изображение — основная часть;")
    print("    доки Groq говорят про ~2048 токенов за картинку, фактический расход зависит от разрешения)")
    print("  * при TPM=8K это порядка 3-10 vision-запросов в минуту;")
    print("  * для постоянного «смотрю на экран» такой режим на бесплатном тарифе нежизнеспособен —")
    print("    дёргайте по команде/кнопке, а не потоком, либо используйте локальную vision-модель.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
