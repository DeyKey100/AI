#!/usr/bin/env python3
"""
Скачивание русской модели Piper TTS для Open-LLM-VTuber.

Piper ожидает пару файлов рядом:
    models/piper/ru_RU-irina-medium.onnx
    models/piper/ru_RU-irina-medium.onnx.json

Запуск из корня проекта Open-LLM-VTuber:
    python scripts/download_piper_ru.py [--voice irina|denis|dmitri|ruslan] [--out models/piper]

Зеркала (проверено 2026-09-21):
    speaches-ai/piper-ru_RU-<voice>-medium  -> model.onnx + config.json  (компактно, ~63 МБ)
    csukuangfj/vits-piper-ru_RU-<voice>-medium -> то же + папка espeak-ng-data

Доступные русские голоса Piper: irina (F), denis (M), dmitri (M), ruslan (M).
Все — качество "medium", обучены в 2023; звучание синтетическое, но RTF на CPU отличный.
Более свежая альтернатива для экспериментов: huggingface.co/rraaww/ru_piper
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

# Браузерный User-Agent обязателен: часть CDN/WAF режет дефолтный Python-urllib
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/126.0 Safari/537.36"}

MIRRORS = [
    "https://huggingface.co/speaches-ai/piper-ru_RU-{voice}-medium/resolve/main/",
    "https://hf-mirror.com/speaches-ai/piper-ru_RU-{voice}-medium/resolve/main/",
    "https://huggingface.co/csukuangfj/vits-piper-ru_RU-{voice}-medium/resolve/main/",
]

# какие имена файлов могут лежать в репозитории
ONNX_CANDIDATES = ["model.onnx", "ru_RU-{voice}-medium.onnx", "{voice}.onnx"]
JSON_CANDIDATES = ["config.json", "ru_RU-{voice}-medium.onnx.json", "{voice}.onnx.json"]


def download(url: str, dest: Path, timeout: int = 300) -> bool:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers=UA)
    try:
        t0 = time.time()
        with urllib.request.urlopen(req, timeout=timeout) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f)
        size = tmp.stat().st_size
        if size < 1024:
            tmp.unlink(missing_ok=True)
            return False
        tmp.replace(dest)
        print(f"    [+] {dest.name}  {size/1e6:.1f} МБ  за {time.time()-t0:.1f} c")
        return True
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError) as e:
        tmp.unlink(missing_ok=True)
        print(f"    [-] {url}  ->  {type(e).__name__}: {e}")
        return False


def fetch_first(base_urls: list[str], candidates: list[str], voice: str, dest: Path) -> bool:
    for base in base_urls:
        for cand in candidates:
            name = cand.format(voice=voice)
            url = base + name
            if download(url, dest):
                return True
    return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--voice", default="irina", choices=["irina", "denis", "dmitri", "ruslan"])
    ap.add_argument("--out", default="models/piper")
    args = ap.parse_args()

    out = Path(args.out)
    onnx = out / f"ru_RU-{args.voice}-medium.onnx"
    js = out / f"ru_RU-{args.voice}-medium.onnx.json"
    bases = [m.format(voice=args.voice) for m in MIRRORS]

    print(f"[i] Голос: ru_RU-{args.voice}-medium")
    print(f"[i] Папка: {out.resolve()}")

    if onnx.exists() and js.exists():
        print(f"[ok] Уже скачано: {onnx.name} ({onnx.stat().st_size/1e6:.1f} МБ), {js.name}")
    else:
        print("[i] Скачиваю .onnx ...")
        if not fetch_first(bases, ONNX_CANDIDATES, args.voice, onnx):
            print("[xx] Не удалось скачать модель. Проверьте сеть/прокси.")
            return 1
        print("[i] Скачиваю конфиг (.onnx.json) ...")
        if not fetch_first(bases, JSON_CANDIDATES, args.voice, js):
            print("[xx] Не удалось скачать конфиг модели.")
            return 1

    # --- подсказка для conf.yaml ---
    print("\n[+] Готово. В conf.yaml:")
    print("      character_config:")
    print("        tts_config:")
    print("          tts_model: 'piper_tts'")
    print("          piper_tts:")
    print(f"            model_path: '{onnx.as_posix()}'")
    print("            speaker_id: 0")

    # --- быстрый smoke-тест синтеза, если piper установлен ---
    try:
        import wave
        from piper import PiperVoice
    except ImportError:
        print("\n[i] piper-tts не установлен в текущем окружении — smoke-тест пропущен.")
        print("    Установка: uv add piper-tts")
        return 0

    print("\n[i] Smoke-тест синтеза ...")
    t0 = time.time()
    voice = PiperVoice.load(str(onnx), config_path=str(js))
    load = time.time() - t0
    text = "Привет! Я твой локальный компаньон. Проверка русского голоса завершена."
    out_wav = out / "piper_selftest.wav"
    t0 = time.time()
    with wave.open(str(out_wav), "wb") as wf:
        voice.synthesize_wav(text, wf)
    synth = time.time() - t0
    with wave.open(str(out_wav)) as wf:
        dur = wf.getnframes() / wf.getframerate()
    print(f"    загрузка модели: {load:.2f} c")
    print(f"    синтез: {synth:.2f} c на {dur:.2f} c аудио -> RTF {synth/dur:.3f}")
    print(f"    файл: {out_wav.resolve()}")
    print("    (RTF < 0.3 означает, что озвучка быстрее речи в реальном времени — хорошо)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
