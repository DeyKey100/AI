﻿<#
.SYNOPSIS
  Установка Open-LLM-VTuber «под ключ» для проекта КАРЕН (локальный AI VTuber-компаньон).
  Стек: Groq qwen/qwen3.8-27b + faster-whisper (ru) + KAREN Voice (Silero v5_5_ru,
  спикер baya, через штатный провайдер openai_tts) + Live2D.

.DESCRIPTION
  Что делает скрипт:
    1. Проверяет git / ffmpeg / uv / Python (3.10..3.12) и наличие GROQ_API_KEY.
    2. Клонирует репозиторий С ФЛАГОМ --recursive (фронтенд — git submodule).
    3. Ставит зависимости через uv sync (fallback: pip install -r requirements.txt).
    3b. Доустанавливает то, чего НЕТ в зависимостях проекта: silero-vad, torchaudio
        (нужны для штатного VAD — без них сервер падает на старте), faster-whisper.
    3c. Проверяет, что все нужные модули реально импортируются.
    4. Собирает conf.yaml из шаблона проекта + эталонного патча и ВАЛИДИРУЕТ его
       pydantic-схемой проекта (merge_conf.py --check --lint).
    5. Создаёт отдельное окружение для голоса: tts\.venv-silero (CPU-torch, silero,
       fastapi, uvicorn, scipy). Отдельно — потому что Silero требует numpy>=2,
       а проект пинит numpy<2.
    6. (только при -Tts piper_tts) скачивает русскую модель Piper.
    7. Прогоняет диагностику Groq API (связность/1010, ключ, модель, RU-диалог,
       стриминг, rate limits, OTPM).

.PARAMETER Tts
  openai_tts (по умолчанию) = локальный KAREN Voice на Silero;
  piper_tts / edge_tts — запасные варианты.

.NOTES
  Запуск:  powershell -ExecutionPolicy Bypass -File .\setup_windows.ps1
  Ключ:    setx GROQ_API_KEY "gsk_..."   (и ОТКРОЙТЕ НОВЫЙ терминал)
  Путь к проекту не должен содержать кириллицу и пробелы.
  Файл сохранён в UTF-8 с BOM: Windows PowerShell 5.1 без BOM читает .ps1
  как ANSI и ломает кириллицу (кракозябры + ошибки парсинга).
#>

[CmdletBinding()]
param(
    [string]$Repo     = "https://github.com/Open-LLM-VTuber/Open-LLM-VTuber",
    [string]$Dir      = "Open-LLM-VTuber",
    [string]$Asr      = "faster_whisper",   # faster_whisper | groq_whisper_asr | whisper_cpp
    [string]$Tts      = "openai_tts",       # openai_tts (=локальный Silero) | piper_tts | edge_tts
    [string]$SileroVoice = "baya",     # baya_anime | baya_bright | baya_bright_x | kseniya_anime | xenia_anime | baya | kseniya | xenia | aidar | eugene
    [string]$SileroUrl   = "http://127.0.0.1:8880/v1",
    [int]$SileroThreads  = 4,
    [string]$Model    = "qwen/qwen3.8-27b",
    [switch]$SkipClone,
    [switch]$SkipTest,
    [switch]$SkipTtsEnv                 # не создавать окружение Silero (если ставите piper/edge)
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
# Корень «лаборатории» (папка karen), если скрипт лежит в karen\scripts
$Lab  = Split-Path -Parent $Here

function Step($msg)  { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Ok($msg)    { Write-Host "    [ok] $msg" -ForegroundColor Green }
function Warn($msg)  { Write-Host "    [!!] $msg" -ForegroundColor Yellow }
function Fail($msg)  { Write-Host "    [xx] $msg" -ForegroundColor Red }

# Поиск вспомогательного файла: рядом со скриптом -> в karen\... -> в текущей папке.
# Скрипты можно запускать как из karen\scripts, так и скопировав их в корень проекта.
function Find-Asset {
    param([string[]]$Candidates)
    $dirs = @(
        $Here,
        (Join-Path $Lab "scripts"),
        (Join-Path $Lab "config"),
        (Join-Path $Lab "config\characters"),
        $Lab,
        (Get-Location).Path
    )
    foreach ($d in $dirs) {
        foreach ($c in $Candidates) {
            $p = Join-Path $d $c
            if (Test-Path $p) { return (Resolve-Path $p).Path }
        }
    }
    return $null
}

# ---------------------------------------------------------------- 1. проверка тулчейна
Step "1/7  Проверяю окружение"

function Test-Cmd($name, $arg) {
    $c = Get-Command $name -ErrorAction SilentlyContinue
    if (-not $c) { return $false }
    try { & $name $arg | Out-Null; return $true } catch { return $true }
}

if (Test-Cmd "git" "--version") { Ok "git $((git --version) -replace 'git version ','')" }
else { Fail "git не найден.  winget install Git.Git"; }

if (Test-Cmd "ffmpeg" "-version") { Ok "ffmpeg найден" }
else { Warn "ffmpeg НЕ найден (обязателен!).  winget install ffmpeg" }

$haveUv = [bool](Get-Command "uv" -ErrorAction SilentlyContinue)
if ($haveUv) { Ok "uv $((uv --version))" }
else {
    Warn "uv не найден."
    Warn "  установка: powershell -ExecutionPolicy ByPass -c `"irm https://astral.sh/uv/install.ps1 | iex`""
    Warn "  затем ПЕРЕЗАПУСТИТЕ терминал. Либо скрипт продолжит через pip (медленнее, менее надёжно)."
}

$py = $null
foreach ($cand in @("python", "py -3", "python3")) {
    try {
        $v = & cmd /c "$cand --version 2>&1"
        if ($v -match "Python (\d+)\.(\d+)") {
            $maj = [int]$Matches[1]; $min = [int]$Matches[2]
            if ($maj -eq 3 -and $min -ge 10 -and $min -le 12) { $py = $cand; Ok "$cand -> $v"; break }
            else { Warn "$v : проект требует Python >=3.10,<3.13" }
        }
    } catch {}
}
if (-not $py -and -not $haveUv) { Fail "Нет подходящего Python и нет uv. Ставьте uv и перезапускайте."; exit 1 }

if ($env:GROQ_API_KEY) {
    $masked = $env:GROQ_API_KEY.Substring(0, [Math]::Min(12, $env:GROQ_API_KEY.Length)) + "..." +
              $env:GROQ_API_KEY.Substring([Math]::Max(0, $env:GROQ_API_KEY.Length - 4))
    Ok "GROQ_API_KEY задан ($masked)"
} else {
    Warn "GROQ_API_KEY НЕ задан в окружении!"
    Warn '  conf.yaml использует подстановку ${GROQ_API_KEY} из переменных ОС;'
    Warn '  .env-файл проектом НЕ читается. Выполните:  setx GROQ_API_KEY "gsk_..."  и откройте новый терминал.'
}

# ---------------------------------------------------------------- 2. клонирование
Step "2/7  Получаю код проекта"
$proj = Join-Path (Get-Location) $Dir

if ($SkipClone -and (Test-Path $proj)) {
    Ok "клон пропущен (-SkipClone), использую $proj"
} elseif (Test-Path (Join-Path $proj ".git")) {
    Ok "$Dir уже существует — обновляю субмодули"
    Push-Location $proj
    git pull --ff-only
    git submodule update --init --recursive
    Pop-Location
} else {
    if ($proj -match "[^\x00-\x7F]") { Fail "Путь содержит не-ASCII символы: $proj"; exit 1 }
    # --recursive ОБЯЗАТЕЛЕН: frontend — субмодуль, иначе в браузере будет {"detail":"Not Found"}
    git clone $Repo $Dir --recursive
    if ($LASTEXITCODE -ne 0) { Fail "git clone не удался"; exit 1 }
    Ok "склонировано в $Dir"
}

Set-Location $proj
if (-not (Test-Path "frontend/index.html")) {
    Warn "frontend/index.html нет — чиню субмодули"
    git submodule update --init --recursive
}
if (Test-Path "frontend/index.html") { Ok "фронтенд на месте" } else { Fail "фронтенд не получен — веб-UI не откроется" }

# ---------------------------------------------------------------- 3. зависимости
Step "3/7  Ставлю зависимости (torch и т.п. — это несколько гигабайт, наберитесь терпения)"
if ($haveUv) {
    uv sync
    if ($LASTEXITCODE -ne 0) { Warn "uv sync вернул ошибку — попробую pip" ; & $py -m pip install -r requirements.txt }
} else {
    & $py -m pip install -r requirements.txt
}

Step "3b/7  Доустанавливаю ASR/TTS провайдеры (их нет в базовых зависимостях)"
# ВАЖНО: silero-vad и torchaudio НУЖНЫ проекту для vad_model: silero_vad,
# но ОТСУТСТВУЮТ в requirements.txt и pyproject.toml (проверено на v1.2.1).
# Без них сервер падает на старте: "No module named 'silero_vad'".
$extras = @("silero-vad", "torchaudio")
if ($Asr -eq "faster_whisper") { $extras += "faster-whisper" }
if ($Asr -eq "whisper_cpp")    { $extras += "pywhispercpp" ; Warn "pywhispercpp собирается из исходников: нужны MSVC Build Tools + CMake" }
if ($Tts -eq "piper_tts")      { $extras += "piper-tts" }
$extras += "pyyaml"

foreach ($pkg in $extras) {
    if ($haveUv) { uv add $pkg } else { & $py -m pip install $pkg }
    if ($LASTEXITCODE -eq 0) { Ok "$pkg" } else {
        Warn "$pkg не установился штатно — пробую без зависимостей"
        if ($haveUv) { uv pip install --no-deps $pkg } else { & $py -m pip install --no-deps $pkg }
        if ($LASTEXITCODE -eq 0) { Ok "$pkg (--no-deps)" } else { Fail "$pkg не установился" }
    }
}

Step "3c/7  Проверяю, что все нужные модули реально импортируются"
$importCheck = @"
import importlib, sys
need = ['torch', 'torchaudio', 'silero_vad', 'loguru', 'pydantic', 'yaml', 'fastapi',
        'uvicorn', 'openai', 'groq', 'mcp', 'soundfile', 'pydub', 'pysbd', 'numpy']
if 'faster-whisper' in sys.argv: need.append('faster_whisper')
missing = []
for m in need:
    try: importlib.import_module(m)
    except Exception as e: missing.append(f'{m}: {type(e).__name__}')
print('IMPORT_MISSING=' + ','.join(missing) if missing else 'IMPORTS_OK')
"@
$importCheck | Out-File -Encoding utf8 "_import_check.py"
if ($haveUv) { uv run python -c (Get-Content -Raw -Encoding UTF8 "_import_check.py") $Asr } else { & $py -c (Get-Content -Raw -Encoding UTF8 "_import_check.py") $Asr }
Remove-Item "_import_check.py" -ErrorAction SilentlyContinue

# ---------------------------------------------------------------- 4. конфигурация
Step "4/7  Собираю conf.yaml"
# Путь A (предпочтительный): шаблон проекта + эталонный патч + валидация схемой проекта
$merge     = Find-Asset @("merge_conf.py")
$patchYaml = Find-Asset @("conf.patch.yaml")
# Путь B (запасной): точечный патчер уже существующего conf.yaml
$patcher   = Find-Asset @("patch_conf.py")

if ($merge -and $patchYaml) {
    Ok "использую merge_conf.py + conf.patch.yaml (шаблон + правки + валидация)"
    $mergeArgs = @("--patch", $patchYaml, "--check", "--tts", $Tts, "--silero-voice", $SileroVoice, "--silero-url", $SileroUrl)
    if ($haveUv) { uv run python $merge @mergeArgs } else { & $py $merge @mergeArgs }
    if ($LASTEXITCODE -ne 0) { Fail "merge_conf.py завершился с ошибкой"; exit 1 }
} elseif ($patcher) {
    Warn "нет merge_conf.py/conf.patch.yaml — использую запасной патчер patch_conf.py"
    if (-not (Test-Path "conf.yaml")) {
        Copy-Item "config_templates/conf.default.yaml" "conf.yaml"
        Ok "conf.yaml создан из config_templates/conf.default.yaml"
    }
    $patchArgs = @("--asr", $Asr, "--tts", $Tts, "--model", $Model, "--silero-voice", $SileroVoice, "--silero-url", $SileroUrl)
    if ($haveUv) { uv run python $patcher @patchArgs } else { & $py $patcher @patchArgs }
} else {
    Fail "не найден ни merge_conf.py, ни patch_conf.py"; exit 1
}

# проверка синтаксиса YAML у всех конфигов (ловит опечатки в characters/*.yaml)
if ($merge) {
    if ($haveUv) { uv run python $merge --lint } else { & $py $merge --lint }
}

# персонаж из этого проекта (если лежит рядом) — в папку characters/
$char = Find-Asset @("karen.yaml")
if ($char) {
    New-Item -ItemType Directory -Force -Path "characters" | Out-Null
    Copy-Item $char "characters/karen.yaml" -Force
    Ok "персонаж добавлен: characters/karen.yaml (переключается в веб-UI)"
}

# ---------------------------------------------------------------- 5. модель Piper
Step "5/7  Готовлю локальный голос"
if (($Tts -eq "openai_tts") -and (-not $SkipTtsEnv)) {
    $ttsDir = Find-Asset @("silero_openai_tts_server.py")
    if ($ttsDir) {
        $ttsHome = Split-Path -Parent $ttsDir
        $venv = Join-Path $ttsHome ".venv-silero"
        $vpy = Join-Path $venv "Scripts\python.exe"
        if (-not (Test-Path $vpy)) {
            Ok "создаю отдельное окружение для TTS (изоляция от numpy<2 в проекте): $venv"
            & py -3.11 -m venv $venv 2>$null
            if (-not (Test-Path $vpy)) { & python -m venv $venv 2>$null }
            if ((-not (Test-Path $vpy)) -and $haveUv) {
                Warn "python/py не нашли — создаю окружение через uv"
                uv venv $venv --python 3.11
                # uv venv создаёт окружение БЕЗ pip, а ниже мы ставим пакеты через pip
                if (Test-Path $vpy) { uv pip install --python $vpy pip }
            }
            if (-not (Test-Path $vpy)) { Warn "не удалось создать venv для TTS — установите Python 3.10-3.12" }
        }
        if (Test-Path $vpy) {
            Warn "ставлю CPU-сборку torch (~2 ГБ, один раз). Для TTS GPU не нужен — VRAM оставим под Live2D."
            & $vpy -m pip install --upgrade pip | Out-Null
            & $vpy -m pip install torch --index-url https://download.pytorch.org/whl/cpu
            # scipy нужен только профилям с chipmunk_st (baya_bright_extra, baya_chipmunk);
# для основного голоса baya не используется, но ставим сразу — 40 МБ и нет сюрпризов
            & $vpy -m pip install silero fastapi "uvicorn[standard]" scipy
            if ($LASTEXITCODE -eq 0) { Ok "окружение Silero TTS готово" } else { Fail "не удалось поставить зависимости Silero" }
        }
    } else {
        Warn "silero_openai_tts_server.py не найден — TTS-сервер придётся ставить вручную"
    }
}

if ($Tts -eq "piper_tts") {
    New-Item -ItemType Directory -Force -Path "models/piper" | Out-Null
    $dl = Find-Asset @("download_piper_ru.py")
    if ($dl) {
        if ($haveUv) { uv run python $dl } else { & $py $dl }
    } else {
        Warn "download_piper_ru.py не найден. Скачайте вручную:"
        Warn "  https://huggingface.co/speaches-ai/piper-ru_RU-irina-medium/resolve/main/model.onnx"
        Warn "    -> models/piper/ru_RU-irina-medium.onnx"
        Warn "  https://huggingface.co/speaches-ai/piper-ru_RU-irina-medium/resolve/main/config.json"
        Warn "    -> models/piper/ru_RU-irina-medium.onnx.json"
    }
} else { Ok "пропущено (TTS = $Tts)" }

# ---------------------------------------------------------------- 6. диагностика API
Step "6/7  Проверяю Groq API"
if ($SkipTest) { Ok "пропущено (-SkipTest)" }
else {
    $t = Find-Asset @("test_groq_api.py")
    if ($t) {
        if ($haveUv) { uv run python $t } else { & $py $t }
    } else { Warn "test_groq_api.py не найден" }
}

# ---------------------------------------------------------------- 7. финал
Step "7/7  Готово"
Write-Host @"

  Запуск (два окна):
      1) start_tts_server.bat         <- локальный голос Silero на :8880 (держать открытым)
      2) start_vtuber.bat             <- сам VTuber-бэкенд + откроет браузер

  Или вручную:
      cd $Dir
      uv run run_server.py            (или: python run_server.py)

  Фронтенд:
      Chrome -> http://localhost:12393 -> разрешить микрофон -> выбрать Live2D модель

  Десктоп-пет (прозрачное окно поверх всего):
      релизы Open-LLM-VTuber-Web -> open-llm-vtuber-electron-*.exe

  Обновление проекта (только для git-установки):
      uv run update.py

  Лимиты бесплатного Groq для qwen/qwen3.8-27b:
      30 RPM | 1000 запросов/СУТКИ | 8K TPM | 200K TPD | OTPM 1000
      -> держите системный промпт коротким и use_mcpp: False
"@ -ForegroundColor White
