@echo off
REM =====================================================================
REM  KAREN - Open-LLM-VTuber backend launcher (desktop-app edition).
REM
REM  1. checks the voice server on :8880 (starts it HIDDEN if missing,
REM     log: karen\logs\tts.log)
REM  2. schedules the desktop Electron app launch: a HIDDEN waiter
REM     (log: karen\logs\app.log) opens the app when :12393 answers.
REM     THE BROWSER IS NOT OPENED ANYMORE.
REM  3. runs the backend in THIS window (visible if launched manually,
REM     hidden + logged when launched by start_karen.bat)
REM
REM  Desktop app search order:
REM    a) env var KAREN_ELECTRON_APP (full path to .lnk or .exe)
REM    b) ..\open-llm-vtuber-electron.lnk / .exe (folder next to karen\)
REM    c) this folder, then any *electron*.lnk/.exe next to karen\
REM
REM  ASCII-only file (cmd.exe decodes .bat in the OEM codepage).
REM =====================================================================
setlocal enabledelayedexpansion
title KAREN backend :12393
set "HERE=%~dp0"

REM KAREN_HIDDEN=1 is inherited from start_karen.bat: output goes to a log
REM file, so Python must write UTF-8 (a cp1251-encoded stdout killed the
REM voice server on 2026-09-21), and `pause` must be skipped - an invisible
REM window waiting for a keypress leaves a zombie cmd.exe behind.
if "%KAREN_HIDDEN%"=="1" set "PYTHONIOENCODING=utf-8"

REM ---- locate the project ----------------------------------------------
REM NOTE: single-line "if exist ... set X & goto" is a BUG pattern -
REM the "& goto" part runs UNCONDITIONALLY. Hence explicit blocks here.
set "PROJ="
if exist "%HERE%run_server.py" set "PROJ=%HERE%"
if not defined PROJ if exist "%HERE%Open-LLM-VTuber\run_server.py" set "PROJ=%HERE%Open-LLM-VTuber\"
if not defined PROJ if exist "%HERE%..\Open-LLM-VTuber\run_server.py" set "PROJ=%HERE%..\Open-LLM-VTuber\"
if not defined PROJ (
    echo [xx] run_server.py not found. Put the karen folder next to
    echo    Open-LLM-VTuber, or copy this .bat inside the project folder.
    pause
    exit /b 1
)
echo [ok] project: %PROJ%

REM ---- locate the desktop app -------------------------------------------
set "APP=%KAREN_ELECTRON_APP%"
if "%APP%"=="" if exist "%HERE%..\open-llm-vtuber-electron.lnk" set "APP=%HERE%..\open-llm-vtuber-electron.lnk"
if "%APP%"=="" if exist "%HERE%..\open-llm-vtuber-electron.exe" set "APP=%HERE%..\open-llm-vtuber-electron.exe"
if "%APP%"=="" if exist "%HERE%open-llm-vtuber-electron.lnk" set "APP=%HERE%open-llm-vtuber-electron.lnk"
if "%APP%"=="" for %%f in ("%HERE%..\*electron*.lnk" "%HERE%..\*electron*.exe" "%HERE%*electron*.lnk" "%HERE%*electron*.exe") do if "!APP!"=="" set "APP=%%~f"
REM normalize: strip ".." segments - cmd's `start` refuses such paths with
REM "The syntax of the file name, directory name, or volume label is incorrect"
if not "%APP%"=="" (
    set "APPN="
    for /f "delims=" %%i in ('powershell -NoProfile -Command "(Resolve-Path -LiteralPath '%APP%').Path" 2^>nul') do set "APPN=%%i"
    if defined APPN set "APP=!APPN!"
)
if "%APP%"=="" (
    echo [!!] Desktop app NOT found. Put open-llm-vtuber-electron.lnk next
    echo    to the karen folder, or set env var KAREN_ELECTRON_APP to the
    echo    full path. The browser will NOT be opened either.
) else (
    echo [ok] desktop app: %APP%
)

REM ---- voice server ------------------------------------------------------
call :probe "http://127.0.0.1:8880/health"
if "%PCODE%"=="200" (
    echo [ok] Voice server is running on :8880
    goto tts_ready
)
echo [!!] Voice server is NOT running - starting it...
set "TTSBAT=%HERE%start_tts_server.bat"
if not exist "%TTSBAT%" if exist "%HERE%..\karen\start_tts_server.bat" set "TTSBAT=%HERE%..\karen\start_tts_server.bat"
if not exist "%TTSBAT%" goto tts_missing
if not exist "%HERE%logs" mkdir "%HERE%logs"
REM rotate the log: crash detection below must read a FRESH file
if exist "%HERE%logs\tts.log" move /y "%HERE%logs\tts.log" "%HERE%logs\tts.log.prev" >nul 2>nul
REM the CHILD must think it is hidden (skip its own `pause`, write UTF-8),
REM but this script must remember how IT was started - otherwise a manual
REM run would close its window instead of pausing after the backend exits.
set "SAVED_HIDDEN=%KAREN_HIDDEN%"
set "KAREN_HIDDEN=1"
if exist "%HERE%run_hidden.vbs" (
    wscript //nologo "%HERE%run_hidden.vbs" "%TTSBAT%" "%HERE%logs\tts.log"
    set "KAREN_HIDDEN=%SAVED_HIDDEN%"
) else (
    set "KAREN_HIDDEN=%SAVED_HIDDEN%"
    start "KAREN Voice" /min "%TTSBAT%"
)
if exist "%HERE%wait_for_port.bat" (
    call "%HERE%wait_for_port.bat" "http://127.0.0.1:8880/health" 420 "%HERE%logs\tts.log" "voice server :8880" 1 "start_tts_server"
    if errorlevel 2 echo [!!] Continuing WITHOUT the voice server - the companion will be MUTE.
    goto tts_ready
)
REM fallback waiter for a partial copy of the folder ^(no diagnostics^)
echo      Waiting for :8880 ^(up to ~5 min, first run installs the venv^)...
set /a N=0
:tts_wait
set /a N+=1
if !N! GTR 120 goto tts_timeout
ping -n 3 127.0.0.1 >nul
call :probe "http://127.0.0.1:8880/health"
if not "!PCODE!"=="200" goto tts_wait
echo [ok] Voice server is up
goto tts_ready
:tts_missing
echo [xx] start_tts_server.bat not found - the companion will be MUTE.
goto tts_ready
:tts_timeout
echo [!!] Voice server did not answer in time - continuing anyway.
:tts_ready

REM ---- API key ------------------------------------------------------------
if not defined GROQ_API_KEY (
    echo [!!] GROQ_API_KEY is not set in this session.
    echo      Permanent fix:  setx GROQ_API_KEY "gsk_..."  + reopen terminal.
    set /p "TMPKEY=Paste the key now (or press Enter to skip): "
    if not "!TMPKEY!"=="" set "GROQ_API_KEY=!TMPKEY!"
)
if defined GROQ_API_KEY (echo [ok] GROQ_API_KEY is set) else (echo [xx] LLM calls will FAIL without the key)

REM ---- quick Groq probe (~10 s, informational, never blocks start) ----
REM Catches 403 Forbidden (VPN exit blocked / RU leak) and dead keys
REM BEFORE the first chat attempt; the verdict lands in this window /
REM logs\backend.log. Needs any python3 in PATH (stdlib only).
if defined GROQ_API_KEY if exist "%HERE%scripts\test_groq_api.py" (
    set "GPY="
    where py >nul 2>nul && set "GPY=py -3"
    if not defined GPY where python >nul 2>nul && set "GPY=python"
    if defined GPY (
        echo [..] Groq API quick check ...
        !GPY! "!HERE!scripts\test_groq_api.py" --quick
    ) else (
        echo [!!] no python in PATH - Groq pre-check skipped ^(not fatal^)
    )
)

REM ---- ffmpeg ---------------------------------------------------------------
where ffmpeg >nul 2>nul
if errorlevel 1 (echo [!!] ffmpeg not found in PATH: winget install ffmpeg) else (echo [ok] ffmpeg found)

REM ---- schedule the desktop app launch (background waiter) -------------------
if not "%APP%"=="" (
    if not exist "%HERE%logs" mkdir "%HERE%logs"
    if exist "%HERE%run_hidden.vbs" (
        wscript //nologo "%HERE%run_hidden.vbs" "%HERE%wait_and_launch_app.bat" "%HERE%logs\app.log" "%APP%"
    ) else (
        start "KAREN app" /min "%HERE%wait_and_launch_app.bat" "%APP%"
    )
    echo [..] Desktop app opens automatically when the backend answers on :12393
    echo      ^(hidden waiter, log: logs\app.log^)
)

REM ---- run the backend (blocking; THIS WINDOW MUST STAY OPEN) ----------------
cd /d "%PROJ%"
echo.
echo ====================================================================
echo  Backend starting: http://localhost:12393   ^(browser NOT opened^)
echo  Stop with Ctrl+C. KEEP THIS WINDOW OPEN.
echo ====================================================================
echo.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" run_server.py
) else (
    where uv >nul 2>nul
    if errorlevel 1 (python run_server.py) else (uv run run_server.py)
)
set "EC=%errorlevel%"
echo.
echo [%date% %time%] backend exited with code %EC%
if not "%EC%"=="0" echo [xx] Backend EXITED unexpectedly ^(code %EC%^) - see the lines above.
if "%KAREN_HIDDEN%"=="1" exit /b %EC%
pause
exit /b 0

REM ---- subroutine: HTTP probe, result in PCODE -------------------------------
:probe
set "PCODE=0"
for /f "delims=" %%i in ('powershell -NoProfile -Command "try { (Invoke-WebRequest -UseBasicParsing -Uri '%~1' -TimeoutSec 3).StatusCode } catch { 0 }" 2^>nul') do set "PCODE=%%i"
exit /b 0
