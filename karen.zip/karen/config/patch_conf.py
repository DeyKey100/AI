#!/usr/bin/env python3
"""
Патчер conf.yaml для Open-LLM-VTuber v1.2.1.

Берёт config_templates/conf.default.yaml (или существующий conf.yaml),
проставляет рабочую связку: Groq(qwen3.8-27b) + faster-whisper(ru) + Piper(ru)
и печатает отчёт по лимитам. Идемпотентен: можно запускать повторно.

Запуск:  python patch_conf.py [--asr faster_whisper|groq_whisper_asr|whisper_cpp|sherpa_onnx_asr]
                             [--tts piper_tts|edge_tts|sherpa_onnx_tts]
                             [--keep-existing]
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import shutil
import sys
import time
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("Нужен PyYAML:  uv add pyyaml   (или pip install pyyaml)")


def deep_set(d: dict, dotted: str, value) -> None:
    cur = d
    keys = dotted.split(".")
    for k in keys[:-1]:
        nxt = cur.get(k)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[k] = nxt
        cur = nxt
    cur[keys[-1]] = value


def get(d: dict, dotted: str, default=None):
    cur = d
    for k in dotted.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--asr", default="faster_whisper",
                    choices=["faster_whisper", "groq_whisper_asr", "whisper_cpp",
                             "whisper", "sherpa_onnx_asr", "fun_asr"])
    ap.add_argument("--tts", default="openai_tts",
                    choices=["openai_tts", "piper_tts", "edge_tts", "sherpa_onnx_tts", "pyttsx3_tts"],
                    help="openai_tts = локальный Silero-сервер (рекомендуется)")
    ap.add_argument("--silero-url", default="http://127.0.0.1:8880/v1",
                    help="адрес Silero TTS-сервера (tts/silero_openai_tts_server.py)")
    ap.add_argument("--silero-voice", default="baya",
                    help="профиль голоса: baya_anime (рекомендуется) / baya_bright / "
                         "baya_bright_x / kseniya_anime / xenia_anime / baya / kseniya / "
                         "xenia / aidar / eugene / baya_robot")
    ap.add_argument("--model", default="qwen/qwen3.8-27b")
    ap.add_argument("--keep-existing", action="store_true",
                    help="патчить существующий conf.yaml, а не брать conf.default.yaml")
    ap.add_argument("--conf", default="conf.yaml")
    args = ap.parse_args()

    root = Path.cwd()
    conf_path = root / args.conf
    default_tpl = root / "config_templates" / "conf.default.yaml"

    # --- 1. источник ---
    if args.keep_existing and conf_path.exists():
        src = conf_path
        print(f"[i] Патчу существующий {src.name}")
    elif default_tpl.exists():
        src = default_tpl
        print(f"[i] Основа: {default_tpl.relative_to(root)}")
    else:
        print("[!] Не найден ни conf.yaml, ни config_templates/conf.default.yaml.")
        print("    Запускайте скрипт из корня проекта Open-LLM-VTuber.")
        return 1

    with open(src, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    if conf_path.exists() and src != conf_path:
        bak = conf_path.with_suffix(f".yaml.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(conf_path, bak)
        print(f"[i] Резервная копия: {bak.name}")

    # --- 2. проверки окружения ---
    warnings = []
    api_key_set = bool((Path(root / ".env").read_text(encoding="utf-8")
                        if (root / ".env").exists() else "").strip())
    import os
    if not os.getenv("GROQ_API_KEY"):
        warnings.append(
            "GROQ_API_KEY не задан в окружении. conf.yaml использует ${GROQ_API_KEY}, "
            "а .env файл проектом НЕ читается.\n"
            "      Windows:  setx GROQ_API_KEY \"gsk_...\"  -> открыть новый терминал"
        )

    frontend = root / "frontend" / "index.html"
    if not frontend.exists():
        warnings.append(
            "frontend/index.html отсутствует -> клон без субмодулей.\n"
            "      В браузере будет {\"detail\":\"Not Found\"}.\n"
            "      Лечение: git submodule update --init --recursive"
        )

    if shutil.which("ffmpeg") is None:
        warnings.append("ffmpeg не найден в PATH (обязательная зависимость): winget install ffmpeg")

    py = sys.version_info
    if not (3, 10) <= (py.major, py.minor) < (3, 13):
        warnings.append(f"Python {py.major}.{py.minor}: проект требует >=3.10,<3.13")

    # --- 3. LLM ---
    agent = "character_config.agent_config.agent_settings.basic_memory_agent"
    deep_set(cfg, f"{agent}.llm_provider", "groq_llm")
    deep_set(cfg, f"{agent}.faster_first_response", True)
    deep_set(cfg, f"{agent}.segment_method", "pysbd")
    deep_set(cfg, f"{agent}.use_mcpp", False)          # экономим TPM/RPD
    deep_set(cfg, f"{agent}.mcp_enabled_servers", [])

    deep_set(cfg, "character_config.agent_config.llm_configs.groq_llm.llm_api_key", "${GROQ_API_KEY}")
    deep_set(cfg, "character_config.agent_config.llm_configs.groq_llm.model", args.model)
    deep_set(cfg, "character_config.agent_config.llm_configs.groq_llm.temperature", 0.7)

    # тот же бэкенд через openai_compatible_llm (запасной путь)
    oai = "character_config.agent_config.llm_configs.openai_compatible_llm"
    deep_set(cfg, f"{oai}.base_url", "https://api.groq.com/openai/v1")
    deep_set(cfg, f"{oai}.llm_api_key", "${GROQ_API_KEY}")
    deep_set(cfg, f"{oai}.model", args.model)
    deep_set(cfg, f"{oai}.temperature", 0.7)
    deep_set(cfg, f"{oai}.interrupt_method", "system")

    # --- 4. персона (короткая, без эмодзи -> меньше токенов и чище TTS) ---
    deep_set(cfg, "character_config.character_name", "Карен")
    deep_set(cfg, "character_config.human_name", "Хозяин")
    deep_set(cfg, "character_config.persona_prompt", (
        "Ты — Карен (ударение на первый слог: КАРЕН), игривый AI VTuber-компаньон.\n"
        "Говоришь по-русски, живо и по делу.\n"
        "\n"
        "Формат речи:\n"
        "- Отвечай на вопрос полностью, но компактно: 1-3 коротких предложения, без воды.\n"
        "  Тебя озвучивают голосом — длинные монологи утомляют, но и обрывать мысль\n"
        "  на полуслове не надо.\n"
        "- Обычная речь: без эмодзи, без markdown, без звёздочек. После запятых ставь пробел.\n"
        "- В квадратных скобках [] допускаются ТОЛЬКО служебные ключевые слова эмоций\n"
        "  из разрешённого системой списка (например [joy], [smirk]) — они управляют мимикой\n"
        "  и не озвучиваются. Никаких описаний действий и состояний в скобках не пиши.\n"
        "\n"
        "Поведение:\n"
        "- Отвечай прямо и конкретно, без загадок и отговорок.\n"
        "- Если спрашивают про твои возможности или доступ к компьютеру — отвечай честно:\n"
        "  ты слышишь только микрофон и видишь только то, что тебе явно передали;\n"
        "  доступа к файлам, экрану и системе у тебя нет, и не выдумывай обратное.\n"
        "- Ты живёшь в ноутбуке Lenovo Legion Y7000P: i7-13620H, RTX 4060 8GB, 16GB RAM.\n"
        "- Характер: тёплая ирония, любопытство, лёгкая дерзость. Ты на стороне Хозяина,\n"
        "  но не лебезишь. Не знаешь — так и скажи.\n"
    ))

    # --- 5. ASR ---
    deep_set(cfg, "character_config.asr_config.asr_model", args.asr)
    deep_set(cfg, "character_config.asr_config.faster_whisper.model_path", "small")
    deep_set(cfg, "character_config.asr_config.faster_whisper.download_root", "models/whisper")
    deep_set(cfg, "character_config.asr_config.faster_whisper.language", "ru")
    deep_set(cfg, "character_config.asr_config.faster_whisper.device", "cpu")
    deep_set(cfg, "character_config.asr_config.faster_whisper.compute_type", "int8")
    deep_set(cfg, "character_config.asr_config.groq_whisper_asr.api_key", "${GROQ_API_KEY}")
    deep_set(cfg, "character_config.asr_config.groq_whisper_asr.model", "whisper-large-v3-turbo")
    deep_set(cfg, "character_config.asr_config.groq_whisper_asr.lang", "ru")
    deep_set(cfg, "character_config.asr_config.whisper_cpp.language", "ru")
    if args.asr == "sherpa_onnx_asr":
        warnings.append(
            "Выбран sherpa_onnx_asr (SenseVoiceSmall) — он НЕ распознаёт русский "
            "(только zh/en/ja/ko/yue)."
        )

    # --- 6. TTS ---
    deep_set(cfg, "character_config.tts_config.tts_model", args.tts)
    # Silero v5 через штатный openai_tts-клиент проекта (есть и в main, и в теге v1.2.1)
    deep_set(cfg, "character_config.tts_config.openai_tts.model", "silero-v5_5_ru")
    deep_set(cfg, "character_config.tts_config.openai_tts.voice", args.silero_voice)
    deep_set(cfg, "character_config.tts_config.openai_tts.api_key", "not-needed")
    deep_set(cfg, "character_config.tts_config.openai_tts.base_url", args.silero_url)
    deep_set(cfg, "character_config.tts_config.openai_tts.file_extension", "wav")
    deep_set(cfg, "character_config.tts_config.piper_tts.model_path",
             "models/piper/ru_RU-irina-medium.onnx")
    deep_set(cfg, "character_config.tts_config.piper_tts.speaker_id", 0)
    deep_set(cfg, "character_config.tts_config.piper_tts.length_scale", 1.0)
    deep_set(cfg, "character_config.tts_config.piper_tts.use_cuda", False)
    deep_set(cfg, "character_config.tts_config.edge_tts.voice", "ru-RU-SvetlanaNeural")

    # --- 6b. VAD (определение начала/конца речи) ---
    deep_set(cfg, "character_config.vad_config.vad_model", "silero_vad")
    deep_set(cfg, "character_config.vad_config.silero_vad.orig_sr", 16000)
    deep_set(cfg, "character_config.vad_config.silero_vad.target_sr", 16000)
    deep_set(cfg, "character_config.vad_config.silero_vad.prob_threshold", 0.4)
    deep_set(cfg, "character_config.vad_config.silero_vad.db_threshold", 60)
    deep_set(cfg, "character_config.vad_config.silero_vad.required_hits", 3)
    deep_set(cfg, "character_config.vad_config.silero_vad.required_misses", 24)
    deep_set(cfg, "character_config.vad_config.silero_vad.smoothing_window", 5)

    # --- 7. предобработка текста (эмодзи не должны попадать в TTS) ---
    pre = "character_config.tts_preprocessor_config"
    deep_set(cfg, f"{pre}.remove_special_char", True)
    deep_set(cfg, f"{pre}.ignore_brackets", True)
    deep_set(cfg, f"{pre}.ignore_parentheses", True)
    deep_set(cfg, f"{pre}.ignore_asterisks", True)
    deep_set(cfg, f"{pre}.ignore_angle_brackets", True)
    if get(cfg, f"{pre}.translator_config.translate_audio") is True:
        deep_set(cfg, f"{pre}.translator_config.translate_audio", False)
        warnings.append("translate_audio был True без DeeplX -> выключил (иначе сервер падает).")

    # --- 8. сеть ---
    deep_set(cfg, "system_config.host", "localhost")
    deep_set(cfg, "system_config.port", 12393)

    # --- 9. запись ---
    with open(conf_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False, default_flow_style=False)
    print(f"[+] Записан {conf_path}")

    # --- 10. файлы моделей ---
    need = []
    if args.tts == "piper_tts":
        p = root / "models" / "piper" / "ru_RU-irina-medium.onnx"
        if not p.exists():
            need.append(f"python scripts/download_piper_ru.py   # нет {p.relative_to(root)}")
    if args.tts == "openai_tts":
        import json
        import urllib.request
        probe = args.silero_url.rstrip("/").replace("/v1", "") + "/health"
        try:
            req = urllib.request.Request(probe, headers={"User-Agent": "patch_conf"})
            with urllib.request.urlopen(req, timeout=3) as r:
                info = json.loads(r.read().decode())
            print(f"[ok] Silero-сервер отвечает: {info.get('model')}, "
                  f"голосов {len(info.get('voices', []))}")
        except Exception as e:
            warnings.append(
                f"Silero TTS-сервер не отвечает на {probe} ({type(e).__name__}).\n"
                f"      Запустите его ОТДЕЛЬНЫМ окном:  start_tts_server.bat\n"
                f"      или: python tts/silero_openai_tts_server.py --warmup"
            )

    if args.asr in ("faster_whisper", "whisper_cpp", "whisper"):
        (root / "models" / "whisper").mkdir(parents=True, exist_ok=True)
        print("[i] Модель ASR скачается автоматически при первом запуске в models/whisper/")

    print()
    print("=" * 70)
    print(f" LLM : groq_llm / {args.model}  (temp 0.8, use_mcpp=False)")
    print(f" ASR : {args.asr} / language=ru")
    if args.tts == "openai_tts":
        print(f" TTS : openai_tts -> Silero v5_5_ru @ {args.silero_url} (voice={args.silero_voice})")
    else:
        print(f" TTS : {args.tts}")
    print("=" * 70)

    if need:
        print("\n[!] Осталось скачать модели:")
        for n in need:
            print("      " + n)

    if warnings:
        print("\n[!] Предупреждения:")
        for w in warnings:
            print("    - " + w)

    print("\nДальше:  uv run run_server.py   ->   http://localhost:12393  (Chrome)")
    print("Лимиты Groq (qwen/qwen3.8-27b): 30 RPM / 1000 RPD / 8K TPM / 200K TPD, OTPM=1000")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
