@echo off
REM =====================================================================
REM  KAREN - stop EVERYTHING: desktop app + hidden servers.
REM  No key press needed: the window shows the result for ~3 s and
REM  then closes ITSELF.
REM
REM  The servers run in HIDDEN windows (no taskbar buttons), so this is
REM  the normal way to stop them:
REM    1. kills leftover hidden cmd wrappers FIRST - otherwise the
REM       hidden waiter (wait_and_launch_app.bat) could re-launch the
REM       desktop app right after we close it
REM    2. closes the OpenLLM desktop app (Electron): graceful close
REM       request first, force-kill for anything still alive ~1.5 s later
REM    3. kills the processes listening on :8880 (voice) and :12393 (backend)
REM
REM  App search order (same as start_karen.bat):
REM    a) env var KAREN_ELECTRON_APP (full path to .lnk/.exe)
REM    b) ..\open-llm-vtuber-electron.lnk / .exe  (next to the karen folder)
REM    c) any *electron*.lnk / *electron*.exe next to the karen folder
REM  A .lnk is resolved to its real target exe name; as a fallback, any
REM  process whose name contains "vtuber" is treated as the app.
REM
REM  History (2026-09-21): v1 left the desktop app running and ended
REM  with `pause` ("press any key"). v2 closes the app too and exits
REM  by itself after ~3 s.
REM
REM  ASCII-only file.
REM =====================================================================
setlocal
title KAREN stop
set "HERE=%~dp0"
REM ---- QuickEdit OFF: a click/selection inside this window freezes all
REM ---- console writes and this window would never close itself.
if exist "%HERE%no_quickedit.ps1" powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%no_quickedit.ps1" >nul 2>&1
echo ====================================================================
echo  KAREN - stopping app + hidden servers
echo ====================================================================

REM ---- 1. hidden cmd wrappers (kill first: the waiter may re-launch
REM         the app while we are closing it) ---------------------------
echo [..] killing leftover hidden cmd wrappers ...
powershell -NoProfile -Command "$procs = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'cmd.exe' -and $_.CommandLine -match 'start_tts_server|start_vtuber|wait_and_launch_app' }; if (-not $procs) { Write-Host '     none' } ; foreach ($p in $procs) { Write-Host ('     kill wrapper PID ' + $p.ProcessId); Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }"

REM ---- 2. desktop app (Electron) --------------------------------------
set "APP=%KAREN_ELECTRON_APP%"
if not defined APP if exist "%HERE%..\open-llm-vtuber-electron.lnk" set "APP=%HERE%..\open-llm-vtuber-electron.lnk"
if not defined APP if exist "%HERE%..\open-llm-vtuber-electron.exe" set "APP=%HERE%..\open-llm-vtuber-electron.exe"
if not defined APP for %%f in ("%HERE%..\*electron*.lnk" "%HERE%..\*electron*.exe") do if not defined APP set "APP=%%~f"

echo [..] closing the OpenLLM desktop app ...
powershell -NoProfile -Command "$ErrorActionPreference='SilentlyContinue'; $names=@('open-llm-vtuber-electron'); $lnk='%APP%'; if ($lnk) { $t=$lnk; if ($lnk -like '*.lnk') { $s=(New-Object -ComObject WScript.Shell).CreateShortcut($lnk); if ($s.TargetPath) { $t=$s.TargetPath } }; $b=[IO.Path]::GetFileNameWithoutExtension($t); if ($b -and ($names -notcontains $b)) { $names+=$b } }; $procs=@(Get-Process | Where-Object { ($names -contains $_.ProcessName) -or ($_.ProcessName -like '*vtuber*') }); if ($procs.Count -eq 0) { Write-Host '     app not running' } else { foreach ($p in $procs) { Write-Host ('     close PID ' + $p.Id + ' (' + $p.ProcessName + ')'); try { [void]$p.CloseMainWindow() } catch {} }; Start-Sleep -Milliseconds 1500; foreach ($p in $procs) { try { if (-not $p.HasExited) { Write-Host ('     force kill PID ' + $p.Id); Stop-Process -Id $p.Id -Force } } catch {} } }"

REM ---- 3. servers on :8880 and :12393 ----------------------------------
echo [..] killing listeners on :8880 and :12393 ...
powershell -NoProfile -Command "$ids = Get-NetTCPConnection -LocalPort 8880,12393 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique; if (-not $ids) { Write-Host '     nothing is listening' } ; foreach ($p in $ids) { try { $n = (Get-Process -Id $p).ProcessName } catch { $n = '?' } ; Write-Host ('     kill PID ' + $p + ' (' + $n + ')'); Stop-Process -Id $p -Force -ErrorAction SilentlyContinue }"

echo.
echo [ok] Done: desktop app + hidden servers stopped.
echo      Logs stay in: %HERE%logs\
echo      This window closes itself in ~3 s.
REM ping-based sleep: unlike `timeout` it also works when the output is
REM redirected. -n 4 = three 1-second waits = ~3 s.
ping -n 4 127.0.0.1 >nul
exit /b 0
