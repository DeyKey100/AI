@echo off
REM =====================================================================
REM  KAREN - open all logs in Notepad.
REM  The servers run hidden; their output is written to karen\logs\:
REM    tts.log      - voice server (Silero, :8880)
REM    backend.log  - VTuber backend (:12393)
REM    app.log      - desktop-app waiter (why/when the app was launched)
REM  Deep backend logs (with timestamps per stage) live in
REM  Open-LLM-VTuber\logs\debug_YYYY-MM-DD.log
REM
REM  ASCII-only file.
REM =====================================================================
setlocal
set "HERE=%~dp0"
set /a OPENED=0
if exist "%HERE%logs\tts.log"     ( start notepad "%HERE%logs\tts.log"     & set /a OPENED+=1 )
if exist "%HERE%logs\backend.log" ( start notepad "%HERE%logs\backend.log" & set /a OPENED+=1 )
if exist "%HERE%logs\app.log"     ( start notepad "%HERE%logs\app.log"     & set /a OPENED+=1 )
if %OPENED%==0 (
    echo No logs yet in %HERE%logs\
    echo Start KAREN first: start_karen.bat
    pause
)
exit /b 0
