﻿# =====================================================================
#  KAREN helper - disables QuickEdit mode for the CURRENT console window.
#
#  Why this file exists (2026-09-21 bug report):
#  With QuickEdit ON (the Windows default), a single mouse click inside a
#  cmd window puts the console into "select" mode and FREEZES every write
#  to it. The batch script blocks mid-echo, `timeout`/`ping` never finish
#  and the window never closes. The owner reported the launcher window
#  stuck at "This window closes in 3 s." - and the pasted text ended
#  exactly before the closing separator line, i.e. the console froze
#  while he was selecting text in it.
#
#  start_karen.bat / stop_karen.bat are short-lived; everything they do
#  is logged to karen\logs (open_logs.bat), so text selection inside
#  these two windows is not needed. Debug windows (start_tts_server.bat,
#  start_vtuber.bat) deliberately KEEP QuickEdit: freezing output there
#  is a feature when you read a crash.
#
#  A child powershell.exe shares the parent console, and console modes
#  are per-console (not per-process), so the change persists after this
#  script exits. Best effort: any failure is ignored, exit code is 0.
#
#  ASCII-only. No BOM required (pure ASCII content).
# =====================================================================
try {
    if (-not ('Karen.KarenConsole' -as [type])) {
        Add-Type -Name KarenConsole -Namespace Karen -MemberDefinition @'
[DllImport("kernel32.dll")] public static extern System.IntPtr GetStdHandle(int nStdHandle);
[DllImport("kernel32.dll")] public static extern bool GetConsoleMode(System.IntPtr hConsoleHandle, out uint lpMode);
[DllImport("kernel32.dll")] public static extern bool SetConsoleMode(System.IntPtr hConsoleHandle, uint dwMode);
'@
    }
    $hIn = [Karen.KarenConsole]::GetStdHandle(-10)   # STD_INPUT_HANDLE
    $mode = [uint32]0
    if ([Karen.KarenConsole]::GetConsoleMode($hIn, [ref]$mode)) {
        # clear ENABLE_QUICK_EDIT_MODE (0x0040), set ENABLE_EXTENDED_FLAGS (0x0080)
        $new = [uint32]((($mode -bor 0x0080) -band (-bnot 0x0040)))
        [void][Karen.KarenConsole]::SetConsoleMode($hIn, $new)
    }
} catch {
    # best effort - never break the launcher because of this helper
}
exit 0
