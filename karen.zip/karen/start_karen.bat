@echo off
REM =====================================================================
REM  KAREN - ONE-CLICK launcher (silent edition).
REM
REM  Starts everything in HIDDEN windows - nothing appears on the taskbar:
REM    0. Karing VPN - started FIRST; api.groq.com is blocked in RU
REM       without it. Default: D:\Programms\Karing\karing.exe
REM       (override: setx KAREN_VPN "full path to karing.exe").
REM       Skipped when Karing is already running.
REM    1. KAREN Voice server (:8880)   log: karen\logs\tts.log
REM    2. VTuber backend     (:12393)  log: karen\logs\backend.log
REM    3. desktop Electron app - opened by a hidden waiter as soon as the
REM       backend answers                          log: karen\logs\app.log
REM  The browser is NOT opened.
REM
REM  This launcher window shows progress and then closes itself.
REM  If a server dies, the reason is printed HERE (tail of its log) and
REM  the window STAYS OPEN - no more silent 10-minute hangs.
REM    Stop everything : stop_karen.bat
REM    Read logs       : open_logs.bat
REM
REM  Desktop shortcut: right-click this file -> Send to -> Desktop
REM  (create shortcut). Rename it to KAREN, set any icon you like.
REM
REM  App shortcut search order:
REM    a) env var KAREN_ELECTRON_APP (full path to .lnk/.exe)
REM    b) ..\open-llm-vtuber-electron.lnk / .exe   (next to the karen folder)
REM    c) any *electron*.lnk / *electron*.exe next to the karen folder
REM
REM  ASCII-only file (cmd.exe decodes .bat in the OEM codepage).
REM =====================================================================
setlocal enabledelayedexpansion
title KAREN launcher
set "HERE=%~dp0"
REM ---- QuickEdit OFF ----------------------------------------------------
REM With QuickEdit ON (Windows default) a mouse click / text selection in
REM this window FREEZES all console writes: the script stops mid-echo and
REM the window never closes (2026-09-21 report: stuck at "closes in 3 s"
REM right after the owner selected text in it). Everything is logged to
REM karen\logs, so text selection in THIS window is not needed.
if exist "%HERE%no_quickedit.ps1" powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%no_quickedit.ps1" >nul 2>&1
if not exist "%HERE%logs" mkdir "%HERE%logs"
if not exist "%HERE%wait_for_port.bat" (
    echo [xx] wait_for_port.bat not found next to this file.
    echo      Copy the WHOLE karen folder, not separate files.
    pause
    exit /b 1
)
if not exist "%HERE%run_hidden.vbs" (
    echo [xx] run_hidden.vbs not found next to this file.
    pause
    exit /b 1
)

REM Children (start_tts_server.bat / start_vtuber.bat) see KAREN_HIDDEN=1
REM and then: (a) do not call `pause` in an invisible window, which would
REM leave a zombie cmd.exe forever, (b) force UTF-8 for Python output.
set "KAREN_HIDDEN=1"

echo ====================================================================
echo  KAREN - one-click start  (hidden mode, logs in karen\logs\)
echo ====================================================================

REM ---- 0. VPN (Karing): api.groq.com is unreachable from RU without it --
REM Path override: setx KAREN_VPN "full path to karing.exe"
set "VPN=%KAREN_VPN%"
if not defined VPN set "VPN=D:\Programms\Karing\karing.exe"
for %%i in ("%VPN%") do set "VPNEXE=%%~nxi"
tasklist /fi "imagename eq %VPNEXE%" 2>nul | find /i "%VPNEXE%" >nul
if not errorlevel 1 (
    echo [ok] VPN already running: %VPNEXE%
    goto vpn_done
)
if not exist "%VPN%" (
    echo [!!] VPN not found: %VPN%
    echo      Groq API may be unreachable - start your VPN manually.
    echo      Different path: setx KAREN_VPN "full path to karing.exe"
    goto vpn_done
)
echo [..] Starting VPN: %VPN%
start "" "%VPN%"
REM give the tunnel a few seconds before anything calls Groq
REM ping-based sleep: unlike `timeout` it never hangs and also works
REM when the console input/output is redirected (same as stop_karen.bat).
ping -n 4 127.0.0.1 >nul
:vpn_done

REM ---- rotate the logs so crash detection reads a FRESH file ------------
for %%L in (tts backend app) do (
    if exist "%HERE%logs\%%L.log" move /y "%HERE%logs\%%L.log" "%HERE%logs\%%L.log.prev" >nul 2>nul
)

REM ---- 1. voice server :8880 -------------------------------------------
call :probe "http://127.0.0.1:8880/health"
if "!PCODE!"=="200" (
    echo [ok] Voice server already running on :8880
    goto voice_done
)
if not exist "%HERE%start_tts_server.bat" (
    echo [xx] start_tts_server.bat not found next to this file.
    pause
    exit /b 1
)
echo [..] Starting voice server - HIDDEN, log: logs\tts.log
echo      ^(first run installs its venv: up to ~5 min. Otherwise ~10 s.^)
echo      ^(a crash is reported here within seconds, not after a timeout^)
wscript //nologo "%HERE%run_hidden.vbs" "%HERE%start_tts_server.bat" "%HERE%logs\tts.log"
call "%HERE%wait_for_port.bat" "http://127.0.0.1:8880/health" 420 "%HERE%logs\tts.log" "voice server :8880" 1 "start_tts_server"
if errorlevel 3 goto voice_crashed
if errorlevel 2 goto voice_timeout
goto voice_done

:voice_crashed
echo.
echo ====================================================================
echo  [xx] The VOICE SERVER died. The companion would be mute, so the
echo       backend was NOT started. Fix the reason above, then re-run.
echo.
echo  Most common causes:
echo    - Python 3.13+ / missing torch in karen\tts\.venv-silero
echo      fix: delete the folder karen\tts\.venv-silero and re-run
echo    - port 8880 taken by another program
echo      fix: netstat -ano ^| findstr :8880
echo    - unicode/encoding crash (fixed on 2026-09-21; update your copy)
echo.
echo  To watch the voice server LIVE in a visible window:
echo      double-click  start_tts_server.bat
echo  Start WITHOUT voice anyway (text chat only):  start_vtuber.bat
echo ====================================================================
pause
exit /b 1

:voice_timeout
echo [!!] Continuing WITHOUT the voice server - the companion will be mute.
echo      Check logs\tts.log ^(open_logs.bat^). First run may simply be slow.
:voice_done

REM ---- 2. backend :12393 (its hidden waiter opens the desktop app) ------
set "FRESH_BACKEND=0"
call :probe "http://127.0.0.1:12393/"
if "!PCODE!"=="200" (
    echo [ok] Backend already running on :12393
    goto backend_done
)
if not exist "%HERE%start_vtuber.bat" (
    echo [xx] start_vtuber.bat not found next to this file.
    pause
    exit /b 1
)
echo [..] Starting backend - HIDDEN, log: logs\backend.log
wscript //nologo "%HERE%run_hidden.vbs" "%HERE%start_vtuber.bat" "%HERE%logs\backend.log"
set "FRESH_BACKEND=1"
call "%HERE%wait_for_port.bat" "http://127.0.0.1:12393/" 240 "%HERE%logs\backend.log" "backend :12393" 1 "start_vtuber"
if errorlevel 3 goto backend_crashed
if errorlevel 2 echo [!!] Backend not ready after ~4 min - read logs\backend.log
goto backend_done

:backend_crashed
echo.
echo ====================================================================
echo  [xx] The BACKEND died. See the log tail above; the full log is
echo       karen\logs\backend.log  ^(open_logs.bat^).
echo  Most common causes:
echo    - conf.yaml is invalid or missing   ^(re-run scripts\setup_windows.ps1^)
echo    - GROQ_API_KEY not set              ^(setx GROQ_API_KEY "gsk_..."^)
echo    - dependencies missing              ^(cd Open-LLM-VTuber ^&^& uv sync^)
echo    - port 12393 taken                  ^(netstat -ano ^| findstr :12393^)
echo ====================================================================
pause
exit /b 1
:backend_done

REM ---- 3. desktop app ---------------------------------------------------
REM If WE started the backend, start_vtuber.bat has already scheduled its
REM own hidden waiter for the app. Launching here as well would open a
REM second instance, so this branch is only for the "everything was
REM already running" case (a repeated click on this launcher).
if "%FRESH_BACKEND%"=="1" (
    echo [..] Desktop app will open automatically ^(hidden waiter, logs\app.log^).
    goto finish
)
call :findapp
if not defined APP (
    echo [!!] Desktop app not found. Put open-llm-vtuber-electron.lnk next
    echo    to the karen folder, or: setx KAREN_ELECTRON_APP "full path"
    goto finish
)
echo [..] Launching desktop app: %APP%
start "" "%APP%" 2>nul
if errorlevel 1 explorer "%APP%"

:finish
echo.
echo ====================================================================
echo  Everything runs HIDDEN in the background now.
echo    stop  : stop_karen.bat
echo    logs  : open_logs.bat   (karen\logs\)
echo  This window closes in 3 s.
echo ====================================================================
REM ping-based sleep: `timeout /t` hangs forever in a console whose
REM input got redirected or frozen (QuickEdit selection) - that was the
REM "window never closes" bug of 2026-09-21. ping always finishes.
ping -n 4 127.0.0.1 >nul
exit /b 0

REM ---- subroutine: HTTP probe, result in PCODE --------------------------
:probe
set "PCODE=0"
for /f "delims=" %%i in ('powershell -NoProfile -Command "try { (Invoke-WebRequest -UseBasicParsing -Uri '%~1' -TimeoutSec 3).StatusCode } catch { 0 }" 2^>nul') do set "PCODE=%%i"
exit /b 0

REM ---- subroutine: find + normalize the desktop app -> APP --------------
:findapp
set "APP=%KAREN_ELECTRON_APP%"
if not defined APP if exist "%HERE%..\open-llm-vtuber-electron.lnk" set "APP=%HERE%..\open-llm-vtuber-electron.lnk"
if not defined APP if exist "%HERE%..\open-llm-vtuber-electron.exe" set "APP=%HERE%..\open-llm-vtuber-electron.exe"
if not defined APP for %%f in ("%HERE%..\*electron*.lnk" "%HERE%..\*electron*.exe") do if not defined APP set "APP=%%~f"
if not defined APP exit /b 0
REM Normalize the path: remove ".." segments. cmd's `start` refuses such
REM paths with "The syntax of the file name, directory name, or volume
REM label is incorrect" - this was the 2026-09-21 bug.
set "APPN="
for /f "delims=" %%i in ('powershell -NoProfile -Command "(Resolve-Path -LiteralPath '%APP%').Path" 2^>nul') do set "APPN=%%i"
if defined APPN set "APP=%APPN%"
exit /b 0
