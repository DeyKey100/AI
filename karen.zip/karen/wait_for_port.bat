@echo off
REM =====================================================================
REM  KAREN helper - wait for an HTTP endpoint, WITH DIAGNOSTICS.
REM
REM  Usage (from another .bat, same window):
REM    call "%HERE%wait_for_port.bat" "http://127.0.0.1:8880/health" 420 "%HERE%logs\tts.log" "voice server :8880" 1 "start_tts_server"
REM      arg1 url        endpoint to probe
REM      arg2 maxsec     give up after this many seconds (default 180)
REM      arg3 logfile    log of the hidden process ("" = no log checks)
REM      arg4 label      human-readable name for messages
REM      arg5 crashchk   1 = abort early when the process died / log is fatal
REM      arg6 procmatch  regex for the wrapper process (e.g. start_tts_server).
REM                       Used to tell "still installing" from "already dead".
REM
REM  Returns errorlevel:  0 = up, 2 = timeout, 3 = crashed, 4 = bad args
REM
REM  WHY THIS FILE EXISTS
REM  --------------------
REM  2026-09-21: the voice server died instantly (UnicodeEncodeError: its
REM  banner contained an arrow U+2192, and with stdout redirected to
REM  logs\tts.log Python used the locale codepage cp1251). Meanwhile
REM  start_karen.bat silently probed the dead port for 10 minutes and the
REM  owner stared at a frozen window. Now the crash is detected within
REM  seconds and the tail of the log is printed right in the launcher.
REM
REM  HOW CRASH DETECTION WORKS (two independent signals, no false alarms)
REM    a) FATAL markers in the log - only errors that certainly kill the
REM       process (UnicodeEncodeError, ModuleNotFoundError, port busy, our
REM       own [xx] marker). A plain "Traceback" is NOT enough on its own:
REM       loguru may print a handled one while the server keeps working.
REM    b) PROCESS ALIVE check (every ~6 s) - the hidden cmd.exe wrapper
REM       lives exactly as long as the server it runs, so "wrapper gone +
REM       port down" means death, whatever the reason (OOM, antivirus,
REM       python not found, crash without a traceback).
REM
REM  ASCII-only file (cmd.exe decodes .bat in the OEM codepage).
REM =====================================================================
setlocal enabledelayedexpansion
set "URL=%~1"
set "MAXS=%~2"
set "LOGF=%~3"
set "LBL=%~4"
set "CRASHCHK=%~5"
set "PMATCH=%~6"
if "%URL%"=="" exit /b 4
if "%MAXS%"=="" set "MAXS=180"
if "%LBL%"=="" set "LBL=%URL%"
if "%CRASHCHK%"=="" set "CRASHCHK=0"

set /a T=0
set /a STALL=0
set /a LASTSZ=-1
set /a WARNED=0
set /a DEADCNT=0

:loop
call :probe "%URL%"
if "!PCODE!"=="200" (
    echo [ok] %LBL% is up   ^(waited ~!T! s^)
    endlocal & exit /b 0
)

REM ---- signal (a): fatal marker in the log ------------------------------
if "%CRASHCHK%"=="1" if not "%LOGF%"=="" if exist "%LOGF%" (
    findstr /L /I /M /C:"UnicodeEncodeError" /C:"ModuleNotFoundError" /C:"No module named" /C:"Address already in use" /C:"error while attempting to bind" /C:"[xx]" "%LOGF%" >nul 2>nul
    if not errorlevel 1 goto crashed
)

REM ---- signal (b): is the hidden process still alive? (every ~6 s) ------
if "%CRASHCHK%"=="1" if not "%PMATCH%"=="" (
    set /a MOD6=!T! %% 6
    if !MOD6! EQU 0 if !T! GEQ 6 (
        call :alive "%PMATCH%"
        REM Two consecutive misses are required: an antivirus can hold the
        REM spawn of cmd.exe for several seconds, and one reading alone would
        REM abort a perfectly healthy first run.
        if "!ALIVE!"=="1" (
            set /a DEADCNT=0
        ) else (
            set /a DEADCNT+=1
            if !DEADCNT! GEQ 2 goto dead
        )
    )
)

if !T! GEQ %MAXS% goto timeout
set /a T+=2

REM ---- progress every ~10 s, with the log size so growth is visible ----
set /a MOD=!T! %% 10
if !MOD! EQU 0 (
    set "SZ=0"
    if not "%LOGF%"=="" if exist "%LOGF%" for %%A in ("%LOGF%") do set "SZ=%%~zA"
    echo      [..] %LBL%: waiting... !T! s of %MAXS% s   ^(log: !SZ! bytes^)
    if !SZ! EQU !LASTSZ! (set /a STALL+=10) else (set /a STALL=0)
    set "LASTSZ=!SZ!"
    if !STALL! GEQ 60 if !WARNED! EQU 0 (
        set /a WARNED=1
        echo      [!!] %LBL%: the log has not grown for !STALL! s.
        call :tail "%LOGF%" 8
    )
)

REM ping-based sleep: unlike `timeout`, it works with redirected output
ping -n 3 127.0.0.1 >nul
goto loop

:dead
echo.
echo [xx] %LBL% - the hidden process is GONE and the port never opened.
echo      ^(that is not a timeout: nothing is running anymore^)
goto report

:crashed
echo.
echo [xx] %LBL% CRASHED - the log contains a fatal error.
:report
echo ----------------------------------------------------------------------
call :tail "%LOGF%" 22
echo ----------------------------------------------------------------------
echo      Full log : %LOGF%
echo      All logs : open_logs.bat
echo      Watch it LIVE in a visible window: double-click start_tts_server.bat
echo      ^(for the backend: double-click start_vtuber.bat^)
endlocal & exit /b 3

:timeout
echo [!!] %LBL% did not answer within %MAXS% s.
if not "%LOGF%"=="" (
    echo      Last lines of %LOGF%:
    call :tail "%LOGF%" 12
)
endlocal & exit /b 2

REM ---- subroutine: HTTP probe -> PCODE ----------------------------------
:probe
set "PCODE=0"
for /f "delims=" %%i in ('powershell -NoProfile -Command "try { $r = Invoke-WebRequest -UseBasicParsing -Uri '%~1' -TimeoutSec 3; if ($r.StatusCode -eq 200) { '200' } else { '0' } } catch { '0' }" 2^>nul') do set "PCODE=%%i"
exit /b 0

REM ---- subroutine: is a process with this command line alive? -> ALIVE ---
:alive
set "ALIVE=0"
REM NOTE: powershell.exe itself is excluded - its own command line contains
REM the search pattern, so without this filter the check always says "alive".
for /f "delims=" %%i in ('powershell -NoProfile -Command "if (Get-CimInstance Win32_Process | Where-Object { $_.Name -ne 'powershell.exe' -and $_.ProcessId -ne $PID -and $_.CommandLine -match '%~1' }) { '1' } else { '0' }" 2^>nul') do set "ALIVE=%%i"
exit /b 0

REM ---- subroutine: print the last N lines of a file ---------------------
:tail
if "%~1"=="" exit /b 0
if not exist "%~1" (
    echo      ^(log %~1 does not exist - the hidden process never started.
    echo       Check that run_hidden.vbs is present and not blocked by
    echo       antivirus / group policy: wscript may be disabled.^)
    exit /b 0
)
set "TN=%~2"
if "%TN%"=="" set "TN=15"
powershell -NoProfile -Command "Get-Content -LiteralPath '%~1' -Tail %TN% -Encoding UTF8" 2>nul
exit /b 0
