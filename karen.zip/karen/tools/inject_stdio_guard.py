#!/usr/bin/env python3
"""
Встраивает «KAREN stdio guard» во все Python-файлы проекта (идемпотентно).

ЗАЧЕМ
-----
Реальный инцидент 2026-09-21: голосовой сервер запускался СКРЫТО через
run_hidden.vbs, stdout уходил в файл logs\\tts.log. В этом режиме Python
берёт для stdout кодировку локали (cp1251 на русской Windows), и первый же
символ вне cp1251 - стрелка U+2192 в баннере - убил процесс:

    UnicodeEncodeError: 'charmap' codec can't encode character '\\u2192'

Симптом снаружи: start_karen.bat «висит» на строке Starting voice server,
а сервера уже нет. Guard делает три вещи:
  1. консоль (isatty) - keeps its codepage, errors='replace'  -> кириллица
     читается, экзотика заменяется на '?', падения нет;
  2. файл/pipe        - encoding='utf-8', errors='replace'   -> лог в UTF-8,
     Notepad и VS Code читают его корректно;
  3. любой print больше не может уронить процесс из-за кодировки.

ЗАПУСК
------
    python tools/inject_stdio_guard.py            # встроить во все .py
    python tools/inject_stdio_guard.py --check     # только проверить (exit 1)
    python tools/inject_stdio_guard.py file.py ... # только указанные файлы

Точка вставки: ПОСЛЕ docstring модуля и ПОСЛЕ всех `from __future__ import`
(иначе SyntaxError). Проверка наличия guard - tools/final_check.py, шаг [3c].
"""
from __future__ import annotations

import ast
import glob
import io
import os
import sys

MARK = "_karen_fix_stdio"

GUARD = '''
# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------
'''.strip("\n")


def insertion_line(src: str) -> int:
    """0-based индекс строки, куда вставлять guard."""
    idx = 0
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return 0
    body = tree.body
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) \
            and isinstance(body[0].value.value, str):
        idx = body[0].end_lineno          # строка ПОСЛЕ docstring
        body = body[1:]
    for node in body:
        if isinstance(node, ast.ImportFrom) and node.module == "__future__":
            idx = node.end_lineno
        else:
            break
    # не разрывать shebang/кодинг-декларацию: они всегда в первых двух строках
    return max(idx, 0)


def process(path: str, check_only: bool) -> str:
    raw = open(path, "rb").read()
    src = raw.decode("utf-8")
    if MARK in src:
        return "already"
    if check_only:
        return "missing"
    lines = src.split("\n")
    at = insertion_line(src)
    at = min(at, len(lines))
    new = lines[:at] + ["", GUARD] + lines[at:]
    out = "\n".join(new)
    # сохраняем исходные концы строк (CRLF для Windows)
    nl = "\r\n" if b"\r\n" in raw else "\n"
    data = out.replace("\r\n", "\n").replace("\n", nl).encode("utf-8")
    if raw.startswith(b"\xef\xbb\xbf"):
        data = b"\xef\xbb\xbf" + data
    with open(path, "wb") as fh:
        fh.write(data)
    return "injected"


def main() -> int:
    argv = [a for a in sys.argv[1:]]
    check_only = "--check" in argv
    argv = [a for a in argv if not a.startswith("--")]
    root = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    files = argv or sorted(glob.glob(os.path.join(root, "**", "*.py"), recursive=True))
    files = [f for f in files if os.path.basename(f) != os.path.basename(__file__)]
    bad = 0
    for f in files:
        st = process(f, check_only)
        rel = os.path.relpath(f, root)
        if st == "missing":
            bad += 1
            print(f"    FAIL  {rel}: guard отсутствует")
        elif st == "injected":
            print(f"    ok    {rel}: guard встроен")
            try:
                compile(io.open(f, encoding="utf-8-sig").read(), f, "exec")
            except SyntaxError as e:
                bad += 1
                print(f"    FAIL  {rel}: не компилируется после вставки: {e}")
        else:
            print(f"    ok    {rel}: guard уже есть")
    if bad:
        print(f"\n[xx] проблем: {bad}")
        return 1
    print("\n[ok] все Python-файлы защищены от UnicodeEncodeError на cp1251")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
