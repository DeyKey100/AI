#!/usr/bin/env python3
"""Валидация YAML-конфигов настоящей pydantic-схемой Open-LLM-VTuber.

Нужен «мини-проект» со скачанным src/open_llm_vtuber/config_manager
(создаётся tools/fetch_schema.py) и установленные pydantic + loguru + chardet + pyyaml.

Запуск:
    python tools/validate_config.py --schema <путь к мини-проекту> <файлы.yaml ...>
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import os
import sys

import yaml


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--schema", required=True, help="корень мини-проекта с src/open_llm_vtuber")
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()

    sys.path.insert(0, os.path.join(args.schema, "src"))
    cwd = os.getcwd()
    os.chdir(args.schema)          # read_yaml/валидаторы ожидают корень проекта
    try:
        from open_llm_vtuber.config_manager import validate_config  # noqa: E402
    except ImportError as e:
        return print(f"[xx] не удалось импортировать config_manager: {e}") or 2

    failed = 0
    for path in args.files:
        path = os.path.join(cwd, path) if not os.path.isabs(path) else path
        try:
            with open(path, encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except Exception as e:  # noqa: BLE001
            failed += 1
            print(f"[YAML-ERROR] {os.path.basename(path)}: {str(e)[:200]}")
            continue
        if not isinstance(data, dict):
            failed += 1
            print(f"[INVALID] {os.path.basename(path)}: не словарь")
            continue
        try:
            cfg = validate_config(data)
            cc = cfg.character_config
            agent = cc.agent_config.agent_settings.basic_memory_agent
            llm = getattr(cc.agent_config.llm_configs, agent.llm_provider, None)
            tts = cc.tts_config
            voice = ""
            if tts.tts_model == "openai_tts" and tts.openai_tts:
                voice = f" voice={tts.openai_tts.voice} url={tts.openai_tts.base_url}"
            elif tts.tts_model == "piper_tts" and tts.piper_tts:
                voice = f" model={tts.piper_tts.model_path}"
            elif tts.tts_model == "edge_tts" and tts.edge_tts:
                voice = f" voice={tts.edge_tts.voice}"
            print(f"[OK]      {os.path.basename(path)}")
            print(f"          персона={cc.character_name!r}  llm={agent.llm_provider}"
                  f"{' (' + str(getattr(llm, 'model', '?')) + ')' if llm else ''}")
            print(f"          asr={cc.asr_config.asr_model}  tts={tts.tts_model}{voice}"
                  f"  vad={cc.vad_config.vad_model}")
            print(f"          persona_prompt: {len(cc.persona_prompt)} симв."
                  f" (~{len(cc.persona_prompt) // 4} токенов в каждом запросе)")
        except Exception as e:  # noqa: BLE001
            failed += 1
            print(f"[INVALID] {os.path.basename(path)}")
            for line in str(e).splitlines()[:14]:
                print("          " + line)
        print()
    os.chdir(cwd)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
