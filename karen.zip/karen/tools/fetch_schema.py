"""Служебный скрипт: собрать «мини-проект» Open-LLM-VTuber (только config_manager + шаблон)
для офлайн-валидации конфигов настоящей pydantic-схемой. Используется при разработке артефактов.
"""

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------
import json
import os
import sys
import urllib.request

UA = {"User-Agent": "Mozilla/5.0"}
B = "https://raw.githubusercontent.com/Open-LLM-VTuber/Open-LLM-VTuber/main/"
API = "https://api.github.com/repos/Open-LLM-VTuber/Open-LLM-VTuber/contents/src/open_llm_vtuber/config_manager?ref=main"


def get(url, dest=None):
    req = urllib.request.Request(url, headers=UA)
    data = urllib.request.urlopen(req, timeout=60).read()
    if dest:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(data)
    return data.decode("utf-8", "replace")


def main():
    proj = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.getcwd(), "olv-schema")
    cm = os.path.join(proj, "src", "open_llm_vtuber", "config_manager")
    os.makedirs(cm, exist_ok=True)
    os.makedirs(os.path.join(proj, "src", "open_llm_vtuber"), exist_ok=True)
    for p in (os.path.join(proj, "src", "__init__.py"),
              os.path.join(proj, "src", "open_llm_vtuber", "__init__.py")):
        open(p, "w").close()
    os.makedirs(os.path.join(proj, "frontend"), exist_ok=True)
    open(os.path.join(proj, "frontend", "index.html"), "w").close()

    files = ["__init__.py", "agent.py", "asr.py", "character.py", "i18n.py", "live.py",
             "main.py", "stateless_llm.py", "system.py", "tts.py", "tts_preprocessor.py",
             "utils.py", "vad.py"]
    for f in files:
        get(B + "src/open_llm_vtuber/config_manager/" + f, os.path.join(cm, f))
    print(f"[ok] {len(files)} модулей config_manager -> {cm}")
    get(B + "config_templates/conf.default.yaml",
        os.path.join(proj, "config_templates", "conf.default.yaml"))
    print("[ok] config_templates/conf.default.yaml")
    print(f"[ok] мини-проект готов: {proj}")


if __name__ == "__main__":
    main()
