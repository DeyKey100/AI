#!/usr/bin/env python3
"""
Сборка index.html из index.template.html.

Зачем: предпросмотр HTML в песочнице (sandboxed iframe) не подтягивает соседние
файлы по относительным путям, поэтому <audio src="audio/..."> показывает 0:00
и не играет. Сборщик встраивает аудио прямо в страницу как data URI — после
этого index.html полностью автономен: его можно открыть в любом превью,
скинуть одним файлом в мессенджер или открыть с флешки.

Что делать при правках:
    1. редактируете index.template.html (там обычные пути audio/...);
    2. запускаете  python tools/build_index.py;
    3. index.html пересобирается.

Проверка после сборки печатается: сколько ссылок заменено, итоговый размер,
и совпадает ли число дорожек с числом файлов в audio/.

Запуск:  python tools/build_index.py [--root <корень проекта>]
"""
from __future__ import annotations

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------

import argparse
import base64
import mimetypes
import os
import re
import sys

SRC_NAME = "index.template.html"
DST_NAME = "index.html"
AUDIO_RE = re.compile(r'src="(audio/[^"]+)"')


def mime_of(path: str) -> str:
    """MIME для аудио. Таблица важнее mimetypes: последний для .wav отдаёт
    устаревший audio/x-wav, а нам нужен audio/wav."""
    ext = os.path.splitext(path)[1].lower()
    table = {".wav": "audio/wav", ".mp3": "audio/mpeg", ".ogg": "audio/ogg",
             ".m4a": "audio/mp4", ".flac": "audio/flac", ".opus": "audio/opus"}
    if ext in table:
        return table[ext]
    guessed, _ = mimetypes.guess_type(path)
    return guessed or "application/octet-stream"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None, help="корень проекта (по умолчанию — родитель tools/)")
    args = ap.parse_args()

    root = args.root or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = os.path.join(root, SRC_NAME)
    dst = os.path.join(root, DST_NAME)

    if not os.path.isfile(src):
        print(f"[xx] не найден шаблон: {src}")
        return 1

    html = open(src, encoding="utf-8").read()
    refs = AUDIO_RE.findall(html)
    if not refs:
        print(f"[!!] в {SRC_NAME} не найдено ни одной ссылки audio/... — собирать нечего")

    total_raw = 0
    replaced = 0
    missing = []
    for ref in dict.fromkeys(refs):                      # без повторов, порядок сохранён
        path = os.path.join(root, ref.replace("/", os.sep))
        if not os.path.isfile(path):
            missing.append(ref)
            continue
        raw = open(path, "rb").read()
        total_raw += len(raw)
        b64 = base64.b64encode(raw).decode("ascii")
        html = html.replace(f'src="{ref}"', f'src="data:{mime_of(path)};base64,{b64}"')
        replaced += 1
        print(f"  [+] {ref:44s} {len(raw)/1024:7.0f} КБ -> data URI")

    note = (f'<!-- СОБРАНО АВТОМАТИЧЕСКИ: tools/build_index.py из {SRC_NAME}. '
            f'Не редактируйте этот файл — правьте шаблон и пересобирайте. '
            f'Аудио встроено как data URI ({replaced} дорожек, {total_raw/1048576:.2f} МБ исходников), '
            f'поэтому страница работает даже в песочнице без доступа к соседним файлам. -->\n')
    if not html.lstrip().startswith("<!-- СОБРАНО АВТОМАТИЧЕСКИ"):
        html = note + html

    with open(dst, "w", encoding="utf-8") as f:
        f.write(html)

    size = os.path.getsize(dst)
    print(f"\n[+] {DST_NAME}: {size/1048576:.2f} МБ")
    if missing:
        print(f"[!!] НЕ НАЙДЕНЫ файлы ({len(missing)}): " + ", ".join(missing))
    if replaced != len(set(refs)):
        print(f"[!!] заменено {replaced} из {len(set(refs))} уникальных ссылок")

    # контроль: все ли аудиофайлы проекта задействованы
    on_disk = []
    adir = os.path.join(root, "audio")
    for r, _d, files in os.walk(adir):
        for fn in files:
            if fn.lower().endswith((".wav", ".mp3", ".ogg", ".m4a", ".flac")):
                on_disk.append(os.path.relpath(os.path.join(r, fn), root).replace(os.sep, "/"))
    unused = sorted(set(on_disk) - set(refs))
    print(f"[i] аудиофайлов на диске: {len(on_disk)}, дорожек в странице: {replaced}")
    if unused:
        print(f"[i] не встроено в страницу (это нормально, если они служебные): "
              + ", ".join(unused))
    if size > 12 * 1024 * 1024:
        print("[!!] страница больше 12 МБ — превью может тормозить; "
              "рассмотрите mp3/ogg вместо wav")

    ok = not missing and replaced == len(set(refs))
    print("\n" + ("[OK] сборка успешна" if ok else "[xx] сборка с предупреждениями"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
