"""Финальная приёмка проекта КАРЕН: компиляция, ссылки, ключи, мусор."""

# --- KAREN stdio guard -----------------------------------------------------
# На русской Windows Python выбирает для stdout кодировку локали (cp1251).
# Если вывод перенаправлен в файл (скрытый запуск через run_hidden.vbs),
# любой символ вне cp1251 - стрелка, эмодзи, псевдографика - даёт
# UnicodeEncodeError и УБИВАЕТ процесс. Так 2026-09-21 упал голосовой сервер.
# Консоль сохраняет свою кодовую страницу (кириллица читается), лог-файл
# становится UTF-8, а непереводимые символы превращаются в '?' вместо падения.
import sys as _karen_sys


def _karen_fix_stdio() -> None:
    for _st in (_karen_sys.stdout, _karen_sys.stderr):
        try:
            if _st is None or not hasattr(_st, "reconfigure"):
                continue
            if _st.isatty():
                _st.reconfigure(errors="replace")
            else:
                # line_buffering: без него лог скрытого сервера «молчит», пока
                # не наберётся 8 КБ, - диагностика по росту лога не работает
                _st.reconfigure(encoding="utf-8", errors="replace",
                                line_buffering=True)
        except Exception:
            pass


_karen_fix_stdio()
# --- end KAREN stdio guard -------------------------------------------------
import glob
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile

import yaml

ROOT = os.path.join(os.environ["ARENA_WORKSPACE"], "karen")
problems = []
os.chdir(ROOT)

print("=" * 72)
print(" ПРИЁМКА ПРОЕКТА КАРЕН")
print("=" * 72)

# 1. Python
print("\n[1] Компиляция Python-файлов")
py = sorted(glob.glob("**/*.py", recursive=True))
with tempfile.TemporaryDirectory() as td:
    for f in py:
        cfile = os.path.join(td, os.path.basename(f) + "c")
        r = subprocess.run([sys.executable, "-c",
                            "import py_compile,sys; py_compile.compile(sys.argv[1], cfile=sys.argv[2], doraise=True)",
                            f, cfile], capture_output=True, text=True)
        if r.returncode == 0:
            print(f"    ok    {f}")
        else:
            err = (r.stderr or r.stdout).strip().splitlines()
            problems.append(f"не компилируется {f}: {err[-1][:140] if err else '?'}")
            print(f"    FAIL  {f}: {err[-1][:140] if err else '?'}")

# 2. YAML
print("\n[2] Синтаксис YAML")
for f in sorted(glob.glob("**/*.yaml", recursive=True)):
    try:
        yaml.safe_load(io.open(f, encoding="utf-8"))
        print(f"    ok    {f}")
    except Exception as e:
        problems.append(f"YAML {f}: {str(e)[:120]}")
        print(f"    FAIL  {f}: {str(e)[:120]}")

# 3. PowerShell: баланс скобок вне here-строк
print("\n[3] PowerShell setup_windows.ps1")
s = io.open("scripts/setup_windows.ps1", encoding="utf-8").read()
lines = s.split("\n")
cleaned, in_hs, hs = [], False, 0
for ln in lines:
    st = ln.strip()
    if not in_hs and (st.endswith('@"') or st.endswith("@'")):
        in_hs = True; hs += 1; cleaned.append(""); continue
    if in_hs and (st == '"@' or st.startswith('"@ ') or st == "'@"):
        in_hs = False; cleaned.append(""); continue
    cleaned.append("" if in_hs else ln)
t = "\n".join(cleaned)
d = par = 0; sq = dq = False; i = 0; ln_no = 1
while i < len(t):
    c = t[i]
    if c == "\n":
        ln_no += 1; sq = dq = False
    elif c == "`" and (dq or sq):
        i += 2; continue
    elif c == "'" and not dq:
        sq = not sq
    elif c == '"' and not sq:
        dq = not dq
    elif not sq and not dq:
        if c == "#":
            while i < len(t) and t[i] != "\n":
                i += 1
            continue
        if c == "{": d += 1
        elif c == "}":
            d -= 1
            if d < 0: problems.append(f"PS: лишняя }} строка {ln_no}")
        elif c == "(": par += 1
        elif c == ")":
            par -= 1
            if par < 0: problems.append(f"PS: лишняя ) строка {ln_no}")
    i += 1
print(f"    here-строк: {hs} | баланс {{}}: {d} | (): {par} | строк: {len(lines)}")
if d or par:
    problems.append(f"PS: несбалансированные скобки {{}}={d} ()={par}")
# опасная интерполяция ${VAR} внутри двойных кавычек
for n, ln in enumerate(s.split("\n"), 1):
    if "${" in ln:
        stripped = ln.strip()
        if stripped.startswith("Warn '") or stripped.startswith("#"):
            continue
        problems.append(f"PS строка {n}: ${{...}} вне одинарных кавычек: {stripped[:70]}")
print("    интерполяция ${...}: безопасно" if not any("${" in p for p in problems) else "    ЕСТЬ ПРОБЛЕМА")

# 3b. Кодировки Windows-файлов.
# Реальный инцидент (2026-09-21): setup_windows.ps1 был сохранён в UTF-8 БЕЗ BOM,
# Windows PowerShell 5.1 прочитал его как ANSI (CP1251/CP1252) -> кракозябры
# «РЎС‚РµРє» и ошибки парсинга. Для .bat другая ловушка: cmd.exe декодирует
# файлы в OEM-кодовой странице (CP866 на русской Windows), поэтому кириллица
# в bat-файлах недопустима - только ASCII.
print("\n[3b] Кодировки Windows-файлов")
BOM = b"\xef\xbb\xbf"
for rel in sorted(glob.glob("**/*.ps1", recursive=True)):
    raw = open(rel, "rb").read()
    if not raw.startswith(BOM):
        problems.append(rel + ": нет UTF-8 BOM - PowerShell 5.1 прочитает как ANSI")
        print("    FAIL  " + rel + ": без BOM")
    elif b"\r\n" not in raw:
        problems.append(rel + ": нет CRLF-переносов")
        print("    FAIL  " + rel + ": LF вместо CRLF")
    else:
        n = raw.count(b"\r\n")
        print("    ok    " + rel + ": UTF-8 BOM + CRLF (" + str(n) + " строк)")
for rel in sorted(glob.glob("**/*.bat", recursive=True)):
    raw = open(rel, "rb").read()
    non_ascii = [b for b in raw if b > 127]
    if non_ascii:
        problems.append(rel + ": " + str(len(non_ascii)) + " не-ASCII байт - cmd.exe (OEM CP866) их исказит")
        print("    FAIL  " + rel + ": не-ASCII (" + str(len(non_ascii)) + " байт)")
    elif b"\r\n" not in raw:
        problems.append(rel + ": нет CRLF-переносов")
        print("    FAIL  " + rel + ": LF вместо CRLF")
    else:
        n = raw.count(b"\r\n")
        print("    ok    " + rel + ": ASCII + CRLF (" + str(n) + " строк)")
# VBS: ASCII + CRLF и ОБЯЗАТЕЛЬНО без BOM - wscript.exe отказывается
# выполнять файл с UTF-8 BOM ("Invalid character").
for rel in sorted(glob.glob("**/*.vbs", recursive=True)):
    raw = open(rel, "rb").read()
    non_ascii = [b for b in raw if b > 127]
    if raw.startswith(BOM):
        problems.append(rel + ": UTF-8 BOM - wscript выдаст 'Invalid character'")
        print("    FAIL  " + rel + ": есть BOM")
    elif non_ascii:
        problems.append(rel + ": " + str(len(non_ascii)) + " не-ASCII байт")
        print("    FAIL  " + rel + ": не-ASCII (" + str(len(non_ascii)) + " байт)")
    elif b"\r\n" not in raw:
        problems.append(rel + ": нет CRLF-переносов")
        print("    FAIL  " + rel + ": LF вместо CRLF")
    else:
        n = raw.count(b"\r\n")
        print("    ok    " + rel + ": ASCII + CRLF, без BOM (" + str(n) + " строк)")

allfiles_pre = {os.path.relpath(x, ROOT).replace("\\", "/")
                for x in glob.glob("**/*", recursive=True) if os.path.isfile(x)}

# 3c. Python: защита stdout от UnicodeEncodeError (cp1251).
# Инцидент 2026-09-21: сервер запускался скрыто, stdout шёл в logs\tts.log,
# Python взял кодовую страницу локали cp1251, а стрелка U+2192 в баннере дала
# UnicodeEncodeError -> процесс умер мгновенно, а start_karen.bat молча ждал
# порт 10 минут. Guard обязан быть в КАЖДОМ .py: console -> errors='replace',
# файл/pipe -> UTF-8.
print("\n[3c] Python: stdio guard + символы вне cp1251")
GUARD_MARK = "_karen_fix_stdio"
for f in py:
    txt = io.open(f, encoding="utf-8").read()
    if GUARD_MARK not in txt:
        problems.append(f"{f}: нет KAREN stdio guard "
                        f"(python tools/inject_stdio_guard.py)")
        print(f"    FAIL  {f}: guard отсутствует")
        continue
    # символы, которые cp1251 не кодирует: с guard они безопасны, но в
    # print/help их быть не должно - это двойная страховка
    risky = set()
    for m in re.finditer(r"(?:print\(|help=|raise SystemExit\(|detail=)", txt):
        for ch in txt[m.end():m.end() + 400]:
            if ord(ch) > 127:
                try:
                    ch.encode("cp1251")
                except Exception:
                    risky.add(ch)
    note = ""
    if risky:
        note = "  (вне cp1251 в печати: " + ",".join(f"U+{ord(c):04X}" for c in sorted(risky)) + ")"
        if "test_groq_api" not in f:
            problems.append(f"{f}: в print/help символы вне cp1251 {sorted(risky)} - "
                            f"замените на ASCII")
    print(f"    ok    {f}: guard есть{note}")

# 3d. .bat: все goto/call :label ведут на существующие метки + файлы на месте.
# Ошибка здесь выглядит как «bat молча ничего не делает» - отловить глазами
# трудно, поэтому проверяем машиной.
print("\n[3d] .bat: метки, goto, ссылки на файлы")
for f in sorted(glob.glob("**/*.bat", recursive=True)):
    lines = io.open(f, encoding="utf-8", errors="replace").read().split("\n")
    labels, targets = set(), []
    for n, ln in enumerate(lines, 1):
        st = ln.strip()
        if st.upper().startswith("REM") or st.startswith("::"):
            continue
        m = re.match(r"^:([A-Za-z_][A-Za-z0-9_]*)", st)
        if m:
            labels.add(m.group(1).lower())
        for g in re.finditer(r"\bgoto\s+:?([A-Za-z_][A-Za-z0-9_]*)", ln, re.I):
            name = g.group(1).lower()
            if name not in ("eof",):
                targets.append((n, name))
        for c in re.finditer(r"\bcall\s+:([A-Za-z_][A-Za-z0-9_]*)", ln, re.I):
            targets.append((n, c.group(1).lower()))
    missing = [(n, t) for n, t in targets if t not in labels]
    unused = sorted(labels - {t for _, t in targets})
    if missing:
        for n, t in missing:
            problems.append(f"{f}:{n}: goto/call :{t} - метки нет")
        print(f"    FAIL  {f}: нет меток {[t for _, t in missing]}")
    else:
        print(f"    ok    {f}: меток {len(labels)}, переходов {len(targets)}"
              + (f", неиспользуемые: {unused}" if unused else ""))
    # баланс блоков: cmd ломается на непарной скобке, а выглядит это как
    # «bat молча ничего не делает». Экранированные ^( ^) и содержимое
    # кавычек не считаются.
    depth = 0; neg = []
    for n, ln in enumerate(lines, 1):
        st = ln.strip()
        if st.upper().startswith("REM") or st.startswith("::"):
            continue
        t = re.sub(r"\^\(|\^\)", "", ln)
        t = re.sub(r'"[^"]*"', "", t)
        depth += t.count("(") - t.count(")")
        if depth < 0:
            neg.append(n); depth = 0
    if depth or neg:
        problems.append(f"{f}: скобки блоков не сбалансированы (остаток {depth}, "
                        f"лишние ) на строках {neg[:5]})")
        print(f"    FAIL  {f}: баланс скобок {depth:+d}, строки {neg[:5]}")
    # for /f: команда в одинарных кавычках - их число должно быть чётным
    for n, ln in enumerate(lines, 1):
        if re.search(r"\bfor\s+/f\b", ln, re.I) and ln.count("'") % 2:
            problems.append(f"{f}:{n}: for /f с непарным числом одинарных кавычек")
            print(f"    FAIL  {f}:{n}: for /f quoting")

    # файлы, которые bat ЗАПУСКАЕТ (wscript/call/start), должны лежать рядом.
    # Пробы вида `if exist "%HERE%run_server.py"` не считаем: они ищут чужой
    # проект (Open-LLM-VTuber), а не файл карен.
    txt = io.open(f, encoding="utf-8", errors="replace").read()
    for ln in txt.split("\n"):
        low = ln.strip().lower()
        if low.startswith(("if exist", "if not exist", "rem")):
            continue
        if not re.search(r"\b(wscript|call|start)\b", low):
            continue
        for m in re.finditer(r'"%HERE%([A-Za-z0-9_.\-]+\.(?:bat|vbs))"', ln):
            ref = m.group(1).replace("\\", "/")
            if ref not in allfiles_pre:
                problems.append(f"{f}: запускает отсутствующий {ref}")
                print(f"    FAIL  {f} -> {ref}")

# 4. Ссылки в HTML и MD на существующие файлы
print("\n[4] Ссылки на файлы (HTML + Markdown)")
allfiles = {os.path.relpath(p, ROOT).replace("\\", "/") for p in glob.glob("**/*", recursive=True)
            if os.path.isfile(p)}
link_re = re.compile(r'(?:src|href)="([^"#]+)"|\*\*`([^`]+\.(?:md|html|py|ps1|bat|yaml|wav|mp3))`\*\*')
# index.html собирается из index.template.html (tools/build_index.py) и содержит
# аудио как data URI, поэтому пути проверяем по ШАБЛОНУ, а не по собранной странице.
for f in ["index.template.html", "README.md", "INSTALL.md",
          "00_AUDIT.md", "01_PLAN.md", "02_VOICE.md"]:
    if not os.path.isfile(f):
        problems.append(f"нет файла {f}")
        continue
    txt = io.open(f, encoding="utf-8").read()
    checked = 0
    # HTML-атрибуты ищем только вне inline-кода: в markdown пример вида
    # `<audio src="audio/...">` не ссылка, а иллюстрация
    txt_attrs = re.sub(r"`[^`\n]*`", "", txt)
    for m in re.finditer(r'(?:src|href)="([^"#][^"]*)"', txt_attrs):
        ref = m.group(1)
        if ref.startswith(("http://", "https://", "mailto:")):
            continue
        base = os.path.dirname(f)
        rel = os.path.normpath(os.path.join(base, ref)).replace("\\", "/")
        checked += 1
        if rel not in allfiles:
            problems.append(f"{f}: битая ссылка -> {ref}")
            print(f"    FAIL  {f} -> {ref}")
    # в markdown дополнительно ищем ссылки на audio/... и *.html.
    # Плейсхолдеры вида `audio/...` и пути с * ссылкой не считаются.
    for m in re.finditer(r"`(audio/[^`]+\.(?:wav|mp3|html))`", txt):
        ref = m.group(1)
        if "..." in ref or "*" in ref:
            continue
        checked += 1
        if ref not in allfiles:
            problems.append(f"{f}: битая ссылка -> {ref}")
            print(f"    FAIL  {f} -> {ref}")
    for m in re.finditer(r'\((audio/[^)]+\.html)\)', txt):
        ref = m.group(1)
        if "..." in ref or "*" in ref:
            continue
        checked += 1
        if ref not in allfiles:
            problems.append(f"{f}: битая ссылка -> {ref}")
    print(f"    ok    {f}: проверено ссылок {checked}")

# 4b. index.html: собран, автономен, не устарел
print("\n[4b] Собранная страница index.html")
if not os.path.isfile("index.html"):
    problems.append("нет index.html — запустите python tools/build_index.py")
    print("    FAIL  index.html отсутствует")
else:
    page = io.open("index.html", encoding="utf-8").read()
    tpl = os.path.getmtime("index.template.html") if os.path.isfile("index.template.html") else 0
    built = os.path.getmtime("index.html")
    if tpl and tpl > built:
        problems.append("index.html старее index.template.html — пересоберите: python tools/build_index.py")
        print("    FAIL  index.html устарел относительно шаблона")
    n_data = len(re.findall(r'src="data:audio/', page))
    n_rel = len(re.findall(r'src="audio/', page))
    size_mb = os.path.getsize("index.html") / 1048576
    print(f"    data URI дорожек: {n_data} | относительных ссылок audio/: {n_rel} | размер {size_mb:.2f} МБ")
    if n_rel:
        problems.append(f"index.html содержит {n_rel} относительных ссылок на audio/ — "
                        f"в песочнице они не сыграют. Пересоберите: python tools/build_index.py")
    if not n_data:
        problems.append("в index.html нет ни одной встроенной дорожки")
    if size_mb > 12:
        problems.append(f"index.html {size_mb:.1f} МБ — превью может тормозить")

# 5. Ключи API
print("\n[5] Секреты")
found = []
for p in glob.glob("**/*", recursive=True):
    if not os.path.isfile(p):
        continue
    try:
        txt = io.open(p, encoding="utf-8", errors="ignore").read()
    except Exception:
        continue
    for m in re.finditer(r"gsk_[A-Za-z0-9]{20,}", txt):
        found.append(f"{p}: {m.group(0)[:14]}...")
if found:
    problems.append("найдены ключи: " + "; ".join(found))
    print("    FAIL", found)
else:
    print("    ok    ключей API в файлах нет")

# 6. Мусор
print("\n[6] Мусор и пустые папки")
junk = []
for p in sorted(glob.glob("**/*", recursive=True), key=len, reverse=True):
    base = os.path.basename(p)
    if base == "__pycache__" and os.path.isdir(p):
        shutil.rmtree(p, ignore_errors=True); junk.append(p + " (удалён)")
    elif p.endswith(".pyc") or base.startswith(".DS_Store"):
        try: os.remove(p); junk.append(p + " (удалён)")
        except OSError: pass
    elif os.path.isdir(p) and not os.listdir(p):
        try: os.rmdir(p); junk.append(p + "/ (пустая папка удалена)")
        except OSError: pass
print("    убрано:", junk or "нечего")

# 7. Итоговая структура и размер
print("\n[7] Состав проекта")
# пересканируем: шаг 6 мог удалить кэш
allfiles = {os.path.relpath(x, ROOT).replace("\\", "/")
            for x in glob.glob("**/*", recursive=True) if os.path.isfile(x)}
total = 0
for p in sorted(allfiles):
    sz = os.path.getsize(p)
    total += sz
print(f"    файлов: {len(allfiles)} | суммарно: {total/1048576:.1f} МБ")
by_dir = {}
for p in allfiles:
    d = os.path.dirname(p) or "."
    by_dir[d] = by_dir.get(d, 0) + 1
for d in sorted(by_dir):
    print(f"      {d:24s} {by_dir[d]:3d} файл(ов)")

print("\n" + "=" * 72)
if problems:
    print(f" ПРОБЛЕМ: {len(problems)}")
    for p in problems:
        print("   -", p)
    print("=" * 72)
    sys.exit(1)
print(" ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ")
print("=" * 72)
