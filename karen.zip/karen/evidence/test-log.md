# Журнал проверок (evidence)

Дата: **2026-09-21**
Стенд проверки: Linux-контейнер (Debian 12, 2 vCPU Intel Xeon, без GPU), исходящий IP — Сингапур (`cf-ray ...-SIN`).
**Это не ваш ноутбук**: абсолютные цифры CPU/сети на Lenovo Legion Y7000P будут лучше. Валидны относительные выводы и все факты про API/конфиги.

---

## 1. Cloudflare 1010 — причина найдена

| Клиент | Результат |
|---|---|
| `urllib.request`, дефолтный `User-Agent: Python-urllib/3.11` | `HTTP 403`, тело: `error code: 1010`, `server: cloudflare`, `cf-ray: a3e4cd634c3191ba-SIN` |
| `urllib.request` + браузерный `User-Agent` (Chrome/126) | `HTTP 401 {"error":{"message":"Invalid API Key",...}}` — **WAF пройден**, дошло до API (ключа в заголовке не было) |
| SDK `groq` 1.7.0 | ✅ работает во всех тестах ниже |

**Вывод:** 1010 — фильтрация по User-Agent, а не геоблокировка и не «нелюбовь к curl».
Практика: любой HTTP-клиент с нормальным UA проходит. Open-LLM-VTuber ходит через SDK (`openai`/`groq`, httpx) → проблемы не будет.

---

## 2. Ключ и доступные модели

`GET /v1/models` ключом из паспорта → **200 OK, 13 моделей** (полный ответ: `groq_models.json`):

```
allam-2-7b
canopylabs/orpheus-arabic-saudi
canopylabs/orpheus-v1-english
groq/compound
groq/compound-mini
meta-llama/llama-prompt-guard-2-22m
meta-llama/llama-prompt-guard-2-86m
openai/gpt-oss-120b
openai/gpt-oss-20b
openai/gpt-oss-safeguard-20b
qwen/qwen3.8-27b          <-- целевая модель присутствует
whisper-large-v3
whisper-large-v3-turbo
```

Организация: `org_01m30fyhkweexbtn7fvvc90cf1`, service tier `on_demand` (бесплатный).

---

## 3. Латентность и токены `qwen/qwen3.8-27b`

Системный промпт — дословно из паспорта:
> «Ты — игривый AI VTuber-компаньон. Отвечай коротко, живо и по-русски.»

| # | Параметры | wall | generation | скорость | completion tok. | Ответ |
|---|---|---|---|---|---|---|
| 1 | `temperature=0.8, max_tokens=100` (как в `test_official.py`) | **0.25 c** | 0.082 c | 528 t/s | 43 | «Ой, Lenovo? 😎 Звучит мощно! Какой именно цвет? Если чёрный — то уже топ, но если есть подсветка, я прям плачу от счастья! 💻✨» |
| 2 | `max_tokens=1024` | — | — | — | — | ❌ **429 OTPM** (см. раздел 5) |
| 3 | `max_tokens=1000` | 0.25 c | — | — | 40 | OK |
| 4 | стриминг, `max_tokens=200` | **0.31 c** всего | — | — | ~370 симв. | **первый токен через 0.13 c** |
| 5 | `reasoning_effort="none"` | 0.20 c | 0.075 c | 528 t/s | 37 | `reasoning_content: None` |
| 6 | `reasoning_effort="none", temperature=0.7, presence_penalty=1.5` (рекомендация Qwen для instruct) | 0.22 c | 0.092 c | 525 t/s | 46 | OK |
| 7 | повторный прогон `test_groq_api.py`, промпт без эмодзи | 0.21 c | 0.063 c | 524 t/s | 33 | «Ого, огонь! Это же зверь для игр и рендера. Ты уже проверил его на тяжелых проектах? Я прям завидую.» |
| 8 | стриминг (повторно) | 0.23 c | — | — | 55 чанков / 186 симв. | первый токен **0.14 c** |

Наблюдения:
* `queue_time ≈ 0.05 c`, `prompt_time ≈ 0.004 c` — очередь на Groq практически отсутствует.
* **Thinking-режим не мешает**: `reasoning_content` пустой, на токены не расходуется.
* Русский язык и стиль держит уверенно.
* ⚠️ Эмодзи появляются, если их прямо не запретить (тест 1 vs тест 7). Для TTS это мусор → держать `remove_special_char: True` + запрет в персоне.

---

## 4. Vision — работает тем же ключом

`scripts/groq_vision_test.py`, синтетический кадр 320×160 (синий фон, красный квадрат 60..160×40..120, зелёная полоса внизу), OpenAI-формат `image_url` + base64:

```
[i] источник: синтетический тестовый кадр 320x160, 1 КБ, mime=image/png
[ok] ответ за 0.35 c | prompt=831 completion=27
«Флаг состоит из синего поля с красным прямоугольником в левом верхнем углу и зеленой полосы внизу.»
```

**Вывод:** зрение доступно на вашей модели и тарифе; описание точное (цвета и расположение совпали). Промпт-токенов ушло 831, а не 2048 — расход зависит от разрешения картинки. Отдельный Alibaba Qwen-VL для этого не нужен.

---

## 5. Лимиты аккаунта — фактические заголовки

```
x-ratelimit-limit-requests      : 1000      (RPD — запросов в сутки)
x-ratelimit-remaining-requests  : 997
x-ratelimit-limit-tokens        : 8000      (TPM — токенов в минуту)
x-ratelimit-remaining-tokens    : 7782
x-ratelimit-reset-requests      : 4m19.2s
x-ratelimit-reset-tokens        : 5.52s
```

Доки Groq по модели: RPM 30 · RPD 1 000 · TPM 8 000 · TPD 200 000; контекст 131 042; max output 16 384; цена $0.80/M in, $4.00/M out.

Ошибка OTPM (первый прогон, `max_tokens=1024`):
```
429 {'error': {'message': "Request too large for model `qwen/qwen3.8-27b` in organization
`org_01m3...` service tier `on_demand` on output tokens per minute (OTPM): Limit 1000,
Requested 1024. The request's expected output tokens exceed the enforced limit; reduce
max_tokens (or the request's expected output) and try again. Need more tokens? Upgrade to
Dev Tier today at https://console.groq.com/settings/billing", 'type': 'tokens',
'code': 'rate_limit_exceeded'}}
```
В повторном прогоне (минутный бюджет был свободен) `max_tokens=1024` прошёл.
→ Ограничение **плавающее по минутному бюджету**, а не жёсткий потолок параметра. Это и есть источник ошибок «то работает, то нет».

Whisper на том же аккаунте: 20 RPM · 2K RPD · 7 200 аудиосек/час · 28 800 аудиосек/сутки (≈ 8 ч речи в день).

---

## 6. Piper TTS — русский голос, замер скорости

Модель: `ru_RU-irina-medium` (зеркало `speaches-ai/piper-ru_RU-irina-medium`, `model.onnx` 63.2 МБ + `config.json`; переименованы в `ru_RU-irina-medium.onnx` / `.onnx.json`).
Библиотека: `piper-tts` (pip), espeak-ng phonemizer, `espeak voice = "ru"`, 1 спикер, 22 050 Гц.
Стенд: **2 vCPU Intel Xeon (контейнер)** — заведомо слабее i7-13620H.

```
текст (118 симв.): «Привет! Я твой локальный ви-тубер компаньон. Сейчас проверим,
                    насколько быстро я умею говорить по-русски на процессоре.»
загрузка модели : 1.28 c
синтез          : 1.11 c
длительность    : 7.81 c аудио (WAV 22 050 Гц, 344 620 байт)
RTF             : 0.142
```

**Экстраполяция на i7-13620H (10C/16T): RTF ≈ 0.03–0.06**, т.е. ~0.2–0.5 c на фразу. Для голосового пайплайна — отлично, VRAM не используется.

Скачано за 6.1 c (63.2 МБ).

---

## 7. Edge TTS — сравнение (облачный, бесплатный)

`edge-tts` (pip), список голосов → русских ровно два:

```
[('ru-RU-DmitryNeural', 'Male'), ('ru-RU-SvetlanaNeural', 'Female')]
ru-RU-SvetlanaNeural : 2.19 c  -> 58 752 байт (mp3)
ru-RU-DmitryNeural   : 6.40 c  -> 60 192 байт (mp3)
```

Тот же текст, что в тесте Piper. Задержка с сингапурского стенда 2.2–6.4 c **на фразу** — для голосового компаньона хуже Piper, зато качество голоса заметно выше. Требует интернет.

🎧 Сэмплы: `audio/piper_ru_RU-irina-medium_sample.wav`, `audio/edge-tts_ru-RU-SvetlanaNeural_sample.mp3`, `audio/edge-tts_ru-RU-DmitryNeural_sample.mp3`.

---

## 8. Валидация конфигов настоящей схемой проекта

Метод: скачаны 13 модулей `src/open_llm_vtuber/config_manager/` и `config_templates/conf.default.yaml` из ветки `main` (v1.2.1), зависимости `pydantic 2.13.5` + `loguru` + `chardet`, затем `validate_config(read_yaml(...))`.

| Файл | Результат |
|---|---|
| `config.yaml` из технического паспорта | ❌ **INVALID**: `1 validation error for Config / character_config / Field required` (все секции `llm:`/`asr:`/`tts:` молча проигнорированы как неизвестные) |
| `conf.yaml`, собранный `merge_conf.py` (шаблон + `conf.patch.yaml`) | ✅ VALID: `llm=groq_llm asr=faster_whisper tts=piper_tts vad=silero_vad` |
| `config/conf.patch.yaml` как самостоятельный конфиг | ✅ VALID |
| `config/characters/karen.yaml` | ✅ VALID (персона 782 симв. ≈ 195 токенов на запрос) |
| `patch_conf.py` → conf.yaml, 8 комбинаций (`faster_whisper`/`groq_whisper_asr`/`whisper_cpp`/`sherpa_onnx_asr` × `piper_tts`/`edge_tts`) | ✅ все 8 VALID |
| `merge_conf.py --lint` (синтаксис YAML: conf.yaml, characters/*.yaml) | ✅ все ok |

Ключевые факты из исходников (проверено чтением кода, не по докам):

* `run_server.py`: `config = validate_config(read_yaml("conf.yaml"))` — **имя файла зашито**, `--config` не поддерживается.
* `config_manager/utils.py`: `pattern = re.compile(r"\$\{(\w+)\}")` → **подстановка `${VAR}` работает**; `load_dotenv` нигде нет → **`.env` не читается**, нужны переменные ОС.
* `config_manager/main.py`: `character_config: CharacterConfig = Field(...)` → раздел **обязателен**.
* `config_manager/stateless_llm.py`: `OpenAICompatibleConfig` = `base_url`, `llm_api_key`, `model`, `organization_id`, `project_id`, `temperature`, `interrupt_method`. **`max_tokens` отсутствует.** `GroqConfig` наследует его и задаёт `base_url = https://api.groq.com/openai/v1`, `interrupt_method = 'system'`.
* `config_manager/i18n.py`: `model_config = ConfigDict(populate_by_name=True)` → `extra` не разрешён, по умолчанию pydantic v2 **игнорирует** неизвестные поля (поэтому опечатки не видны).
* `config_manager/agent.py`: `llm_provider` — `Literal[...]`, в списке есть `groq_llm` и `openai_compatible_llm`.
* `pyproject.toml`: `requires-python >=3.10,<3.13`; в зависимостях есть `groq`, `edge-tts`, `sherpa-onnx`, `torch>=2.6`, `openai`, `mcp[cli]`; **нет** `faster-whisper`, `piper-tts`, `pywhispercpp` — их нужно доустанавливать.
* PyPI: `https://pypi.org/pypi/open-llm-vtuber/json` → **404 Not Found** (пакет не публикуется, `pip install open-llm-vtuber` невозможен).
* GitHub API: 13 854 звёзд, 1 653 форка, 156 открытых issues; релиз **v1.2.1** от 2025-08-26 (ассеты: `open-llm-vtuber-1.2.1-setup.exe` 101 МБ, `.dmg`, zip en/zh); ветки: `main`, `dev`, `v1-release`, `v2` (рерайт).
* README: «v2.0 — полный рерайт, в ранней фазе планирования; v1 продолжает получать баг-фиксы»; клон **обязательно** с `--recursive` (фронтенд — submodule); рекомендуется Chrome; для удалённого доступа нужен HTTPS (микрофон работает только в secure context).

---

## 9. Что проверить на своём железе (я проверить не мог)

| Пункт | Как проверить |
|---|---|
| Свободные слоты RAM (паспорт планирует 2×16 ГБ) | `wmic memorydevice get BankLabel,DeviceLocator,Capacity,PartNumber` + спецификация машины на psref.lenovo.com. У Y7000P 2023 IRH8 обычно 2× SO-DIMM DDR5-5600 (до 64 ГБ), но в части партий память распаяна |
| Реальный RTF Piper на i7-13620H | `python scripts/download_piper_ru.py` — в конце печатает RTF |
| Реальная задержка faster-whisper small на RU | после первого запуска посмотреть `logs/debug_*.log` |
| Доступность api.groq.com из вашей сети | `python scripts/test_groq_api.py` (тест 1/7 покажет и 1010, и таймауты) |
| Срок действия бесплатной квоты Alibaba | dashscope.console.aliyun.com → Billing/Quota (цифру «70M токенов / 90 дней» из паспорта подтвердить не могу) |
| Расход RPD за сессию | после 10 минут разговора: console.groq.com/settings/usage + заголовки `x-ratelimit-remaining-requests` |
