# Баг TTS «ошибка синтеза: » (HTTP 500) — расследование и фикс, 2026-09-21

## Симптом (логи пользователя)

`logs/backend.log`:

```
CRITICAL | src.open_llm_vtuber.tts.openai_tts:generate_audio:107 |
  Error: OpenAI TTS unable to generate audio: Error code: 500 - {'detail': 'ошибка синтеза: '}
```

`logs/tts.log` (наш Silero-сервер):

```
[!] синтез через SSML не удался (ValueError: ) — пробую обычным текстом     <- пустое сообщение!
INFO: 127.0.0.1:22140 - "POST /v1/audio/speech HTTP/1.1" 500 Internal Server Error
```

## Расследование

`tts/.venv-silero/.../v5_5_ru.pt` — это torch.package (zip). Настоящий код
модели упакован внутри: `multi_acc_v3_package.py`. Извлечено и прочитано:

```python
def process_simple_text(self, text, lang):
    sentence, clean_sentence, has_text = self.prepare_text_input(text, lang)
    if not has_text:
        raise ValueError          # <- ГОЛЫЙ ValueError, str(e) == ""

# prepare_text_input:
clean_sentence = re.sub(r'[^а-я\- ]', '', sentence)   # всё, кроме кириллицы, - выброс
has_text = len(clean_sentence.replace(' ', '')) > 0
```

Вывод: v5_5_ru — русскоязычный пак; текст без единой кириллической буквы
(чистая латиница / цифры / эмодзи) → голый `ValueError()` → наш сервер
отдавал 500 с пустой причиной. Бэкенд в тот вечер пытался озвучить
английскую строку ошибки Groq («Error calling the chat endpoint: ...») —
поэтому падала КАЖДАЯ реплика.

## Воспроизведение в песочнице (реальная модель v5_5_ru, baya, 48 кГц)

```
ru-warmup  «Проверка связи.»                      -> OK   1.34 c аудио
en-error   «Error calling the chat endpoint: ...» -> ValueError()
en-short   «See the logs for details.»            -> ValueError()
en-mixed   «Привет! Error calling ...»            -> OK 0.78 c  <- латиница молча выброшена
digits     «Код ошибки 403.»                      -> OK   1.04 c
pure-digit «403»                                  -> ValueError()
```

## Фикс (tts/silero_openai_tts_server.py)

`ensure_pronounceable()` перед синтезом:
- латинские слова → кириллица фонетически (digraph-таблица sh/ch/th/ph/...);
- теги эмоций `[joy]` защищены плейсхолдерами;
- текст без кириллицы И латиницы → запасная фраза «Хм, тут что-то нечитаемое.»;
- флаг `--no-translit` (защита от 500 остаётся и с ним);
- ошибки в логе/detail больше никогда не пустые: тип исключения + текст;
- прогрев `--warmup` теперь включает латинскую фразу (регресс-контроль).

## Проверка после фикса (HTTP, как вызывает Open-LLM-VTuber)

```
HTTP 200  5.55s audio  <- 'Error calling the chat endpoint: Error occurred ...'
HTTP 200  1.94s audio  <- 'See the logs for details.'
HTTP 200  3.26s audio  <- 'Привет! Я Карен, твой локальный компаньон.'   (регрессия)
HTTP 200  2.96s audio  <- 'Привет, Error calling the chat endpoint.'      (смешанный)
HTTP 200  2.17s audio  <- '403'                                           (fallback-фраза)
HTTP 200  3.44s audio  <- 'The quick brown fox jumps over the lazy dog.'
```

Полный `tts/test_silero_server.py` (с новой секцией 4b «noncyr»): 22 запроса,
все 200, RTF 0.041.

## Артефакты

- `after_fix_latin_error_translit.wav` — та самая строка ошибки, озвученная
  транслитом: «Еррор каллинг те чат ендпоинт: ...»
- `after_fix_digits_fallback.wav` — «403» → «Хм, тут что-то нечитаемое.»
