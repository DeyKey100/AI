' =====================================================================
'  KAREN helper - runs a program in a FULLY HIDDEN console window.
'  Used by start_karen.bat / start_vtuber.bat so that no cmd windows
'  appear on the taskbar. Output is appended to a log file.
'
'  Usage:
'    wscript //nologo run_hidden.vbs <program> <logfile|""> [args...]
'  Example:
'    wscript //nologo run_hidden.vbs "F:\AI\karen\start_tts_server.bat" "F:\AI\karen\logs\tts.log"
'    wscript //nologo run_hidden.vbs "F:\AI\karen\wait_and_launch_app.bat" "F:\AI\karen\logs\app.log" "F:\AI\app.lnk"
'
'  Why VBS: it is the only zero-dependency way to spawn a console process
'  with window style 0 (hidden). PowerShell -WindowStyle Hidden still
'  flashes a window; `start /min` keeps a taskbar button.
'
'  ASCII-only. MUST be saved WITHOUT a BOM (wscript rejects BOM'd VBS).
' =====================================================================
Option Explicit
Dim sh, args, cmd, i, prog, log
Set sh = CreateObject("WScript.Shell")
Set args = WScript.Arguments
If args.Count < 1 Then WScript.Quit 1
prog = args(0)
log = ""
If args.Count >= 2 Then log = args(1)

' cmd /c call "prog" "arg2" "arg3" >>"log" 2>&1
' The command line deliberately starts with the word `call` (not a quote),
' so cmd.exe does not apply its first/last quote-stripping rule.
cmd = "cmd /c call """ & prog & """"
For i = 2 To args.Count - 1
  cmd = cmd & " """ & args(i) & """"
Next
If log <> "" Then cmd = cmd & " >>""" & log & """ 2>&1"

sh.Run cmd, 0, False
