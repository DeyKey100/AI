@echo off
REM =====================================================================
REM  KAREN helper - waits for the backend on :12393, then launches the
REM  desktop Electron app. Runs HIDDEN via run_hidden.vbs; its output
REM  goes to karen\logs\app.log.
REM
REM  Usage:  wait_and_launch_app.bat "C:\path\open-llm-vtuber-electron.lnk"
REM
REM  History (2026-09-21): the app path used to contain a ".." segment
REM  (karen\..\app.lnk) and `start` refused such paths with the error
REM  "The syntax of the file name, directory name, or volume label is
REM  incorrect". The path is now normalized (Resolve-Path) before use,
REM  and explorer.exe is kept as a fallback launcher.
REM
REM  ASCII-only file.
REM =====================================================================
setlocal
set "APP=%~1"
if "%APP%"=="" (
    echo [xx] No app path passed. Nothing to launch.
    exit /b 1
)

REM ---- normalize: strip ".." segments (start chokes on them) ----
set "APPN="
for /f "delims=" %%i in ('powershell -NoProfile -Command "(Resolve-Path -LiteralPath '%APP%').Path" 2^>nul') do set "APPN=%%i"
if defined APPN set "APP=%APPN%"
echo [i] app: %APP%

if not exist "%APP%" (
    echo [xx] App not found: %APP%
    exit /b 1
)

REM Log of the hidden backend, used to detect a crash instead of waiting
REM out the whole timeout (2026-09-21 lesson: silent waits waste minutes).
set "BLOG=%~dp0logs\backend.log"
set /a N=0
:loop
set /a N+=1
if %N% GTR 150 (
    echo [xx] Backend did not answer on http://127.0.0.1:12393 within ~6 min.
    echo    Desktop app NOT launched. Read logs\backend.log for the reason.
    if exist "%BLOG%" powershell -NoProfile -Command "Get-Content -LiteralPath '%BLOG%' -Tail 20 -Encoding UTF8" 2>nul
    exit /b 1
)
REM 1) probe FIRST: a backend that already answers wins over any scary
REM    line in its log (loguru may print a handled traceback on startup).
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:12393/' -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto up
REM 2) still down: did the backend die? Our own wrapper writes an explicit
REM    marker on exit, so this does not false-trigger on library noise.
if exist "%BLOG%" (
    findstr /L /I /M /C:"[xx] Backend EXITED" "%BLOG%" >nul 2>nul
    if not errorlevel 1 (
        echo [xx] The backend process EXITED - desktop app NOT launched.
        echo    Last lines of logs\backend.log:
        powershell -NoProfile -Command "Get-Content -LiteralPath '%BLOG%' -Tail 20 -Encoding UTF8" 2>nul
        exit /b 1
    )
)
REM ping-based sleep: unlike `timeout`, it works with redirected output
ping -n 3 127.0.0.1 >nul
goto loop
:up
echo [ok] Backend is up - launching desktop app
start "" "%APP%" 2>nul
if errorlevel 1 (
    echo [i] start failed, falling back to explorer
    explorer "%APP%"
)
exit /b 0
